import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  DEFAULT_SETTINGS,
  DEFAULT_SLIDER,
  DESMOS_COLORS,
  ExamplePreset,
  ExpressionItem,
  ExpressionKind,
  GraphSettings,
  SavedGraph,
  ViewMode,
} from './types/calculator';
import { createExpressionItem, INITIAL_EXPRESSIONS, nextExprId } from './engine/presets';
import { createHistory, HistoryState, pushHistory, redoHistory, undoHistory } from './engine/history';
import { GeoGebraEngineAdapter, SyncFeedback } from './engine/geogebraAdapter';
import {
  decodeShareHash,
  deleteSavedGraph,
  encodeShareUrl,
  listSavedGraphs,
  loadAutosave,
  saveAutosave,
  upsertSavedGraph,
  WorkspaceSnapshot,
} from './engine/storage';
import { TopBar } from './components/TopBar';
import { ExpressionPanel } from './components/ExpressionPanel';
import { GraphViewport } from './components/GeoGebraViewport';
import { MathKeypad } from './components/MathKeypad';
import { SavedGraphsDrawer } from './components/SavedGraphsDrawer';
import { ExamplesModal } from './components/ExamplesModal';
import { ShareModal } from './components/ShareModal';
import { HelpModal } from './components/HelpModal';

function getInitialWorkspace(): {
  title: string;
  expressions: ExpressionItem[];
  settings: GraphSettings;
  viewMode: ViewMode;
  ggbXml2d?: string;
  ggbXml3d?: string;
} {
  const fromHash = decodeShareHash(window.location.hash);
  if (fromHash) return fromHash;
  const fromLocal = loadAutosave();
  if (fromLocal) return fromLocal;
  return {
    title: 'Untitled Graph',
    expressions: INITIAL_EXPRESSIONS,
    settings: DEFAULT_SETTINGS,
    viewMode: '2d',
  };
}

export default function App() {
  const initial = useMemo(() => getInitialWorkspace(), []);

  const [title, setTitle] = useState<string>(initial.title);
  const [activeGraphId, setActiveGraphId] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<ViewMode>(initial.viewMode);
  const [settings, setSettings] = useState<GraphSettings>(initial.settings);
  const [history, setHistory] = useState<HistoryState>(() => createHistory(initial.expressions));
  const [feedbackMap, setFeedbackMap] = useState<Record<string, SyncFeedback>>({});

  const [focusedId, setFocusedId] = useState<string | null>(
    initial.expressions[0]?.id ?? null
  );
  const [sidebarWidth, setSidebarWidth] = useState<number>(380);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [keypadOpen, setKeypadOpen] = useState<boolean>(false);

  const [savedDrawerOpen, setSavedDrawerOpen] = useState<boolean>(false);
  const [examplesOpen, setExamplesOpen] = useState<boolean>(false);
  const [shareOpen, setShareOpen] = useState<boolean>(false);
  const [helpOpen, setHelpOpen] = useState<boolean>(false);
  const [savedGraphs, setSavedGraphs] = useState<SavedGraph[]>(() => listSavedGraphs());

  const [pendingXml2d, setPendingXml2d] = useState<string | null>(initial.ggbXml2d ?? null);
  const [pendingXml3d, setPendingXml3d] = useState<string | null>(initial.ggbXml3d ?? null);

  const inputRefs = useRef<Map<string, HTMLInputElement>>(new Map());
  const adaptersRef = useRef<{
    '2d': GeoGebraEngineAdapter | null;
    '3d': GeoGebraEngineAdapter | null;
  }>({ '2d': null, '3d': null });

  const expressionsWithFeedback = useMemo(() => {
    return history.present.map((item) => {
      const fb = feedbackMap[item.id];
      if (!fb) return item;
      return {
        ...item,
        error: fb.error,
        modeNotice: fb.modeNotice,
        evalResult: fb.evalResult,
        undefinedVars: fb.undefinedVars,
        isSlider: fb.isSlider,
        variableName: fb.variableName,
      };
    });
  }, [history.present, feedbackMap]);

  // Autosave to localStorage
  useEffect(() => {
    const timer = window.setTimeout(() => {
      saveAutosave({
        title,
        expressions: history.present,
        settings,
        viewMode,
      });
    }, 300);
    return () => window.clearTimeout(timer);
  }, [title, history.present, settings, viewMode]);

  // Slider animation loop
  const hasPlayingSlider = useMemo(
    () => history.present.some((item) => item.slider?.playing),
    [history.present]
  );

  useEffect(() => {
    if (!hasPlayingSlider) return;
    const interval = window.setInterval(() => {
      setHistory((prev) => {
        let changed = false;
        const nextList = prev.present.map((item) => {
          if (!item.slider?.playing) return item;
          const m = item.latex.trim().match(/^([a-zA-Z][a-zA-Z0-9_]*)\s*=\s*(-?\d*\.?\d+)$/);
          if (!m) return item;
          const varName = m[1];
          const current = parseFloat(m[2]);
          const { min, max, step, speed, direction, loopMode } = item.slider;
          const span = Math.max(1e-6, max - min);
          const delta = (step > 0 ? Math.max(step, span / 120) : span / 120) * speed * direction;
          let nextVal = current + delta;
          let nextDir = direction;
          let stillPlaying = true;

          if (nextVal >= max) {
            if (loopMode === 'oscillate') {
              nextVal = max;
              nextDir = -1;
            } else if (loopMode === 'loop') {
              nextVal = min;
            } else {
              nextVal = max;
              stillPlaying = false;
            }
          } else if (nextVal <= min) {
            if (loopMode === 'oscillate') {
              nextVal = min;
              nextDir = 1;
            } else if (loopMode === 'loop') {
              nextVal = max;
            } else {
              nextVal = min;
              stillPlaying = false;
            }
          }

          const rounded = Number(nextVal.toFixed(4));
          changed = true;
          return {
            ...item,
            latex: `${varName} = ${rounded}`,
            slider: {
              ...item.slider,
              direction: nextDir,
              playing: stillPlaying,
            },
          };
        });
        return changed ? pushHistory(prev, nextList, false) : prev;
      });
    }, 45);
    return () => window.clearInterval(interval);
  }, [hasPlayingSlider]);

  const registerInputRef = useCallback((id: string, el: HTMLInputElement | null) => {
    if (el) inputRefs.current.set(id, el);
    else inputRefs.current.delete(id);
  }, []);

  const focusAndSelectInput = useCallback((id: string) => {
    setFocusedId(id);
    window.setTimeout(() => {
      const el = inputRefs.current.get(id);
      el?.focus();
    }, 20);
  }, []);

  const handleFeedback = useCallback((mode: ViewMode, fb: Record<string, SyncFeedback>) => {
    setFeedbackMap((prev) => {
      // Only update feedback from the currently active mode
      return { ...prev, ...fb };
    });
  }, []);

  const handleAdapterReady = useCallback(
    (mode: ViewMode, adapter: GeoGebraEngineAdapter | null) => {
      adaptersRef.current[mode] = adapter;
    },
    []
  );

  const handleAddItem = useCallback(
    (kind: ExpressionKind, afterId?: string | null) => {
      const color = DESMOS_COLORS[history.present.length % DESMOS_COLORS.length].hex;
      let folderId: string | null = null;
      if (afterId) {
        const afterItem = history.present.find((i) => i.id === afterId);
        if (afterItem?.type === 'folder') folderId = afterItem.id;
        else if (afterItem?.folderId) folderId = afterItem.folderId;
      }

      const newItem = createExpressionItem({
        type: kind,
        color,
        folderId,
        noteText: kind === 'folder' ? 'New Folder' : '',
        tableColumns:
          kind === 'table'
            ? [
                {
                  id: nextExprId('col'),
                  header: 'x_1',
                  values: ['0', '1', '2', ''],
                  color,
                  visible: true,
                  showLines: false,
                  showPoints: true,
                  pointStyle: 'point',
                  lineStyle: 'solid',
                },
                {
                  id: nextExprId('col'),
                  header: 'y_1',
                  values: ['0', '1', '4', ''],
                  color,
                  visible: true,
                  showLines: true,
                  showPoints: true,
                  pointStyle: 'point',
                  lineStyle: 'solid',
                },
              ]
            : undefined,
      });

      setHistory((prev) => {
        const idx = afterId ? prev.present.findIndex((i) => i.id === afterId) : -1;
        const next = [...prev.present];
        if (idx >= 0) next.splice(idx + 1, 0, newItem);
        else next.push(newItem);
        return pushHistory(prev, next, true);
      });
      setHasUnsavedChanges(true);
      focusAndSelectInput(newItem.id);
    },
    [history.present, focusAndSelectInput]
  );

  const handleUpdateExpression = useCallback(
    (id: string, patch: Partial<ExpressionItem>, recordHistory = true) => {
      setHistory((prev) => {
        const next = prev.present.map((item) => (item.id === id ? { ...item, ...patch } : item));
        return pushHistory(prev, next, recordHistory);
      });
      setHasUnsavedChanges(true);
    },
    []
  );

  const handleDeleteExpression = useCallback(
    (id: string) => {
      setHistory((prev) => {
        const idx = prev.present.findIndex((i) => i.id === id);
        let next = prev.present.filter((i) => i.id !== id && i.folderId !== id);
        if (next.length === 0) {
          next = [createExpressionItem({ type: 'expression', latex: '' })];
        }
        const nextFocus = next[Math.max(0, Math.min(idx - 1, next.length - 1))]?.id ?? null;
        if (nextFocus) focusAndSelectInput(nextFocus);
        return pushHistory(prev, next, true);
      });
      setHasUnsavedChanges(true);
    },
    [focusAndSelectInput]
  );

  const handleDuplicateExpression = useCallback(
    (id: string) => {
      setHistory((prev) => {
        const idx = prev.present.findIndex((i) => i.id === id);
        if (idx === -1) return prev;
        const src = prev.present[idx];
        const copy = createExpressionItem({
          ...src,
          id: nextExprId(),
          slider: src.slider ? { ...src.slider, playing: false } : undefined,
        });
        const next = [...prev.present];
        next.splice(idx + 1, 0, copy);
        return pushHistory(prev, next, true);
      });
      setHasUnsavedChanges(true);
    },
    []
  );

  const handleReorderExpression = useCallback((fromIndex: number, toIndex: number) => {
    setHistory((prev) => {
      const next = [...prev.present];
      const [moved] = next.splice(fromIndex, 1);
      if (!moved) return prev;
      next.splice(toIndex, 0, moved);
      return pushHistory(prev, next, true);
    });
    setHasUnsavedChanges(true);
  }, []);

  const handleAddSliderVars = useCallback((vars: string[], afterId: string) => {
    setHistory((prev) => {
      const existing = new Set(
        prev.present
          .map((i) => i.latex.trim().match(/^([a-zA-Z][a-zA-Z0-9_]*)\s*=/)?.[1])
          .filter(Boolean)
      );
      const toInsert = vars
        .filter((v) => !existing.has(v))
        .map((v, offset) =>
          createExpressionItem({
            type: 'expression',
            latex: `${v} = 1`,
            color: DESMOS_COLORS[(prev.present.length + offset) % DESMOS_COLORS.length].hex,
            slider: { ...DEFAULT_SLIDER },
          })
        );
      if (toInsert.length === 0) return prev;
      const idx = prev.present.findIndex((i) => i.id === afterId);
      const next = [...prev.present];
      next.splice(idx >= 0 ? idx + 1 : next.length, 0, ...toInsert);
      return pushHistory(prev, next, true);
    });
    setHasUnsavedChanges(true);
  }, []);

  // Keypad insertion into currently focused expression input
  const handleKeypadInsert = useCallback(
    (text: string, cursorOffset = 0) => {
      const targetId = focusedId ?? history.present[0]?.id;
      if (!targetId) return;
      const inputEl = inputRefs.current.get(targetId);
      const item = history.present.find((i) => i.id === targetId);
      if (!item || item.type !== 'expression') return;

      const start = inputEl?.selectionStart ?? item.latex.length;
      const end = inputEl?.selectionEnd ?? item.latex.length;
      const nextLatex = item.latex.slice(0, start) + text + item.latex.slice(end);
      handleUpdateExpression(targetId, { latex: nextLatex }, true);

      window.setTimeout(() => {
        const el = inputRefs.current.get(targetId);
        if (el) {
          el.focus();
          const pos = start + text.length + cursorOffset;
          el.setSelectionRange(pos, pos);
        }
      }, 10);
    },
    [focusedId, history.present, handleUpdateExpression]
  );

  const handleKeypadBackspace = useCallback(() => {
    const targetId = focusedId ?? history.present[0]?.id;
    if (!targetId) return;
    const inputEl = inputRefs.current.get(targetId);
    const item = history.present.find((i) => i.id === targetId);
    if (!item || item.type !== 'expression') return;

    const start = inputEl?.selectionStart ?? item.latex.length;
    const end = inputEl?.selectionEnd ?? item.latex.length;
    let nextLatex = item.latex;
    let nextPos = start;
    if (start !== end) {
      nextLatex = item.latex.slice(0, start) + item.latex.slice(end);
    } else if (start > 0) {
      nextLatex = item.latex.slice(0, start - 1) + item.latex.slice(start);
      nextPos = start - 1;
    }
    handleUpdateExpression(targetId, { latex: nextLatex }, true);
    window.setTimeout(() => {
      const el = inputRefs.current.get(targetId);
      if (el) {
        el.focus();
        el.setSelectionRange(nextPos, nextPos);
      }
    }, 10);
  }, [focusedId, history.present, handleUpdateExpression]);

  const handleKeypadMoveCursor = useCallback(
    (delta: number) => {
      const targetId = focusedId ?? history.present[0]?.id;
      if (!targetId) return;
      const el = inputRefs.current.get(targetId);
      if (!el) return;
      el.focus();
      const pos = Math.max(0, Math.min(el.value.length, (el.selectionStart ?? 0) + delta));
      el.setSelectionRange(pos, pos);
    },
    [focusedId, history.present]
  );

  // Save / Load / Presets / Share
  const buildSnapshot = useCallback((): WorkspaceSnapshot => {
    let ggbXml2d: string | undefined;
    let ggbXml3d: string | undefined;
    try {
      ggbXml2d = adaptersRef.current['2d']?.getApi().getXML();
    } catch {
      // ignore
    }
    try {
      ggbXml3d = adaptersRef.current['3d']?.getApi().getXML();
    } catch {
      // ignore
    }
    return {
      title,
      expressions: history.present,
      settings,
      viewMode,
      ggbXml2d,
      ggbXml3d,
    };
  }, [title, history.present, settings, viewMode]);

  const handleSaveGraph = useCallback(() => {
    const id = activeGraphId ?? nextExprId('graph');
    const snap = buildSnapshot();
    const record: SavedGraph = {
      id,
      title: snap.title,
      updatedAt: new Date().toISOString(),
      expressions: snap.expressions,
      settings: snap.settings,
      viewMode: snap.viewMode,
      ggbXml2d: snap.ggbXml2d,
      ggbXml3d: snap.ggbXml3d,
    };
    const nextList = upsertSavedGraph(record);
    setSavedGraphs(nextList);
    setActiveGraphId(id);
    setHasUnsavedChanges(false);
  }, [activeGraphId, buildSnapshot]);

  const handleLoadSnapshot = useCallback(
    (snap: WorkspaceSnapshot, graphId: string | null = null) => {
      setTitle(snap.title || 'Untitled Graph');
      setSettings({ ...DEFAULT_SETTINGS, ...(snap.settings ?? {}) });
      setViewMode(snap.viewMode === '3d' ? '3d' : '2d');
      setHistory(createHistory(snap.expressions));
      setActiveGraphId(graphId);
      setHasUnsavedChanges(false);
      setPendingXml2d(snap.ggbXml2d ?? null);
      setPendingXml3d(snap.ggbXml3d ?? null);
      if (snap.expressions[0]) {
        focusAndSelectInput(snap.expressions[0].id);
      }
    },
    [focusAndSelectInput]
  );

  const handleNewGraph = useCallback(() => {
    const blank = createExpressionItem({ type: 'expression', latex: '', color: DESMOS_COLORS[0].hex });
    handleLoadSnapshot(
      {
        title: 'Untitled Graph',
        expressions: [blank],
        settings: DEFAULT_SETTINGS,
        viewMode,
      },
      null
    );
  }, [handleLoadSnapshot, viewMode]);

  const handleSelectPreset = useCallback(
    (preset: ExamplePreset) => {
      const exprs = preset.expressions.map((e) => createExpressionItem(e));
      handleLoadSnapshot(
        {
          title: preset.title,
          expressions: exprs,
          settings: DEFAULT_SETTINGS,
          viewMode: preset.recommendedMode,
        },
        null
      );
    },
    [handleLoadSnapshot]
  );

  const handleExportPng = useCallback((): string | null => {
    const adapter = adaptersRef.current[viewMode];
    if (!adapter) return null;
    try {
      return adapter.getApi().getPNGBase64?.(2, false, 144) ?? null;
    } catch {
      return null;
    }
  }, [viewMode]);

  // Sidebar drag resizing on desktop
  const handleResizeStart = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = sidebarWidth;
    const onMove = (ev: MouseEvent) => {
      const next = Math.max(280, Math.min(560, startW + (ev.clientX - startX)));
      setSidebarWidth(next);
    };
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const shareUrl = useMemo(() => {
    if (!shareOpen) return '';
    return encodeShareUrl(buildSnapshot());
  }, [shareOpen, buildSnapshot]);

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-white text-neutral-900">
      {/* Shared Persistent Top Toolbar */}
      <TopBar
        title={title}
        onTitleChange={(t) => {
          setTitle(t);
          setHasUnsavedChanges(true);
        }}
        hasUnsavedChanges={hasUnsavedChanges}
        onSave={handleSaveGraph}
        onOpenSavedDrawer={() => setSavedDrawerOpen(true)}
        viewMode={viewMode}
        onViewModeChange={(m) => setViewMode(m)}
        canUndo={history.past.length > 0}
        canRedo={history.future.length > 0}
        onUndo={() => setHistory((h) => undoHistory(h))}
        onRedo={() => setHistory((h) => redoHistory(h))}
        onOpenExamples={() => setExamplesOpen(true)}
        onOpenShare={() => setShareOpen(true)}
        onOpenHelp={() => setHelpOpen(true)}
      />

      {/* Main Split Workspace: Left Expression Panel + Right Graph Viewport */}
      <div className="flex-1 min-h-0 flex flex-col-reverse md:flex-row relative overflow-hidden">
        {/* Mobile height wrapper when open */}
        {!sidebarCollapsed && (
          <div className="h-[48%] md:h-full w-full md:w-auto flex shrink-0">
            <ExpressionPanel
              expressions={expressionsWithFeedback}
              focusedId={focusedId}
              width={typeof window !== 'undefined' && window.innerWidth < 768 ? window.innerWidth : sidebarWidth}
              collapsed={sidebarCollapsed}
              keypadOpen={keypadOpen}
              canUndo={history.past.length > 0}
              canRedo={history.future.length > 0}
              onUndo={() => setHistory((h) => undoHistory(h))}
              onRedo={() => setHistory((h) => redoHistory(h))}
              onCollapse={() => setSidebarCollapsed(true)}
              onToggleKeypad={() => setKeypadOpen((o) => !o)}
              onFocusExpression={(id) => setFocusedId(id)}
              onRegisterInputRef={registerInputRef}
              onAddItem={handleAddItem}
              onUpdateExpression={handleUpdateExpression}
              onDeleteExpression={handleDeleteExpression}
              onDuplicateExpression={handleDuplicateExpression}
              onReorderExpression={handleReorderExpression}
              onAddSliderVars={handleAddSliderVars}
            />

            {/* Desktop Resizable Divider */}
            <div
              role="separator"
              aria-orientation="vertical"
              aria-label="Resize expression panel"
              onMouseDown={handleResizeStart}
              className="hidden md:block w-1 h-full bg-transparent hover:bg-blue-500/60 cursor-col-resize transition-colors shrink-0 z-30 -ml-0.5"
            />
          </div>
        )}

        {/* Graph Viewport (ONLY this panel switches between GeoGebra 2D and GeoGebra 3D) */}
        <GraphViewport
          viewMode={viewMode}
          expressions={history.present}
          settings={settings}
          sidebarCollapsed={sidebarCollapsed}
          pendingXml2d={pendingXml2d}
          pendingXml3d={pendingXml3d}
          onConsumePendingXml={(m) => {
            if (m === '2d') setPendingXml2d(null);
            else setPendingXml3d(null);
          }}
          onExpandSidebar={() => setSidebarCollapsed(false)}
          onSettingsChange={(next) => {
            setSettings(next);
            setHasUnsavedChanges(true);
          }}
          onFeedback={handleFeedback}
          onAdapterReady={handleAdapterReady}
          adaptersRef={adaptersRef}
        />
      </div>

      {/* Virtual Math Keypad */}
      <MathKeypad
        open={keypadOpen}
        onInsert={handleKeypadInsert}
        onBackspace={handleKeypadBackspace}
        onMoveCursor={handleKeypadMoveCursor}
        onEnter={() => handleAddItem('expression', focusedId)}
        onClose={() => setKeypadOpen(false)}
      />

      {/* Drawers & Modals */}
      <SavedGraphsDrawer
        open={savedDrawerOpen}
        savedGraphs={savedGraphs}
        activeGraphId={activeGraphId}
        onNewGraph={handleNewGraph}
        onLoadGraph={(g) => handleLoadSnapshot(g, g.id)}
        onDeleteGraph={(id) => setSavedGraphs(deleteSavedGraph(id))}
        onClose={() => setSavedDrawerOpen(false)}
      />

      <ExamplesModal
        open={examplesOpen}
        onSelectPreset={handleSelectPreset}
        onClose={() => setExamplesOpen(false)}
      />

      <ShareModal
        open={shareOpen}
        shareUrl={shareUrl}
        snapshot={buildSnapshot()}
        onExportPng={handleExportPng}
        onImportSnapshot={(snap) => handleLoadSnapshot(snap, null)}
        onClose={() => setShareOpen(false)}
      />

      <HelpModal open={helpOpen} onClose={() => setHelpOpen(false)} />
    </div>
  );
}
