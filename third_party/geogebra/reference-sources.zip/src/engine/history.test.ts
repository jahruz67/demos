import test from 'node:test';
import assert from 'node:assert/strict';
import { createHistory, pushHistory, undoHistory, redoHistory } from './history';
import { createExpressionItem } from './presets';

test('undo and redo restore expression snapshots deterministically', () => {
  const e1 = createExpressionItem({ id: '1', type: 'expression', latex: 'y=x' });
  const e2 = createExpressionItem({ id: '2', type: 'expression', latex: 'y=x^2' });

  let h = createHistory([e1]);
  h = pushHistory(h, [e1, e2]);
  assert.equal(h.present.length, 2);
  assert.equal(h.past.length, 1);

  h = undoHistory(h);
  assert.equal(h.present.length, 1);
  assert.equal(h.present[0].latex, 'y=x');
  assert.equal(h.future.length, 1);

  h = redoHistory(h);
  assert.equal(h.present.length, 2);
  assert.equal(h.present[1].latex, 'y=x^2');
});

test('non-recording updates (like slider animation ticks) update present without clearing future or bloating past', () => {
  const e1 = createExpressionItem({ id: '1', type: 'expression', latex: 'a=1' });
  const e2 = createExpressionItem({ id: '1', type: 'expression', latex: 'a=2' });

  let h = createHistory([e1]);
  h = pushHistory(h, [e2], false);
  assert.equal(h.past.length, 0);
  assert.equal(h.present[0].latex, 'a=2');
});
