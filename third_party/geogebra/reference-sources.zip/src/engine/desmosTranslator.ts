import { ViewMode } from '../types/calculator';

export type TranslatedKind =
  | 'empty'
  | 'slider'
  | 'scalar'
  | 'function_def'
  | 'explicit_2d'
  | 'explicit_3d'
  | 'implicit_2d'
  | 'implicit_3d'
  | 'polar'
  | 'parametric_2d'
  | 'parametric_3d'
  | 'point_2d'
  | 'point_3d'
  | 'inequality_2d'
  | 'inequality_3d'
  | 'list'
  | 'calculus';

export interface TranslationResult {
  ok: boolean;
  kind: TranslatedKind;
  ggbCommand: string;
  ggbLabel?: string; // explicit symbol name if user defined one (e.g. "a", "f", "L", "A")
  displayLatex: string;
  undefinedVars: string[];
  isSlider: boolean;
  sliderValue?: number;
  isNumericEval: boolean;
  supports2D: boolean;
  supports3D: boolean;
  error?: string;
}

const BUILTIN_FUNCTIONS = new Set([
  'sin',
  'cos',
  'tan',
  'csc',
  'sec',
  'cot',
  'asin',
  'acos',
  'atan',
  'arcsin',
  'arccos',
  'arctan',
  'sinh',
  'cosh',
  'tanh',
  'asinh',
  'acosh',
  'atanh',
  'ln',
  'log',
  'log10',
  'log2',
  'exp',
  'sqrt',
  'cbrt',
  'abs',
  'floor',
  'ceil',
  'round',
  'sign',
  'sgn',
  'mod',
  'min',
  'max',
  'mean',
  'median',
  'stdev',
  'total',
  'length',
  'distance',
  'nCr',
  'nPr',
  'sum',
  'prod',
  'integral',
  'derivative',
  'If',
  'Sequence',
  'Curve',
  'Derivative',
  'Integral',
  'Sum',
  'Product',
]);

const RESERVED_COORDS = new Set(['x', 'y', 'z', 'r', 't', 'theta', 'pi', 'e']);

type TokenType =
  | 'num'
  | 'ident'
  | 'op'
  | 'lparen'
  | 'rparen'
  | 'lbrace'
  | 'rbrace'
  | 'lbracket'
  | 'rbracket'
  | 'comma'
  | 'colon'
  | 'range';

interface Token {
  type: TokenType;
  value: string;
}

/**
 * Normalize Unicode symbols and common LaTeX constructs into canonical ASCII math syntax.
 */
export function preprocessLatex(raw: string): string {
  let s = raw.trim();
  if (!s) return '';

  // Unicode operators & Greek shortcuts
  s = s
    .replace(/π/g, 'pi')
    .replace(/θ/g, 'theta')
    .replace(/≤/g, '<=')
    .replace(/≥/g, '>=')
    .replace(/≠/g, '!=')
    .replace(/·/g, '*')
    .replace(/×/g, '*')
    .replace(/÷/g, '/')
    .replace(/−/g, '-')
    .replace(/²/g, '^2')
    .replace(/³/g, '^3')
    .replace(/√/g, 'sqrt');

  // Remove \left and \right wrappers
  s = s.replace(/\\left\s*\|/g, '|').replace(/\\right\s*\|/g, '|');
  s = s.replace(/\\left\s*/g, '').replace(/\\right\s*/g, '');

  // LaTeX operators & symbols
  s = s
    .replace(/\\cdot/g, '*')
    .replace(/\\times/g, '*')
    .replace(/\\div/g, '/')
    .replace(/\\le\b/g, '<=')
    .replace(/\\leq\b/g, '<=')
    .replace(/\\ge\b/g, '>=')
    .replace(/\\geq\b/g, '>=')
    .replace(/\\ne\b/g, '!=')
    .replace(/\\neq\b/g, '!=')
    .replace(/\\pi\b/g, 'pi')
    .replace(/\\theta\b/g, 'theta')
    .replace(/\\arcsin\b/g, 'arcsin')
    .replace(/\\arccos\b/g, 'arccos')
    .replace(/\\arctan\b/g, 'arctan')
    .replace(/\\sinh\b/g, 'sinh')
    .replace(/\\cosh\b/g, 'cosh')
    .replace(/\\tanh\b/g, 'tanh')
    .replace(/\\sin\b/g, 'sin')
    .replace(/\\cos\b/g, 'cos')
    .replace(/\\tan\b/g, 'tan')
    .replace(/\\csc\b/g, 'csc')
    .replace(/\\sec\b/g, 'sec')
    .replace(/\\cot\b/g, 'cot')
    .replace(/\\ln\b/g, 'ln')
    .replace(/\\log\b/g, 'log')
    .replace(/\\exp\b/g, 'exp');

  // Handle \frac{a}{b} (supports nested braces)
  s = replaceLatexFrac(s);
  // Handle \sqrt{a} and \sqrt[n]{a}
  s = replaceLatexSqrt(s);
  // Handle \sum_{i=a}^{b} expr and \prod_{i=a}^{b} expr
  s = replaceLatexBigOp(s, 'sum');
  s = replaceLatexBigOp(s, 'prod');
  // Handle \int_{a}^{b} expr dx
  s = replaceLatexIntegral(s);
  // Handle |...| absolute value bars
  s = replaceAbsBars(s);

  return s.trim();
}

function readBraced(str: string, startIdx: number): { content: string; endIdx: number } | null {
  let i = startIdx;
  while (i < str.length && str[i] === ' ') i++;
  if (str[i] !== '{') return null;
  let depth = 0;
  const contentStart = i + 1;
  for (; i < str.length; i++) {
    if (str[i] === '{') depth++;
    else if (str[i] === '}') {
      depth--;
      if (depth === 0) {
        return { content: str.slice(contentStart, i), endIdx: i + 1 };
      }
    }
  }
  return null;
}

function replaceLatexFrac(input: string): string {
  let s = input;
  let safety = 0;
  while (s.includes('\\frac') && safety++ < 25) {
    const idx = s.indexOf('\\frac');
    const num = readBraced(s, idx + 5);
    if (!num) break;
    const den = readBraced(s, num.endIdx);
    if (!den) break;
    // Check derivative shorthand \frac{d}{dx}(...) or \frac{d}{dx} ...
    if (num.content.trim() === 'd' && /^d[a-zA-Z]$/.test(den.content.trim())) {
      const v = den.content.trim()[1];
      const rest = s.slice(den.endIdx).trim();
      const paren = rest.startsWith('(') ? readBalancedParen(rest, 0) : null;
      if (paren) {
        s =
          s.slice(0, idx) +
          `derivative(${paren.content}, ${v})` +
          rest.slice(paren.endIdx);
        continue;
      }
    }
    s = s.slice(0, idx) + `((${num.content})/(${den.content}))` + s.slice(den.endIdx);
  }
  return s;
}

function readBalancedParen(str: string, startIdx: number): { content: string; endIdx: number } | null {
  if (str[startIdx] !== '(') return null;
  let depth = 0;
  for (let i = startIdx; i < str.length; i++) {
    if (str[i] === '(') depth++;
    else if (str[i] === ')') {
      depth--;
      if (depth === 0) {
        return { content: str.slice(startIdx + 1, i), endIdx: i + 1 };
      }
    }
  }
  return null;
}

function replaceLatexSqrt(input: string): string {
  let s = input;
  let safety = 0;
  while (s.includes('\\sqrt') && safety++ < 25) {
    const idx = s.indexOf('\\sqrt');
    let cursor = idx + 5;
    while (cursor < s.length && s[cursor] === ' ') cursor++;
    let rootN: string | null = null;
    if (s[cursor] === '[') {
      const endBracket = s.indexOf(']', cursor + 1);
      if (endBracket !== -1) {
        rootN = s.slice(cursor + 1, endBracket);
        cursor = endBracket + 1;
      }
    }
    const arg = readBraced(s, cursor);
    if (!arg) break;
    const replacement = rootN ? `((${arg.content})^(1/(${rootN})))` : `sqrt(${arg.content})`;
    s = s.slice(0, idx) + replacement + s.slice(arg.endIdx);
  }
  return s;
}

function replaceLatexBigOp(input: string, opName: 'sum' | 'prod'): string {
  let s = input;
  const cmd = `\\${opName}`;
  let safety = 0;
  while (s.includes(cmd) && safety++ < 10) {
    const idx = s.indexOf(cmd);
    let cursor = idx + cmd.length;
    while (cursor < s.length && s[cursor] === ' ') cursor++;
    if (s[cursor] !== '_') break;
    cursor++;
    const lower = readBraced(s, cursor);
    if (!lower) break;
    cursor = lower.endIdx;
    while (cursor < s.length && s[cursor] === ' ') cursor++;
    if (s[cursor] !== '^') break;
    cursor++;
    const upper = readBraced(s, cursor);
    if (!upper) break;
    const body = s.slice(upper.endIdx).trim();
    s = s.slice(0, idx) + `${opName}(${lower.content}, ${upper.content}, ${body})`;
  }
  return s;
}

function replaceLatexIntegral(input: string): string {
  let s = input;
  const cmd = '\\int';
  let safety = 0;
  while (s.includes(cmd) && safety++ < 10) {
    const idx = s.indexOf(cmd);
    let cursor = idx + cmd.length;
    while (cursor < s.length && s[cursor] === ' ') cursor++;
    let lowerStr = '';
    let upperStr = '';
    if (s[cursor] === '_') {
      const lower = readBraced(s, cursor + 1);
      if (lower) {
        lowerStr = lower.content;
        cursor = lower.endIdx;
        while (cursor < s.length && s[cursor] === ' ') cursor++;
      }
    }
    if (s[cursor] === '^') {
      const upper = readBraced(s, cursor + 1);
      if (upper) {
        upperStr = upper.content;
        cursor = upper.endIdx;
      }
    }
    const rest = s.slice(cursor).trim();
    const diffMatch = rest.match(/^(.*?)\s*d([a-zA-Z])\s*$/);
    if (diffMatch) {
      const integrand = diffMatch[1].trim();
      const varName = diffMatch[2];
      if (lowerStr && upperStr) {
        s = s.slice(0, idx) + `integral(${integrand}, ${varName}, ${lowerStr}, ${upperStr})`;
      } else {
        s = s.slice(0, idx) + `integral(${integrand}, ${varName})`;
      }
    } else {
      break;
    }
  }
  return s;
}

function replaceAbsBars(input: string): string {
  if (!input.includes('|')) return input;
  let out = '';
  let open = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (ch === '|') {
      if (!open) {
        out += 'abs(';
        open = true;
      } else {
        out += ')';
        open = false;
      }
    } else {
      out += ch;
    }
  }
  return open ? input : out;
}

/**
 * Tokenize normalized ASCII math string and insert Desmos-style implicit multiplication.
 */
export function tokenizeMath(
  input: string,
  knownSymbols: Set<string> = new Set(),
  knownFunctions: Set<string> = new Set()
): Token[] {
  const rawTokens: Token[] = [];
  let i = 0;

  while (i < input.length) {
    const ch = input[i];
    if (/\s/.test(ch)) {
      i++;
      continue;
    }
    // Two-char operators
    const two = input.slice(i, i + 2);
    if (two === '<=' || two === '>=' || two === '!=') {
      rawTokens.push({ type: 'op', value: two });
      i += 2;
      continue;
    }
    if (two === '..') {
      rawTokens.push({ type: 'range', value: '..' });
      i += 2;
      continue;
    }

    // Numbers (including decimals like .5 or 12.34)
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(input[i + 1] ?? ''))) {
      let j = i;
      let sawDot = false;
      while (j < input.length) {
        if (/[0-9]/.test(input[j])) j++;
        else if (input[j] === '.' && !sawDot && input[j + 1] !== '.') {
          sawDot = true;
          j++;
        } else break;
      }
      rawTokens.push({ type: 'num', value: input.slice(i, j) });
      i = j;
      continue;
    }

    // Identifiers (letters, underscores, trailing digits for subscripts like x_1 or x1)
    if (/[a-zA-Z]/.test(ch)) {
      let j = i + 1;
      while (j < input.length && /[a-zA-Z0-9_]/.test(input[j])) j++;
      const word = input.slice(i, j);
      const isDiffDenom =
        /^d[a-zA-Z]$/.test(word) &&
        rawTokens[rawTokens.length - 1]?.value === '/' &&
        rawTokens[rawTokens.length - 2]?.value === 'd';
      // Split unknown multi-letter identifiers unless reserved, subscripted, or user-defined
      if (
        !isDiffDenom &&
        word.length > 1 &&
        !word.includes('_') &&
        !BUILTIN_FUNCTIONS.has(word) &&
        !RESERVED_COORDS.has(word) &&
        !knownSymbols.has(word) &&
        !knownFunctions.has(word) &&
        word !== 'true' &&
        word !== 'false' &&
        word !== 'd'
      ) {
        // Attempt greedy split on known prefixes/suffixes (like "sinx" -> "sin", "x" or "2pi" -> "pi", or "mx" -> "m", "x")
        const split = splitUnknownIdentifier(word, knownSymbols, knownFunctions);
        for (const part of split) {
          rawTokens.push({ type: 'ident', value: part });
        }
      } else {
        rawTokens.push({ type: 'ident', value: word });
      }
      i = j;
      continue;
    }

    // Single-char delimiters & ops
    if (ch === '(') rawTokens.push({ type: 'lparen', value: '(' });
    else if (ch === ')') rawTokens.push({ type: 'rparen', value: ')' });
    else if (ch === '{') rawTokens.push({ type: 'lbrace', value: '{' });
    else if (ch === '}') rawTokens.push({ type: 'rbrace', value: '}' });
    else if (ch === '[') rawTokens.push({ type: 'lbracket', value: '[' });
    else if (ch === ']') rawTokens.push({ type: 'rbracket', value: ']' });
    else if (ch === ',') rawTokens.push({ type: 'comma', value: ',' });
    else if (ch === ':') rawTokens.push({ type: 'colon', value: ':' });
    else if ("+-*/^=<>'".includes(ch)) rawTokens.push({ type: 'op', value: ch });
    else {
      throw new Error(`Unexpected character "${ch}"`);
    }
    i++;
  }

  // Insert implicit multiplication tokens
  const withMul: Token[] = [];
  for (let idx = 0; idx < rawTokens.length; idx++) {
    const curr = rawTokens[idx];
    const prev = withMul[withMul.length - 1];

    if (prev && shouldInsertMultiply(prev, curr, knownFunctions)) {
      withMul.push({ type: 'op', value: '*' });
    }
    withMul.push(curr);
  }

  return withMul;
}

function splitUnknownIdentifier(
  word: string,
  knownSymbols: Set<string>,
  knownFunctions: Set<string>
): string[] {
  const parts: string[] = [];
  let rem = word;
  const specialWords = [
    ...Array.from(BUILTIN_FUNCTIONS),
    'theta',
    'pi',
    ...Array.from(knownSymbols),
    ...Array.from(knownFunctions),
  ].sort((a, b) => b.length - a.length);

  while (rem.length > 0) {
    const match = specialWords.find((w) => rem.startsWith(w) && w.length > 1);
    if (match) {
      parts.push(match);
      rem = rem.slice(match.length);
    } else if (/^[a-zA-Z][0-9]+/.test(rem)) {
      const m = rem.match(/^[a-zA-Z][0-9]+/)!;
      parts.push(m[0]);
      rem = rem.slice(m[0].length);
    } else {
      parts.push(rem[0]);
      rem = rem.slice(1);
    }
  }
  return parts;
}

function shouldInsertMultiply(prev: Token, curr: Token, knownFunctions: Set<string>): boolean {
  const prevIsValueEnd =
    prev.type === 'num' ||
    prev.type === 'rparen' ||
    prev.type === 'rbracket' ||
    prev.type === 'ident' ||
    (prev.type === 'op' && prev.value === "'");

  if (!prevIsValueEnd) return false;

  const currIsValueStart =
    curr.type === 'num' ||
    curr.type === 'ident' ||
    curr.type === 'lparen' ||
    curr.type === 'lbracket';

  if (!currIsValueStart) return false;

  // Function call: f(...) or sin(...) or differential d/dx(...)
  if (prev.type === 'ident' && curr.type === 'lparen') {
    if (BUILTIN_FUNCTIONS.has(prev.value) || knownFunctions.has(prev.value) || /^d[a-zA-Z]$/.test(prev.value)) {
      return false;
    }
    // Single letters not in RESERVED_COORDS could be user function calls in lhs `f(x) = ...`
    // handled at top level, so only auto-insert * for RESERVED_COORDS like x(x+1) or pi(2)
    if (RESERVED_COORDS.has(prev.value)) return true;
    return false;
  }

  // Prime derivative call: f'(x)
  if (prev.type === 'op' && prev.value === "'" && curr.type === 'lparen') {
    return false;
  }

  // Indexing a list: L[1]
  if (prev.type === 'ident' && curr.type === 'lbracket') {
    return false;
  }

  return true;
}

function tokensToString(tokens: Token[]): string {
  return tokens
    .map((t, i) => {
      if (t.type === 'comma') return ', ';
      if (t.type === 'colon') return ': ';
      if (t.type === 'op' && ['=', '<', '>', '<=', '>=', '!='].includes(t.value)) {
        return ` ${t.value} `;
      }
      if (t.type === 'op' && (t.value === '+' || t.value === '-')) {
        const prev = tokens[i - 1];
        if (!prev || prev.type === 'lparen' || prev.type === 'comma' || prev.type === 'op') {
          return t.value;
        }
        return ` ${t.value} `;
      }
      return t.value;
    })
    .join('');
}

/**
 * Split top-level tokens by a target token predicate (outside parens/brackets/braces).
 */
function splitTopLevel(tokens: Token[], match: (t: Token) => boolean): Token[][] {
  const parts: Token[][] = [];
  let current: Token[] = [];
  let paren = 0;
  let bracket = 0;
  let brace = 0;

  for (const t of tokens) {
    if (t.type === 'lparen') paren++;
    else if (t.type === 'rparen') paren--;
    else if (t.type === 'lbracket') bracket++;
    else if (t.type === 'rbracket') bracket--;
    else if (t.type === 'lbrace') brace++;
    else if (t.type === 'rbrace') brace--;

    if (paren === 0 && bracket === 0 && brace === 0 && match(t)) {
      parts.push(current);
      current = [];
    } else {
      current.push(t);
    }
  }
  parts.push(current);
  return parts;
}

function checkBalanced(tokens: Token[]): string | null {
  let paren = 0;
  let bracket = 0;
  let brace = 0;
  for (const t of tokens) {
    if (t.type === 'lparen') paren++;
    else if (t.type === 'rparen') paren--;
    else if (t.type === 'lbracket') bracket++;
    else if (t.type === 'rbracket') bracket--;
    else if (t.type === 'lbrace') brace++;
    else if (t.type === 'rbrace') brace--;
    if (paren < 0) return 'Unmatched closing parenthesis ")"';
    if (bracket < 0) return 'Unmatched closing bracket "]"';
    if (brace < 0) return 'Unmatched closing brace "}"';
  }
  if (paren > 0) return 'Missing closing parenthesis ")"';
  if (bracket > 0) return 'Missing closing bracket "]"';
  if (brace > 0) return 'Missing closing brace "}"';
  return null;
}

/**
 * Extract trailing `{condition}` or piecewise `{c1: e1, c2: e2, ...}` from tokens.
 */
function extractBraces(tokens: Token[]): { main: Token[]; restrictions: Token[][] } {
  const main: Token[] = [];
  const restrictions: Token[][] = [];
  let i = 0;
  while (i < tokens.length) {
    if (tokens[i].type === 'lbrace') {
      let depth = 1;
      const start = i + 1;
      i++;
      while (i < tokens.length && depth > 0) {
        if (tokens[i].type === 'lbrace') depth++;
        else if (tokens[i].type === 'rbrace') depth--;
        i++;
      }
      const inside = tokens.slice(start, i - 1);
      // Check if it's a piecewise expression (`:` inside) vs domain restriction
      const hasColon = inside.some((t) => t.type === 'colon');
      if (hasColon && main.length === 0) {
        // Standalone piecewise `{c1: e1, e2}`
        main.push({ type: 'lbrace', value: '{' }, ...inside, { type: 'rbrace', value: '}' });
      } else if (hasColon) {
        main.push({ type: 'lbrace', value: '{' }, ...inside, { type: 'rbrace', value: '}' });
      } else {
        restrictions.push(inside);
      }
    } else {
      main.push(tokens[i]);
      i++;
    }
  }
  return { main, restrictions };
}

/**
 * Convert chained inequalities like `-2 <= x <= 3` into `(-2 <= x) && (x <= 3)`.
 */
function expandChainedComparisons(tokens: Token[]): Token[] {
  const cmpOps = new Set(['<', '>', '<=', '>=', '!=']);
  // Find top-level comparison operators
  const cmpIndices: number[] = [];
  let p = 0;
  let b = 0;
  let c = 0;
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (t.type === 'lparen') p++;
    else if (t.type === 'rparen') p--;
    else if (t.type === 'lbracket') b++;
    else if (t.type === 'rbracket') b--;
    else if (t.type === 'lbrace') c++;
    else if (t.type === 'rbrace') c--;
    else if (p === 0 && b === 0 && c === 0 && t.type === 'op' && cmpOps.has(t.value)) {
      cmpIndices.push(i);
    }
  }
  if (cmpIndices.length <= 1) return tokens;

  const segments: Token[][] = [];
  let prev = 0;
  for (const idx of cmpIndices) {
    segments.push(tokens.slice(prev, idx));
    prev = idx + 1;
  }
  segments.push(tokens.slice(prev));

  const out: Token[] = [];
  for (let k = 0; k < cmpIndices.length; k++) {
    if (k > 0) out.push({ type: 'ident', value: '&&' });
    out.push({ type: 'lparen', value: '(' });
    out.push(...segments[k]);
    out.push(tokens[cmpIndices[k]]);
    out.push(...segments[k + 1]);
    out.push({ type: 'rparen', value: ')' });
  }
  return out;
}

/**
 * Transform Desmos expression tokens into GeoGebra syntax string:
 * - `[1, 2, 3]` -> `{1, 2, 3}`
 * - `[1..10]` -> `Sequence(k_, k_, 1, 10)`
 * - `{c1: e1, c2: e2, fallback}` -> `If(c1, e1, If(c2, e2, fallback))`
 * - `d/dx(expr)` -> `Derivative(expr, x)`
 * - `sum(n=1, 5, expr)` -> `Sum(Sequence(expr, n, 1, 5))`
 * - `prod(n=1, 5, expr)` -> `Product(Sequence(expr, n, 1, 5))`
 * - `integral(expr, x, a, b)` -> `Integral(expr, a, b)`
 * - `arcsin` -> `asin`, `log` -> `log10` (Desmos log is base 10)
 */
function compileExpressionTokens(tokens: Token[]): string {
  // Handle piecewise `{c1: e1, c2: e2, ...}`
  const processed = transformSpecialCalls(tokens);
  const parts: string[] = [];

  for (let i = 0; i < processed.length; i++) {
    const t = processed[i];
    if (t.type === 'lbrace') {
      // Find matching rbrace
      let depth = 1;
      const start = i + 1;
      i++;
      while (i < processed.length && depth > 0) {
        if (processed[i].type === 'lbrace') depth++;
        else if (processed[i].type === 'rbrace') depth--;
        i++;
      }
      const inside = processed.slice(start, i - 1);
      i--; // loop will increment
      const branches = splitTopLevel(inside, (tok) => tok.type === 'comma');
      parts.push(buildPiecewiseIf(branches));
      continue;
    }

    if (t.type === 'lbracket') {
      // List `[1, 2, 3]` or range `[1..10]`
      let depth = 1;
      const start = i + 1;
      i++;
      while (i < processed.length && depth > 0) {
        if (processed[i].type === 'lbracket') depth++;
        else if (processed[i].type === 'rbracket') depth--;
        i++;
      }
      const inside = processed.slice(start, i - 1);
      i--;
      const rangeParts = splitTopLevel(inside, (tok) => tok.type === 'range');
      if (rangeParts.length === 2) {
        const startExpr = compileExpressionTokens(rangeParts[0]);
        const endExpr = compileExpressionTokens(rangeParts[1]);
        parts.push(`Sequence(_k, _k, ${startExpr}, ${endExpr})`);
      } else {
        const listItems = splitTopLevel(inside, (tok) => tok.type === 'comma').map((item) =>
          compileExpressionTokens(item)
        );
        parts.push(`{${listItems.join(', ')}}`);
      }
      continue;
    }

    if (t.type === 'ident') {
      if (t.value === '&&') {
        parts.push(' && ');
      } else {
        parts.push(mapFunctionName(t.value));
      }
      continue;
    }

    if (t.type === 'op' && ['<', '>', '<=', '>=', '!='].includes(t.value)) {
      parts.push(` ${t.value} `);
      continue;
    }

    parts.push(t.value);
  }

  return parts.join('');
}

function mapFunctionName(name: string): string {
  switch (name) {
    case 'arcsin':
      return 'asin';
    case 'arccos':
      return 'acos';
    case 'arctan':
      return 'atan';
    case 'log':
      return 'log10';
    case 'theta':
      return 'θ';
    case 'pi':
      return 'π';
    case 'sgn':
      return 'sign';
    default:
      return name;
  }
}

function buildPiecewiseIf(branches: Token[][]): string {
  const parsed = branches.map((b) => splitTopLevel(b, (tok) => tok.type === 'colon'));
  // Walk backwards to build nested If(cond, val, elseVal)
  let acc = '';
  for (let i = parsed.length - 1; i >= 0; i--) {
    const pair = parsed[i];
    if (pair.length === 1) {
      // Fallback value without colon
      acc = compileExpressionTokens(pair[0]);
    } else if (pair.length >= 2) {
      const cond = compileExpressionTokens(expandChainedComparisons(pair[0]));
      const val = compileExpressionTokens(pair[1]);
      acc = acc ? `If(${cond}, ${val}, ${acc})` : `If(${cond}, ${val})`;
    }
  }
  return acc || '0';
}

function transformSpecialCalls(tokens: Token[]): Token[] {
  const out: Token[] = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    // Handle `d/dx(expr)` pattern
    if (
      t.type === 'ident' &&
      t.value === 'd' &&
      tokens[i + 1]?.type === 'op' &&
      tokens[i + 1]?.value === '/' &&
      tokens[i + 2]?.type === 'ident' &&
      /^d[a-zA-Z]$/.test(tokens[i + 2].value) &&
      tokens[i + 3]?.type === 'lparen'
    ) {
      const v = tokens[i + 2].value[1];
      const inner = readParenTokens(tokens, i + 3);
      if (inner) {
        const innerStr = compileExpressionTokens(inner.tokens);
        out.push({ type: 'ident', value: `Derivative(${innerStr}, ${v})` });
        i = inner.endIdx - 1;
        continue;
      }
    }

    // Handle `sum(n=1, 5, expr)`, `prod(n=1, 5, expr)`, `integral(expr, x, a, b)`, `derivative(expr, x)`
    if (
      t.type === 'ident' &&
      ['sum', 'prod', 'integral', 'derivative'].includes(t.value) &&
      tokens[i + 1]?.type === 'lparen'
    ) {
      const inner = readParenTokens(tokens, i + 1);
      if (inner) {
        const args = splitTopLevel(inner.tokens, (tok) => tok.type === 'comma');
        if ((t.value === 'sum' || t.value === 'prod') && args.length >= 3) {
          const eqParts = splitTopLevel(args[0], (tok) => tok.type === 'op' && tok.value === '=');
          if (eqParts.length === 2 && eqParts[0][0]?.type === 'ident') {
            const iterVar = eqParts[0][0].value;
            const lower = compileExpressionTokens(eqParts[1]);
            const upper = compileExpressionTokens(args[1]);
            const body = compileExpressionTokens(args.slice(2).flat());
            const ggbOp = t.value === 'sum' ? 'Sum' : 'Product';
            out.push({
              type: 'ident',
              value: `${ggbOp}(Sequence(${body}, ${iterVar}, ${lower}, ${upper}))`,
            });
            i = inner.endIdx - 1;
            continue;
          }
        }
        if (t.value === 'integral') {
          if (args.length >= 4) {
            const expr = compileExpressionTokens(args[0]);
            const a = compileExpressionTokens(args[2]);
            const b = compileExpressionTokens(args[3]);
            out.push({ type: 'ident', value: `Integral(${expr}, ${a}, ${b})` });
            i = inner.endIdx - 1;
            continue;
          } else if (args.length >= 1) {
            const expr = compileExpressionTokens(args[0]);
            out.push({ type: 'ident', value: `Integral(${expr})` });
            i = inner.endIdx - 1;
            continue;
          }
        }
        if (t.value === 'derivative' && args.length >= 1) {
          const expr = compileExpressionTokens(args[0]);
          const v = args[1] ? compileExpressionTokens(args[1]) : 'x';
          out.push({ type: 'ident', value: `Derivative(${expr}, ${v})` });
          i = inner.endIdx - 1;
          continue;
        }
      }
    }

    // Handle `f'(x)` -> `Derivative(f)`
    if (
      t.type === 'ident' &&
      tokens[i + 1]?.type === 'op' &&
      tokens[i + 1].value === "'" &&
      tokens[i + 2]?.type === 'lparen'
    ) {
      const inner = readParenTokens(tokens, i + 2);
      if (inner) {
        out.push({ type: 'ident', value: `${t.value}'(${compileExpressionTokens(inner.tokens)})` });
        i = inner.endIdx - 1;
        continue;
      }
    }

    out.push(t);
  }
  return out;
}

function readParenTokens(tokens: Token[], startIdx: number): { tokens: Token[]; endIdx: number } | null {
  if (tokens[startIdx]?.type !== 'lparen') return null;
  let depth = 0;
  for (let i = startIdx; i < tokens.length; i++) {
    if (tokens[i].type === 'lparen') depth++;
    else if (tokens[i].type === 'rparen') {
      depth--;
      if (depth === 0) {
        return { tokens: tokens.slice(startIdx + 1, i), endIdx: i + 1 };
      }
    }
  }
  return null;
}

/**
 * Extract undefined scalar/parameter identifiers from tokens.
 */
function findUndefinedVariables(
  tokens: Token[],
  definedSymbols: Set<string>,
  localBoundVars: Set<string> = new Set()
): string[] {
  const found = new Set<string>();

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (t.type !== 'ident') continue;
    const name = t.value;

    // Bound variable in sum/prod `sum(n=1, ...)`
    if (
      (name === 'sum' || name === 'prod') &&
      tokens[i + 1]?.type === 'lparen' &&
      tokens[i + 2]?.type === 'ident'
    ) {
      localBoundVars.add(tokens[i + 2].value);
    }
    if (name === 'integral' && tokens[i + 1]?.type === 'lparen') {
      const inner = readParenTokens(tokens, i + 1);
      if (inner) {
        const args = splitTopLevel(inner.tokens, (tok) => tok.type === 'comma');
        if (args[1]?.[0]?.type === 'ident') localBoundVars.add(args[1][0].value);
      }
    }
    if (name === 'd' && tokens[i + 1]?.value === '/' && tokens[i + 2]?.type === 'ident') {
      i += 2;
      continue;
    }

    if (
      BUILTIN_FUNCTIONS.has(name) ||
      RESERVED_COORDS.has(name) ||
      definedSymbols.has(name) ||
      localBoundVars.has(name) ||
      name === 'true' ||
      name === 'false' ||
      name === '&&' ||
      name === '||'
    ) {
      continue;
    }
    // Function call `f(x)` where f isn't defined yet shouldn't be treated as scalar slider
    if (tokens[i + 1]?.type === 'lparen') continue;

    found.add(name);
  }
  return Array.from(found);
}

function extractBoundsForVar(
  restrictions: Token[][],
  varNames: string[]
): { min: string; max: string; remainingRestrictions: Token[][] } {
  let min = varNames.includes('theta') ? '0' : '-10';
  let max = varNames.includes('theta') ? '2*π' : '10';
  const remaining: Token[][] = [];

  for (const r of restrictions) {
    const str = tokensToString(r).replace(/\s+/g, '');
    // Match `a<=t<=b` or `a<t<b`
    const chained = str.match(/^(.+?)(<=|<)(t|theta)(<=|<)(.+)$/);
    if (chained && varNames.includes(chained[3])) {
      min = compileExpressionTokens(tokenizeMath(chained[1]));
      max = compileExpressionTokens(tokenizeMath(chained[5]));
      continue;
    }
    remaining.push(r);
  }

  return { min, max, remainingRestrictions: remaining };
}

/**
 * Convert ASCII/normalized expression into clean KaTeX LaTeX for display.
 */
export function toDisplayLatex(raw: string): string {
  if (!raw.trim()) return '';
  let s = raw.trim();
  // Convert basic tokens to clean KaTeX
  s = s
    .replace(/<=/g, ' \\le ')
    .replace(/>=/g, ' \\ge ')
    .replace(/!=/g, ' \\ne ')
    .replace(/\bpi\b/g, '\\pi ')
    .replace(/\btheta\b/g, '\\theta ')
    .replace(/\*/g, ' \\cdot ')
    .replace(/\bsqrt\(([^()]+)\)/g, '\\sqrt{$1}')
    .replace(/\b(sin|cos|tan|csc|sec|cot|arcsin|arccos|arctan|ln|log)\b/g, '\\$1');
  return s;
}

export interface TranslateOptions {
  definedSymbols?: Set<string>;
  definedFunctions?: Set<string>;
  viewMode?: ViewMode;
  internalLabel?: string; // safe prefix for unnamed objects e.g. "d1"
}

export function translateDesmosExpression(
  rawInput: string,
  options: TranslateOptions = {}
): TranslationResult {
  const {
    definedSymbols = new Set<string>(),
    definedFunctions = new Set<string>(),
    internalLabel = 'g1',
  } = options;

  const trimmed = rawInput.trim();
  if (!trimmed) {
    return {
      ok: true,
      kind: 'empty',
      ggbCommand: '',
      displayLatex: '',
      undefinedVars: [],
      isSlider: false,
      isNumericEval: false,
      supports2D: true,
      supports3D: true,
    };
  }

  try {
    const normalized = preprocessLatex(trimmed);
    const tokens = tokenizeMath(normalized, definedSymbols, definedFunctions);

    const balanceErr = checkBalanced(tokens);
    if (balanceErr) {
      return {
        ok: false,
        kind: 'empty',
        ggbCommand: '',
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars: [],
        isSlider: false,
        isNumericEval: false,
        supports2D: true,
        supports3D: true,
        error: balanceErr,
      };
    }

    const { main, restrictions } = extractBraces(tokens);
    if (main.length === 0) {
      return {
        ok: false,
        kind: 'empty',
        ggbCommand: '',
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars: [],
        isSlider: false,
        isNumericEval: false,
        supports2D: true,
        supports3D: true,
        error: 'Expression cannot consist solely of a condition',
      };
    }

    const combinedRestrictionStr =
      restrictions.length > 0
        ? restrictions
            .map((r) => compileExpressionTokens(expandChainedComparisons(r)))
            .join(' && ')
        : '';

    const idents = new Set(main.filter((t) => t.type === 'ident').map((t) => t.value));
    const hasX = idents.has('x');
    const hasY = idents.has('y');
    const hasZ = idents.has('z');
    const hasT = idents.has('t');
    const hasTheta = idents.has('theta');

    // Check top-level comparison/inequality (`<`, `>`, `<=`, `>=`)
    const hasInequality = main.some(
      (t, idx) =>
        t.type === 'op' &&
        ['<', '>', '<=', '>='].includes(t.value) &&
        isTopLevelIndex(main, idx)
    );

    if (hasInequality) {
      const expanded = expandChainedComparisons(main);
      const ineqCmd = compileExpressionTokens(expanded);
      const fullCmd = combinedRestrictionStr ? `(${ineqCmd}) && (${combinedRestrictionStr})` : ineqCmd;
      const undefinedVars = findUndefinedVariables(tokens, definedSymbols);
      return {
        ok: true,
        kind: hasZ ? 'inequality_3d' : 'inequality_2d',
        ggbCommand: `${internalLabel}: ${fullCmd}`,
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars,
        isSlider: false,
        isNumericEval: false,
        supports2D: !hasZ,
        supports3D: true,
      };
    }

    // Check top-level `=`
    const eqParts = splitTopLevel(main, (t) => t.type === 'op' && t.value === '=');

    if (eqParts.length > 2) {
      return {
        ok: false,
        kind: 'empty',
        ggbCommand: '',
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars: [],
        isSlider: false,
        isNumericEval: false,
        supports2D: true,
        supports3D: true,
        error: 'Multiple "=" signs are not allowed in one equation',
      };
    }

    if (eqParts.length === 2) {
      const [lhs, rhs] = eqParts;
      if (lhs.length === 0 || rhs.length === 0) {
        return {
          ok: false,
          kind: 'empty',
          ggbCommand: '',
          displayLatex: toDisplayLatex(trimmed),
          undefinedVars: [],
          isSlider: false,
          isNumericEval: false,
          supports2D: true,
          supports3D: true,
          error: 'Equation is missing left or right side',
        };
      }

      // Case 1: Function definition `f(x) = ...` or `g(x, y) = ...`
      if (
        lhs.length >= 4 &&
        lhs[0].type === 'ident' &&
        lhs[1].type === 'lparen' &&
        lhs[lhs.length - 1].type === 'rparen'
      ) {
        const fnName = lhs[0].value;
        const paramTokens = lhs.slice(2, -1);
        const paramVars = paramTokens.filter((t) => t.type === 'ident').map((t) => t.value);
        const bound = new Set(paramVars);
        const undefinedVars = findUndefinedVariables([...rhs, ...restrictions.flat()], definedSymbols, bound);
        const rhsStr = compileExpressionTokens(rhs);
        const body = combinedRestrictionStr ? `If(${combinedRestrictionStr}, ${rhsStr})` : rhsStr;
        const is3dFn = paramVars.length === 2 || hasZ;
        return {
          ok: true,
          kind: 'function_def',
          ggbLabel: fnName,
          ggbCommand: `${fnName}(${paramVars.join(', ')}) = ${body}`,
          displayLatex: toDisplayLatex(trimmed),
          undefinedVars,
          isSlider: false,
          isNumericEval: false,
          supports2D: !is3dFn,
          supports3D: true,
        };
      }

      // Case 2: Polar `r = f(theta)`
      if (lhs.length === 1 && lhs[0].type === 'ident' && lhs[0].value === 'r') {
        const rhsStr = compileExpressionTokens(rhs).replace(/θ/g, 't_');
        const { min, max } = extractBoundsForVar(restrictions, ['theta', 't']);
        const bound = new Set(['theta', 't']);
        const undefinedVars = findUndefinedVariables([...rhs, ...restrictions.flat()], definedSymbols, bound);
        return {
          ok: true,
          kind: 'polar',
          ggbCommand: `${internalLabel} = Curve((${rhsStr})*cos(t_), (${rhsStr})*sin(t_), t_, ${min}, ${max})`,
          displayLatex: toDisplayLatex(trimmed),
          undefinedVars,
          isSlider: false,
          isNumericEval: false,
          supports2D: true,
          supports3D: true,
        };
      }

      // Case 3: Explicit `y = f(x)`
      if (lhs.length === 1 && lhs[0].type === 'ident' && lhs[0].value === 'y' && !hasYInTokens(rhs)) {
        const rhsStr = compileExpressionTokens(rhs);
        const undefinedVars = findUndefinedVariables([...rhs, ...restrictions.flat()], definedSymbols);
        if (hasZ) {
          return {
            ok: true,
            kind: 'implicit_3d',
            ggbCommand: `${internalLabel}: y = ${rhsStr}`,
            displayLatex: toDisplayLatex(trimmed),
            undefinedVars,
            isSlider: false,
            isNumericEval: false,
            supports2D: false,
            supports3D: true,
          };
        }
        const body = combinedRestrictionStr ? `If(${combinedRestrictionStr}, ${rhsStr})` : rhsStr;
        return {
          ok: true,
          kind: 'explicit_2d',
          ggbCommand: `${internalLabel}(x) = ${body}`,
          displayLatex: toDisplayLatex(trimmed),
          undefinedVars,
          isSlider: false,
          isNumericEval: false,
          supports2D: true,
          supports3D: true,
        };
      }

      // Case 4: Explicit 3D surface `z = f(x, y)`
      if (lhs.length === 1 && lhs[0].type === 'ident' && lhs[0].value === 'z' && !identsHas(rhs, 'z')) {
        const rhsStr = compileExpressionTokens(rhs);
        const undefinedVars = findUndefinedVariables([...rhs, ...restrictions.flat()], definedSymbols);
        const body = combinedRestrictionStr ? `If(${combinedRestrictionStr}, ${rhsStr})` : rhsStr;
        return {
          ok: true,
          kind: 'explicit_3d',
          ggbCommand: `${internalLabel}(x, y) = ${body}`,
          displayLatex: toDisplayLatex(trimmed),
          undefinedVars,
          isSlider: false,
          isNumericEval: false,
          supports2D: false,
          supports3D: true,
        };
      }

      // Case 5: Named assignment `A = (1, 2)`, `L = [1, 2, 3]`, or Slider `a = 2`
      if (
        lhs.length === 1 &&
        lhs[0].type === 'ident' &&
        !RESERVED_COORDS.has(lhs[0].value)
      ) {
        const varName = lhs[0].value;
        const rhsStr = compileExpressionTokens(rhs);
        const undefinedVars = findUndefinedVariables([...rhs, ...restrictions.flat()], definedSymbols);
        // Check if RHS is a list
        if (rhs[0]?.type === 'lbracket') {
          return {
            ok: true,
            kind: 'list',
            ggbLabel: varName,
            ggbCommand: `${varName} = ${rhsStr}`,
            displayLatex: toDisplayLatex(trimmed),
            undefinedVars,
            isSlider: false,
            isNumericEval: false,
            supports2D: true,
            supports3D: true,
          };
        }
        // Check if RHS is a point `(a, b)` or `(a, b, c)`
        const pointDim = detectTupleDimension(rhs);
        if (pointDim === 2 || pointDim === 3) {
          return {
            ok: true,
            kind: pointDim === 3 ? 'point_3d' : 'point_2d',
            ggbLabel: varName,
            ggbCommand: `${varName} = ${rhsStr}`,
            displayLatex: toDisplayLatex(trimmed),
            undefinedVars,
            isSlider: false,
            isNumericEval: false,
            supports2D: pointDim === 2,
            supports3D: true,
          };
        }
        // Check if numeric slider (no x, y, z, t, theta)
        const rhsIdents = rhs.filter((t) => t.type === 'ident').map((t) => t.value);
        const usesAxisVar = rhsIdents.some((v) => ['x', 'y', 'z', 't', 'theta'].includes(v));
        const literalNum = Number(rhsStr);
        const isPureNumber = !usesAxisVar && !Number.isNaN(literalNum) && rhs.every((t) => t.type === 'num' || (t.type === 'op' && (t.value === '-' || t.value === '+')));
        return {
          ok: true,
          kind: isPureNumber ? 'slider' : 'scalar',
          ggbLabel: varName,
          ggbCommand: `${varName} = ${rhsStr}`,
          displayLatex: toDisplayLatex(trimmed),
          undefinedVars: undefinedVars.filter((v) => v !== varName),
          isSlider: isPureNumber,
          sliderValue: isPureNumber ? literalNum : undefined,
          isNumericEval: !usesAxisVar,
          supports2D: true,
          supports3D: true,
        };
      }

      // Case 6: Implicit equation `x^2 + y^2 = 25` or `x^2 + y^2 + z^2 = 25` or `x + y + z = 5`
      const lhsStr = compileExpressionTokens(lhs);
      const rhsStr = compileExpressionTokens(rhs);
      const undefinedVars = findUndefinedVariables([...main, ...restrictions.flat()], definedSymbols);
      return {
        ok: true,
        kind: hasZ ? 'implicit_3d' : 'implicit_2d',
        ggbCommand: `${internalLabel}: ${lhsStr} = ${rhsStr}`,
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars,
        isSlider: false,
        isNumericEval: false,
        supports2D: !hasZ,
        supports3D: true,
      };
    }

    // No `=` sign! Could be:
    // A) Tuple: Parametric curve `(cos(t), sin(t))` or Point `(2, 3)` or 3D `(1, 2, 3)`
    const tupleParts = extractTopLevelTuple(main);
    if (tupleParts) {
      const tupleHasT = tupleParts.some((part) => part.some((tok) => tok.type === 'ident' && tok.value === 't'));
      if (tupleHasT) {
        const { min, max } = extractBoundsForVar(restrictions, ['t']);
        const bound = new Set(['t']);
        const undefinedVars = findUndefinedVariables([...main, ...restrictions.flat()], definedSymbols, bound);
        const coords = tupleParts.map((p) => compileExpressionTokens(p));
        if (coords.length === 2) {
          return {
            ok: true,
            kind: 'parametric_2d',
            ggbCommand: `${internalLabel} = Curve(${coords[0]}, ${coords[1]}, t, ${min}, ${max})`,
            displayLatex: toDisplayLatex(trimmed),
            undefinedVars,
            isSlider: false,
            isNumericEval: false,
            supports2D: true,
            supports3D: true,
          };
        }
        if (coords.length === 3) {
          return {
            ok: true,
            kind: 'parametric_3d',
            ggbCommand: `${internalLabel} = Curve(${coords[0]}, ${coords[1]}, ${coords[2]}, t, ${min}, ${max})`,
            displayLatex: toDisplayLatex(trimmed),
            undefinedVars,
            isSlider: false,
            isNumericEval: false,
            supports2D: false,
            supports3D: true,
          };
        }
      } else if (tupleParts.length === 2 || tupleParts.length === 3) {
        const undefinedVars = findUndefinedVariables(main, definedSymbols);
        const coords = tupleParts.map((p) => compileExpressionTokens(p));
        return {
          ok: true,
          kind: tupleParts.length === 3 ? 'point_3d' : 'point_2d',
          ggbCommand: `${internalLabel} = (${coords.join(', ')})`,
          displayLatex: toDisplayLatex(trimmed),
          undefinedVars,
          isSlider: false,
          isNumericEval: false,
          supports2D: tupleParts.length === 2,
          supports3D: true,
        };
      }
    }

    // B) Standalone list `[1, 2, 3]`
    if (main[0]?.type === 'lbracket' && main[main.length - 1]?.type === 'rbracket') {
      const listStr = compileExpressionTokens(main);
      const undefinedVars = findUndefinedVariables(main, definedSymbols);
      return {
        ok: true,
        kind: 'list',
        ggbCommand: `${internalLabel} = ${listStr}`,
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars,
        isSlider: false,
        isNumericEval: false,
        supports2D: true,
        supports3D: true,
      };
    }

    // C) Bare expression:
    // If it involves `x` and `y` (without `z`), or `x` alone -> Desmos auto-plots `y = expr`!
    // If it involves `x` and `y` and maybe `z`? If `x` and `y` without `z`? Wait: `sin(x)*cos(y)` in 3D mode could be `z = sin(x)*cos(y)`!
    // If it has no `x`, `y`, `z`, `t`, `theta` -> numeric calculation (evaluated via GeoGebra)!
    const undefinedVars = findUndefinedVariables([...main, ...restrictions.flat()], definedSymbols);
    const exprStr = compileExpressionTokens(main);

    if (hasX && hasY && !hasZ) {
      // e.g. `sin(x)*cos(y)` -> treat as 3D surface `z = expr`
      const body = combinedRestrictionStr ? `If(${combinedRestrictionStr}, ${exprStr})` : exprStr;
      return {
        ok: true,
        kind: 'explicit_3d',
        ggbCommand: `${internalLabel}(x, y) = ${body}`,
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars,
        isSlider: false,
        isNumericEval: false,
        supports2D: false,
        supports3D: true,
      };
    }

    if (/^Integral\(.+,.+,.+\)$/.test(exprStr)) {
      return {
        ok: true,
        kind: 'calculus',
        ggbCommand: `${internalLabel} = ${exprStr}`,
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars,
        isSlider: false,
        isNumericEval: true,
        supports2D: true,
        supports3D: false,
      };
    }

    if (hasX && !hasY && !hasZ) {
      const body = combinedRestrictionStr ? `If(${combinedRestrictionStr}, ${exprStr})` : exprStr;
      return {
        ok: true,
        kind: 'explicit_2d',
        ggbCommand: `${internalLabel}(x) = ${body}`,
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars,
        isSlider: false,
        isNumericEval: false,
        supports2D: true,
        supports3D: true,
      };
    }

    if (!hasX && !hasY && !hasZ && !hasT && !hasTheta) {
      return {
        ok: true,
        kind: 'scalar',
        ggbCommand: `${internalLabel} = ${exprStr}`,
        displayLatex: toDisplayLatex(trimmed),
        undefinedVars,
        isSlider: false,
        isNumericEval: true,
        supports2D: true,
        supports3D: true,
      };
    }

    return {
      ok: true,
      kind: hasZ ? 'explicit_3d' : 'explicit_2d',
      ggbCommand: `${internalLabel}: ${exprStr}`,
      displayLatex: toDisplayLatex(trimmed),
      undefinedVars,
      isSlider: false,
      isNumericEval: false,
      supports2D: !hasZ,
      supports3D: true,
    };
  } catch (err) {
    return {
      ok: false,
      kind: 'empty',
      ggbCommand: '',
      displayLatex: toDisplayLatex(trimmed),
      undefinedVars: [],
      isSlider: false,
      isNumericEval: false,
      supports2D: true,
      supports3D: true,
      error: err instanceof Error ? err.message : 'Unable to parse expression',
    };
  }
}

function isTopLevelIndex(tokens: Token[], targetIdx: number): boolean {
  let p = 0;
  let b = 0;
  let c = 0;
  for (let i = 0; i < targetIdx; i++) {
    if (tokens[i].type === 'lparen') p++;
    else if (tokens[i].type === 'rparen') p--;
    else if (tokens[i].type === 'lbracket') b++;
    else if (tokens[i].type === 'rbracket') b--;
    else if (tokens[i].type === 'lbrace') c++;
    else if (tokens[i].type === 'rbrace') c--;
  }
  return p === 0 && b === 0 && c === 0;
}

function hasYInTokens(tokens: Token[]): boolean {
  return tokens.some((t) => t.type === 'ident' && t.value === 'y');
}

function identsHas(tokens: Token[], target: string): boolean {
  return tokens.some((t) => t.type === 'ident' && t.value === target);
}

function extractTopLevelTuple(tokens: Token[]): Token[][] | null {
  if (tokens.length < 3 || tokens[0].type !== 'lparen' || tokens[tokens.length - 1].type !== 'rparen') {
    return null;
  }
  // Ensure outer parens match each other
  let depth = 0;
  for (let i = 0; i < tokens.length; i++) {
    if (tokens[i].type === 'lparen') depth++;
    else if (tokens[i].type === 'rparen') {
      depth--;
      if (depth === 0 && i < tokens.length - 1) return null;
    }
  }
  const inner = tokens.slice(1, -1);
  const parts = splitTopLevel(inner, (t) => t.type === 'comma');
  return parts.length >= 2 ? parts : null;
}

function detectTupleDimension(tokens: Token[]): number {
  const parts = extractTopLevelTuple(tokens);
  return parts ? parts.length : 0;
}

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean;
  const num = parseInt(full, 16);
  if (Number.isNaN(num)) return [45, 112, 179];
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}
