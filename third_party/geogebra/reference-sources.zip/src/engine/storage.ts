import { DEFAULT_SETTINGS, ExpressionItem, GraphSettings, SavedGraph, ViewMode } from '../types/calculator';

const AUTOSAVE_KEY = 'desmos_ggb_autosave_v1';
const SAVED_LIST_KEY = 'desmos_ggb_saved_graphs_v1';

export interface WorkspaceSnapshot {
  title: string;
  expressions: ExpressionItem[];
  settings: GraphSettings;
  viewMode: ViewMode;
  ggbXml2d?: string;
  ggbXml3d?: string;
}

export function saveAutosave(snapshot: WorkspaceSnapshot): void {
  try {
    localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(snapshot));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadAutosave(): WorkspaceSnapshot | null {
  try {
    const raw = localStorage.getItem(AUTOSAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as WorkspaceSnapshot;
    if (!Array.isArray(parsed.expressions)) return null;
    return {
      title: parsed.title || 'Untitled Graph',
      expressions: parsed.expressions,
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings ?? {}) },
      viewMode: parsed.viewMode === '3d' ? '3d' : '2d',
      ggbXml2d: parsed.ggbXml2d,
      ggbXml3d: parsed.ggbXml3d,
    };
  } catch {
    return null;
  }
}

export function listSavedGraphs(): SavedGraph[] {
  try {
    const raw = localStorage.getItem(SAVED_LIST_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedGraph[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function upsertSavedGraph(graph: SavedGraph): SavedGraph[] {
  const existing = listSavedGraphs().filter((g) => g.id !== graph.id);
  const next = [graph, ...existing];
  try {
    localStorage.setItem(SAVED_LIST_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }
  return next;
}

export function deleteSavedGraph(id: string): SavedGraph[] {
  const next = listSavedGraphs().filter((g) => g.id !== id);
  try {
    localStorage.setItem(SAVED_LIST_KEY, JSON.stringify(next));
  } catch {
    // ignore
  }
  return next;
}

export function encodeShareUrl(snapshot: WorkspaceSnapshot): string {
  const compact = {
    t: snapshot.title,
    m: snapshot.viewMode,
    e: snapshot.expressions,
    s: snapshot.settings,
  };
  const json = JSON.stringify(compact);
  const bytes = new TextEncoder().encode(json);
  let binary = '';
  for (const b of bytes) binary += String.fromCharCode(b);
  const b64 = btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const url = new URL(window.location.href);
  url.hash = `g=${b64}`;
  return url.toString();
}

export function decodeShareHash(hash: string): WorkspaceSnapshot | null {
  try {
    if (!hash || !hash.includes('g=')) return null;
    const match = hash.match(/g=([A-Za-z0-9\-_]+)/);
    if (!match) return null;
    let b64 = match[1].replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4) b64 += '=';
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const json = new TextDecoder().decode(bytes);
    const parsed = JSON.parse(json) as {
      t?: string;
      m?: ViewMode;
      e?: ExpressionItem[];
      s?: GraphSettings;
    };
    if (!Array.isArray(parsed.e)) return null;
    return {
      title: parsed.t || 'Shared Graph',
      viewMode: parsed.m === '3d' ? '3d' : '2d',
      expressions: parsed.e,
      settings: { ...DEFAULT_SETTINGS, ...(parsed.s ?? {}) },
    };
  } catch {
    return null;
  }
}
