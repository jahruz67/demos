import test from 'node:test';
import assert from 'node:assert/strict';
import { translateDesmosExpression, preprocessLatex, hexToRgb } from './desmosTranslator';

test('translates standard 2D explicit equations and implicit multiplication', () => {
  const res = translateDesmosExpression('y = 2x^2 + 3x - 1', { internalLabel: 'g1' });
  assert.equal(res.ok, true);
  assert.equal(res.kind, 'explicit_2d');
  assert.equal(res.ggbCommand, 'g1(x) = 2*x^2+3*x-1');
  assert.deepEqual(res.undefinedVars, []);
});

test('detects undefined parameters for auto-sliders in y = mx + b', () => {
  const res = translateDesmosExpression('y = mx + b', { internalLabel: 'g2' });
  assert.equal(res.ok, true);
  assert.equal(res.ggbCommand, 'g2(x) = m*x+b');
  assert.deepEqual(res.undefinedVars, ['m', 'b']);

  const withDefined = translateDesmosExpression('y = mx + b', {
    internalLabel: 'g2',
    definedSymbols: new Set(['m']),
  });
  assert.deepEqual(withDefined.undefinedVars, ['b']);
});

test('translates domain restrictions and chained inequalities', () => {
  const res = translateDesmosExpression('y = x^2 {x > 0}', { internalLabel: 'g3' });
  assert.equal(res.ok, true);
  assert.equal(res.ggbCommand, 'g3(x) = If(x > 0, x^2)');

  const chained = translateDesmosExpression('y = sin(x) {-pi <= x <= pi}', { internalLabel: 'g4' });
  assert.equal(chained.ok, true);
  assert.equal(chained.ggbCommand, 'g4(x) = If((-π <= x) && (x <= π), sin(x))');
});

test('translates polar equations to parametric curves', () => {
  const res = translateDesmosExpression('r = 2sin(3θ)', { internalLabel: 'g5' });
  assert.equal(res.ok, true);
  assert.equal(res.kind, 'polar');
  assert.equal(res.ggbCommand, 'g5 = Curve((2*sin(3*t_))*cos(t_), (2*sin(3*t_))*sin(t_), t_, 0, 2*π)');
  assert.deepEqual(res.undefinedVars, []);
});

test('translates implicit 2D and 3D equations', () => {
  const circle = translateDesmosExpression('x^2 + y^2 = 25', { internalLabel: 'g6' });
  assert.equal(circle.ok, true);
  assert.equal(circle.kind, 'implicit_2d');
  assert.equal(circle.supports2D, true);
  assert.equal(circle.ggbCommand, 'g6: x^2+y^2 = 25');

  const sphere = translateDesmosExpression('x^2 + y^2 + z^2 = 25', { internalLabel: 'g7' });
  assert.equal(sphere.ok, true);
  assert.equal(sphere.kind, 'implicit_3d');
  assert.equal(sphere.supports2D, false);
  assert.equal(sphere.supports3D, true);
  assert.equal(sphere.ggbCommand, 'g7: x^2+y^2+z^2 = 25');
});

test('translates 3D explicit surfaces z = sin(x)cos(y)', () => {
  const surf = translateDesmosExpression('z = sin(x)cos(y)', { internalLabel: 'g8' });
  assert.equal(surf.ok, true);
  assert.equal(surf.kind, 'explicit_3d');
  assert.equal(surf.supports2D, false);
  assert.equal(surf.supports3D, true);
  assert.equal(surf.ggbCommand, 'g8(x, y) = sin(x)*cos(y)');
});

test('translates piecewise, lists, summations, derivatives, and integrals', () => {
  const pw = translateDesmosExpression('y = {x < 0: -x, x^2}', { internalLabel: 'g9' });
  assert.equal(pw.ok, true);
  assert.equal(pw.ggbCommand, 'g9(x) = If(x < 0, -x, x^2)');

  const list = translateDesmosExpression('L = [1, 2, 3, 4]');
  assert.equal(list.ok, true);
  assert.equal(list.kind, 'list');
  assert.equal(list.ggbCommand, 'L = {1, 2, 3, 4}');

  const sumRes = translateDesmosExpression('y = sum(n=1, 4, x^n / n)', { internalLabel: 'g10' });
  assert.equal(sumRes.ok, true);
  assert.equal(sumRes.ggbCommand, 'g10(x) = Sum(Sequence(x^n/n, n, 1, 4))');
  assert.deepEqual(sumRes.undefinedVars, []);

  const deriv = translateDesmosExpression('y = d/dx(x^3 - 2x)', { internalLabel: 'g11' });
  assert.equal(deriv.ok, true);
  assert.equal(deriv.ggbCommand, 'g11(x) = Derivative(x^3-2*x, x)');

  const integ = translateDesmosExpression('integral(x^2, x, 0, 3)', { internalLabel: 'g12' });
  assert.equal(integ.ok, true);
  assert.equal(integ.ggbCommand, 'g12 = Integral(x^2, 0, 3)');
});

test('translates absolute value bars and LaTeX fractions', () => {
  assert.equal(preprocessLatex('\\frac{x^2 + 1}{2}'), '((x^2 + 1)/(2))');
  const absRes = translateDesmosExpression('y = |x - 2|', { internalLabel: 'g13' });
  assert.equal(absRes.ok, true);
  assert.equal(absRes.ggbCommand, 'g13(x) = abs(x-2)');
});

test('handles sliders and numeric scalar evaluation', () => {
  const slider = translateDesmosExpression('a = 2.5');
  assert.equal(slider.ok, true);
  assert.equal(slider.isSlider, true);
  assert.equal(slider.sliderValue, 2.5);
  assert.equal(slider.ggbLabel, 'a');

  const scalar = translateDesmosExpression('2 + 3 * 4', { internalLabel: 'g14' });
  assert.equal(scalar.ok, true);
  assert.equal(scalar.isNumericEval, true);
  assert.equal(scalar.ggbCommand, 'g14 = 2+3*4');
});

test('reports clear errors for unmatched delimiters', () => {
  const bad = translateDesmosExpression('y = sin(x');
  assert.equal(bad.ok, false);
  assert.match(bad.error ?? '', /parenthesis/i);
});

test('hexToRgb converts Desmos hex colors accurately', () => {
  assert.deepEqual(hexToRgb('#c74440'), [199, 68, 64]);
  assert.deepEqual(hexToRgb('#2d70b3'), [45, 112, 179]);
});
