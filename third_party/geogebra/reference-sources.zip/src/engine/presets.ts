import { DESMOS_COLORS, ExamplePreset, ExpressionItem } from '../types/calculator';

let idSeq = 100;
export function nextExprId(prefix = 'expr'): string {
  idSeq += 1;
  return `${prefix}_${Date.now().toString(36)}_${idSeq}`;
}

export function createExpressionItem(partial: Partial<ExpressionItem> & { type: ExpressionItem['type'] }): ExpressionItem {
  const colorIndex = idSeq % DESMOS_COLORS.length;
  return {
    id: partial.id ?? nextExprId(),
    type: partial.type,
    folderId: partial.folderId ?? null,
    collapsed: partial.collapsed ?? false,
    latex: partial.latex ?? '',
    color: partial.color ?? DESMOS_COLORS[colorIndex].hex,
    visible: partial.visible ?? true,
    lineStyle: partial.lineStyle ?? 'solid',
    lineWidth: partial.lineWidth ?? 2.5,
    lineOpacity: partial.lineOpacity ?? 0.9,
    pointStyle: partial.pointStyle ?? 'point',
    pointSize: partial.pointSize ?? 5,
    showLabel: partial.showLabel ?? false,
    labelText: partial.labelText ?? '',
    slider: partial.slider,
    noteText: partial.noteText,
    tableColumns: partial.tableColumns,
  };
}

export const INITIAL_EXPRESSIONS: ExpressionItem[] = [
  createExpressionItem({
    id: 'init_1',
    type: 'expression',
    latex: 'y = a*sin(b*x)',
    color: DESMOS_COLORS[1].hex,
  }),
  createExpressionItem({
    id: 'init_2',
    type: 'expression',
    latex: 'a = 2',
    color: DESMOS_COLORS[0].hex,
    slider: {
      min: -5,
      max: 5,
      step: 0.1,
      playing: false,
      speed: 1,
      direction: 1,
      loopMode: 'oscillate',
    },
  }),
  createExpressionItem({
    id: 'init_3',
    type: 'expression',
    latex: 'b = 1.5',
    color: DESMOS_COLORS[2].hex,
    slider: {
      min: 0.2,
      max: 5,
      step: 0.1,
      playing: false,
      speed: 1,
      direction: 1,
      loopMode: 'oscillate',
    },
  }),
  createExpressionItem({
    id: 'init_4',
    type: 'expression',
    latex: 'x^2 + y^2 = 9',
    color: DESMOS_COLORS[0].hex,
    lineStyle: 'dashed',
  }),
];

export const EXAMPLE_PRESETS: ExamplePreset[] = [
  {
    id: 'preset_harmonic',
    title: 'Harmonic Wave & Circle',
    category: 'Interactive',
    recommendedMode: '2d',
    description: 'Parametric sine wave with live amplitude & frequency sliders.',
    expressions: [
      { type: 'expression', latex: 'y = a*sin(b*x)', color: '#2d70b3' },
      {
        type: 'expression',
        latex: 'a = 2',
        color: '#c74440',
        slider: { min: -5, max: 5, step: 0.1, playing: false, speed: 1, direction: 1, loopMode: 'oscillate' },
      },
      {
        type: 'expression',
        latex: 'b = 1.5',
        color: '#388c46',
        slider: { min: 0.2, max: 5, step: 0.1, playing: false, speed: 1, direction: 1, loopMode: 'oscillate' },
      },
      { type: 'expression', latex: 'x^2 + y^2 = 9', color: '#c74440', lineStyle: 'dashed' },
    ],
  },
  {
    id: 'preset_polar',
    title: 'Polar Rose & Spiral',
    category: '2D Curves',
    recommendedMode: '2d',
    description: 'Four-petal polar rose and golden spiral in polar coordinates.',
    expressions: [
      { type: 'expression', latex: 'r = 4*sin(3*theta)', color: '#c74440' },
      { type: 'expression', latex: 'r = 0.35*theta {0 <= theta <= 4*pi}', color: '#6042a6' },
      { type: 'expression', latex: 'x^2 + y^2 <= 16', color: '#2d70b3', visible: false },
    ],
  },
  {
    id: 'preset_calculus',
    title: 'Derivative & Definite Integral',
    category: '2D Calculus',
    recommendedMode: '2d',
    description: 'Cubic function, tangent slope derivative, and shaded area integral.',
    expressions: [
      { type: 'expression', latex: 'f(x) = 0.25*x^3 - x', color: '#2d70b3' },
      { type: 'expression', latex: 'y = d/dx(0.25*x^3 - x)', color: '#c74440', lineStyle: 'dashed' },
      { type: 'expression', latex: 'integral(0.25*x^3 - x, x, -2, 2)', color: '#388c46' },
    ],
  },
  {
    id: 'preset_3d_waves',
    title: '3D Wave Interference & Sphere',
    category: '3D Surfaces',
    recommendedMode: '3d',
    description: 'Interactive 3D trig surface with frequency slider and translucent plane.',
    expressions: [
      { type: 'expression', latex: 'z = a*sin(x)*cos(y)', color: '#2d70b3' },
      {
        type: 'expression',
        latex: 'a = 1.5',
        color: '#c74440',
        slider: { min: 0.2, max: 3, step: 0.1, playing: false, speed: 1, direction: 1, loopMode: 'oscillate' },
      },
      { type: 'expression', latex: 'x + y + z = 4', color: '#fa7e19' },
      { type: 'expression', latex: 'x^2 + y^2 + z^2 = 16', color: '#6042a6', visible: false },
    ],
  },
  {
    id: 'preset_3d_paraboloid',
    title: 'Elliptic Paraboloid & Helix',
    category: '3D Surfaces',
    recommendedMode: '3d',
    description: 'Paraboloid surface paired with a 3D parametric helix curve.',
    expressions: [
      { type: 'expression', latex: 'z = 0.2*(x^2 + y^2)', color: '#388c46' },
      { type: 'expression', latex: '(2*cos(t), 2*sin(t), 0.35*t) {0 <= t <= 4*pi}', color: '#c74440' },
      { type: 'expression', latex: '(0, 0, 2)', color: '#000000' },
    ],
  },
];
