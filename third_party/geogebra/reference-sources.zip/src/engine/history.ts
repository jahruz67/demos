import { ExpressionItem } from '../types/calculator';

export interface HistoryState {
  past: ExpressionItem[][];
  present: ExpressionItem[];
  future: ExpressionItem[][];
}

const MAX_HISTORY = 60;

export function createHistory(initial: ExpressionItem[]): HistoryState {
  return {
    past: [],
    present: initial,
    future: [],
  };
}

export function pushHistory(state: HistoryState, next: ExpressionItem[], record = true): HistoryState {
  if (!record) {
    return {
      ...state,
      present: next,
    };
  }
  const past = [...state.past, state.present].slice(-MAX_HISTORY);
  return {
    past,
    present: next,
    future: [],
  };
}

export function undoHistory(state: HistoryState): HistoryState {
  if (state.past.length === 0) return state;
  const previous = state.past[state.past.length - 1];
  const past = state.past.slice(0, -1);
  return {
    past,
    present: previous,
    future: [state.present, ...state.future],
  };
}

export function redoHistory(state: HistoryState): HistoryState {
  if (state.future.length === 0) return state;
  const next = state.future[0];
  const future = state.future.slice(1);
  return {
    past: [...state.past, state.present].slice(-MAX_HISTORY),
    present: next,
    future,
  };
}
