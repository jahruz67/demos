import { ExpressionItem, GraphSettings, ViewMode } from '../types/calculator';
import { hexToRgb, translateDesmosExpression, TranslationResult } from './desmosTranslator';

export interface GgbApi {
  evalCommand: (cmd: string) => boolean;
  evalCommandGetLabels: (cmd: string) => string | null;
  evalCommandCAS?: (cmd: string) => string;
  deleteObject: (name: string) => void;
  exists: (name: string) => boolean;
  setVisible: (name: string, visible: boolean) => void;
  setColor: (name: string, r: number, g: number, b: number) => void;
  setLineThickness: (name: string, thickness: number) => void;
  setLineStyle: (name: string, style: number) => void;
  setPointStyle: (name: string, style: number) => void;
  setPointSize: (name: string, size: number) => void;
  setFilling: (name: string, opacity: number) => void;
  setLabelVisible: (name: string, visible: boolean) => void;
  setLabelStyle?: (name: string, style: number) => void;
  setCaption?: (name: string, caption: string) => void;
  setValue: (name: string, value: number) => void;
  getValue: (name: string) => number;
  getValueString?: (name: string) => string;
  getXcoord?: (name: string) => number;
  getYcoord?: (name: string) => number;
  getZcoord?: (name: string) => number;
  setCoordSystem: (...args: number[]) => void;
  setGridVisible: (...args: unknown[]) => void;
  setAxesVisible: (...args: unknown[]) => void;
  setPerspective: (perspective: string) => void;
  setMode?: (mode: number) => void;
  getAllObjectNames: (type?: string) => string[];
  getObjectType?: (name: string) => string;
  getXML: (objName?: string) => string;
  setXML: (xml: string) => void;
  getPNGBase64?: (exportScale?: number, transparent?: boolean, dpi?: number) => string;
  registerObjectUpdateListener?: (objName: string, fn: string) => void;
  registerClientListener?: (fn: string) => void;
  getGraphicsViewBounds?: () => { xmin: number; xmax: number; ymin: number; ymax: number };
  setErrorDialogsActive?: (active: boolean) => void;
  setAxesCornerCoordsVisible?: (visible: boolean) => void;
  setGridType?: (type: number) => void;
  setAxisLabels?: (view: number, x: string, y: string, z?: string) => void;
  setAxisSteps?: (view: number, x: number, y: number, z?: number) => void;
}

export interface SyncFeedback {
  error: string | null;
  modeNotice: string | null;
  evalResult: string | null;
  undefinedVars: string[];
  isSlider: boolean;
  variableName?: string;
}

interface TrackedExpr {
  mathSignature: string;
  styleSignature: string;
  ggbLabels: string[];
  definedSymbol?: string;
  sliderNumeric?: number;
  feedback: SyncFeedback;
}

function getMathSignature(item: ExpressionItem, mode: ViewMode, angleMode: 'rad' | 'deg'): string {
  if (item.type === 'table') {
    return JSON.stringify({ type: 'table', cols: item.tableColumns, mode });
  }
  return `${item.type}|${item.latex}|${mode}|${angleMode}`;
}

function getStyleSignature(item: ExpressionItem, effectiveVisible: boolean): string {
  return JSON.stringify({
    v: effectiveVisible,
    c: item.color,
    ls: item.lineStyle,
    lw: item.lineWidth,
    lo: item.lineOpacity,
    ps: item.pointStyle,
    pz: item.pointSize,
    sl: item.showLabel,
    lt: item.labelText,
    cols: item.tableColumns?.map((c) => [c.color, c.visible, c.showLines, c.showPoints, c.pointStyle, c.lineStyle]),
  });
}

function mapLineStyle(style: ExpressionItem['lineStyle']): number {
  switch (style) {
    case 'dashed':
      return 1;
    case 'dotted':
      return 3;
    default:
      return 0;
  }
}

function mapPointStyle(style: ExpressionItem['pointStyle']): number {
  switch (style) {
    case 'open':
      return 2;
    case 'cross':
      return 1;
    default:
      return 0;
  }
}

export class GeoGebraEngineAdapter {
  private api: GgbApi;
  private mode: ViewMode;
  private tracked = new Map<string, TrackedExpr>();
  private labelCounter = 1;

  constructor(api: GgbApi, mode: ViewMode) {
    this.api = api;
    this.mode = mode;
    try {
      this.api.setErrorDialogsActive?.(false);
    } catch {
      // Ignore if unavailable in build
    }
  }

  public getApi(): GgbApi {
    return this.api;
  }

  public applySettings(settings: GraphSettings, applyBounds = false): void {
    try {
      if (this.mode === '2d') {
        this.api.setGridVisible(settings.showGrid);
        this.api.setAxesVisible(settings.showXAxis, settings.showYAxis);
        if (settings.polarGrid) {
          this.api.setGridType?.(2); // Polar grid in GeoGebra
        } else {
          this.api.setGridType?.(settings.showMinorGrid ? 1 : 0);
        }
        if (applyBounds) {
          const { xmin, xmax, ymin, ymax } = settings.bounds2D;
          if (xmax > xmin && ymax > ymin) {
            this.api.setCoordSystem(xmin, xmax, ymin, ymax);
          }
        }
        this.api.setAxisLabels?.(1, settings.xAxisLabel || '', settings.yAxisLabel || '');
        if (settings.xStep && settings.yStep) {
          this.api.setAxisSteps?.(1, settings.xStep, settings.yStep);
        }
      } else {
        // 3D mode settings
        try {
          this.api.setGridVisible(3, settings.showGrid);
        } catch {
          try {
            this.api.setGridVisible(settings.showGrid);
          } catch {
            // ignore
          }
        }
        try {
          this.api.setAxesVisible(3, settings.showXAxis, settings.showYAxis, settings.showZAxis);
        } catch {
          try {
            this.api.setAxesVisible(settings.showXAxis, settings.showYAxis, settings.showZAxis);
          } catch {
            // ignore
          }
        }
        if (applyBounds) {
          const { xmin, xmax, ymin, ymax, zmin, zmax } = settings.bounds3D;
          if (xmax > xmin && ymax > ymin && zmax > zmin) {
            try {
              this.api.setCoordSystem(xmin, xmax, ymin, ymax, zmin, zmax);
            } catch {
              // ignore if 3D coord system signature differs
            }
          }
        }
      }
    } catch {
      // Guard against transient applet initialization races
    }
  }

  public zoom(factor: number, settings: GraphSettings): GraphSettings['bounds2D'] | null {
    if (this.mode === '2d') {
      const current = this.readBounds2D() ?? settings.bounds2D;
      const cx = (current.xmin + current.xmax) / 2;
      const cy = (current.ymin + current.ymax) / 2;
      const halfW = ((current.xmax - current.xmin) / 2) * factor;
      const halfH = ((current.ymax - current.ymin) / 2) * factor;
      const next = {
        xmin: cx - halfW,
        xmax: cx + halfW,
        ymin: cy - halfH,
        ymax: cy + halfH,
      };
      this.api.setCoordSystem(next.xmin, next.xmax, next.ymin, next.ymax);
      return next;
    } else {
      // 3D zoom via XML or coordSystem scaling
      try {
        const b = settings.bounds3D;
        const cx = (b.xmin + b.xmax) / 2;
        const cy = (b.ymin + b.ymax) / 2;
        const cz = (b.zmin + b.zmax) / 2;
        const hw = ((b.xmax - b.xmin) / 2) * factor;
        const hh = ((b.ymax - b.ymin) / 2) * factor;
        const hd = ((b.zmax - b.zmin) / 2) * factor;
        this.api.setCoordSystem(cx - hw, cx + hw, cy - hh, cy + hh, cz - hd, cz + hd);
      } catch {
        // Fallback zoom command
      }
      return null;
    }
  }

  public resetView(settings: GraphSettings): void {
    if (this.mode === '2d') {
      this.api.setCoordSystem(-10, 10, -6.5, 6.5);
    } else {
      try {
        this.api.setCoordSystem(
          settings.bounds3D.xmin,
          settings.bounds3D.xmax,
          settings.bounds3D.ymin,
          settings.bounds3D.ymax,
          settings.bounds3D.zmin,
          settings.bounds3D.zmax
        );
      } catch {
        // ignore
      }
    }
  }

  public readBounds2D(): GraphSettings['bounds2D'] | null {
    if (this.mode !== '2d') return null;
    try {
      const xml = this.api.getXML();
      const match = xml.match(
        /<euclidianView[^>]*>[\s\S]*?<coordSystem\s+xZero="([^"]+)"\s+yZero="([^"]+)"\s+scale="([^"]+)"(?:\s+yscale="([^"]+)")?/
      );
      const sizeMatch = xml.match(/<size\s+width="([^"]+)"\s+height="([^"]+)"/);
      if (match && sizeMatch) {
        const xZero = parseFloat(match[1]);
        const yZero = parseFloat(match[2]);
        const xScale = parseFloat(match[3]);
        const yScale = match[4] ? parseFloat(match[4]) : xScale;
        const width = parseFloat(sizeMatch[1]);
        const height = parseFloat(sizeMatch[2]);
        if (xScale > 0 && yScale > 0 && width > 0 && height > 0) {
          return {
            xmin: -xZero / xScale,
            xmax: (width - xZero) / xScale,
            ymin: (yZero - height) / yScale,
            ymax: yZero / yScale,
          };
        }
      }
    } catch {
      // ignore
    }
    return null;
  }

  /**
   * Incrementally reconcile all expressions with this GeoGebra applet.
   * Preserves unrelated objects, uses fast-path setValue for sliders, and returns per-expression feedback.
   */
  public syncExpressions(
    items: ExpressionItem[],
    settings: GraphSettings
  ): Record<string, SyncFeedback> {
    const feedbackMap: Record<string, SyncFeedback> = {};
    const folderVisibility = new Map<string, boolean>();
    for (const item of items) {
      if (item.type === 'folder') {
        folderVisibility.set(item.id, item.visible);
      }
    }

    // Collect defined symbols & functions across the list before translating
    const definedSymbols = new Set<string>();
    const definedFunctions = new Set<string>();
    for (const item of items) {
      if (item.type !== 'expression') continue;
      const mFn = item.latex.trim().match(/^([a-zA-Z][a-zA-Z0-9_]*)\s*\(/);
      if (mFn && item.latex.includes('=')) {
        definedFunctions.add(mFn[1]);
        definedSymbols.add(mFn[1]);
      }
      const mVar = item.latex.trim().match(/^([a-zA-Z][a-zA-Z0-9_]*)\s*=/);
      if (mVar && !['x', 'y', 'z', 'r', 't', 'theta'].includes(mVar[1])) {
        definedSymbols.add(mVar[1]);
      }
    }

    // Delete objects for removed expressions
    const currentIds = new Set(items.map((i) => i.id));
    for (const [trackedId, tracked] of this.tracked.entries()) {
      if (!currentIds.has(trackedId)) {
        this.deleteLabels(tracked.ggbLabels);
        this.tracked.delete(trackedId);
      }
    }

    let dependencyDirty = false;

    // Order items for evaluation: sliders/scalars/lists first, then function_def, then curves/equations/tables
    const orderedItems = [...items].sort((a, b) => {
      const rank = (it: ExpressionItem): number => {
        if (it.type !== 'expression') return 3;
        const t = it.latex.trim();
        if (/^[a-zA-Z][a-zA-Z0-9_]*\s*=\s*-?\d*\.?\d+$/.test(t)) return 0; // pure slider
        if (/^[a-zA-Z][a-zA-Z0-9_]*\s*=/.test(t) && !/^[xyrz]\s*=/.test(t)) return 1; // named scalar/list
        if (/^[a-zA-Z][a-zA-Z0-9_]*\s*\([^)]*\)\s*=/.test(t)) return 2; // function def
        return 3;
      };
      return rank(a) - rank(b);
    });

    for (const item of orderedItems) {
      const parentVisible = item.folderId ? (folderVisibility.get(item.folderId) ?? true) : true;
      const effectiveVisible = item.visible && parentVisible;

      if (item.type === 'folder' || item.type === 'note') {
        feedbackMap[item.id] = {
          error: null,
          modeNotice: null,
          evalResult: null,
          undefinedVars: [],
          isSlider: false,
        };
        continue;
      }

      const mathSig = getMathSignature(item, this.mode, settings.angleMode);
      const styleSig = getStyleSignature(item, effectiveVisible);
      const prev = this.tracked.get(item.id);

      // Handle table items
      if (item.type === 'table') {
        if (!prev || prev.mathSignature !== mathSig) {
          if (prev) this.deleteLabels(prev.ggbLabels);
          const labels = this.createTableObjects(item, effectiveVisible);
          const fb: SyncFeedback = {
            error: null,
            modeNotice: null,
            evalResult: null,
            undefinedVars: [],
            isSlider: false,
          };
          this.tracked.set(item.id, {
            mathSignature: mathSig,
            styleSignature: styleSig,
            ggbLabels: labels,
            feedback: fb,
          });
          feedbackMap[item.id] = fb;
        } else if (prev.styleSignature !== styleSig) {
          this.applyTableStyles(item, prev.ggbLabels, effectiveVisible);
          prev.styleSignature = styleSig;
          feedbackMap[item.id] = prev.feedback;
        } else {
          feedbackMap[item.id] = prev.feedback;
        }
        continue;
      }

      // Fast path for slider numeric value changes: update via setValue() without deleting/recreating!
      if (prev && prev.definedSymbol && prev.sliderNumeric !== undefined) {
        const translatedCheck = translateDesmosExpression(item.latex, {
          definedSymbols,
          definedFunctions,
          viewMode: this.mode,
          internalLabel: `d_${this.labelCounter}`,
        });
        if (
          translatedCheck.ok &&
          translatedCheck.isSlider &&
          translatedCheck.ggbLabel === prev.definedSymbol &&
          translatedCheck.sliderValue !== undefined &&
          this.api.exists(prev.definedSymbol)
        ) {
          if (prev.sliderNumeric !== translatedCheck.sliderValue) {
            try {
              this.api.setValue(prev.definedSymbol, translatedCheck.sliderValue);
              prev.sliderNumeric = translatedCheck.sliderValue;
              prev.mathSignature = mathSig;
            } catch {
              // Fall through to full re-eval if setValue fails
            }
          }
          if (prev.styleSignature !== styleSig) {
            this.applyStyles(prev.ggbLabels, item, effectiveVisible, false);
            prev.styleSignature = styleSig;
          }
          feedbackMap[item.id] = prev.feedback;
          continue;
        }
      }

      // If unchanged mathematically and no upstream dependency changed
      if (prev && prev.mathSignature === mathSig && !dependencyDirty) {
        if (prev.styleSignature !== styleSig) {
          this.applyStyles(prev.ggbLabels, item, effectiveVisible, prev.feedback.isSlider);
          prev.styleSignature = styleSig;
        }
        // Re-read numeric eval result in case a slider updated upstream
        const refreshedEval = this.readEvalResult(prev.ggbLabels, prev.feedback);
        prev.feedback = { ...prev.feedback, evalResult: refreshedEval };
        feedbackMap[item.id] = prev.feedback;
        continue;
      }

      // Otherwise, (re)evaluate this expression
      if (prev) {
        this.deleteLabels(prev.ggbLabels);
      }

      const internalLabel = `d${this.labelCounter++}`;
      const translation = translateDesmosExpression(item.latex, {
        definedSymbols,
        definedFunctions,
        viewMode: this.mode,
        internalLabel,
      });

      if (translation.kind === 'empty' && translation.ok) {
        const fb: SyncFeedback = {
          error: null,
          modeNotice: null,
          evalResult: null,
          undefinedVars: [],
          isSlider: false,
        };
        this.tracked.set(item.id, {
          mathSignature: mathSig,
          styleSignature: styleSig,
          ggbLabels: [],
          feedback: fb,
        });
        feedbackMap[item.id] = fb;
        continue;
      }

      if (!translation.ok) {
        const fb: SyncFeedback = {
          error: translation.error ?? 'Invalid expression',
          modeNotice: null,
          evalResult: null,
          undefinedVars: [],
          isSlider: false,
        };
        this.tracked.set(item.id, {
          mathSignature: mathSig,
          styleSignature: styleSig,
          ggbLabels: [],
          feedback: fb,
        });
        feedbackMap[item.id] = fb;
        continue;
      }

      // Check mode compatibility before invoking GeoGebra
      if (this.mode === '2d' && !translation.supports2D) {
        const fb: SyncFeedback = {
          error: null,
          modeNotice: '3D expression — switch to 3D mode to plot',
          evalResult: null,
          undefinedVars: translation.undefinedVars,
          isSlider: false,
        };
        this.tracked.set(item.id, {
          mathSignature: mathSig,
          styleSignature: styleSig,
          ggbLabels: [],
          feedback: fb,
        });
        feedbackMap[item.id] = fb;
        continue;
      }

      // If expression has undefined variables (like y = mx + b), don't error; prompt user to add sliders!
      if (translation.undefinedVars.length > 0) {
        const fb: SyncFeedback = {
          error: null,
          modeNotice: null,
          evalResult: null,
          undefinedVars: translation.undefinedVars,
          isSlider: false,
        };
        this.tracked.set(item.id, {
          mathSignature: mathSig,
          styleSignature: styleSig,
          ggbLabels: [],
          feedback: fb,
        });
        feedbackMap[item.id] = fb;
        continue;
      }

      // Evaluate in GeoGebra
      const evalOutcome = this.evaluateTranslation(translation, item, effectiveVisible, settings);
      if (translation.ggbLabel) {
        dependencyDirty = true;
      }

      this.tracked.set(item.id, {
        mathSignature: mathSig,
        styleSignature: styleSig,
        ggbLabels: evalOutcome.labels,
        definedSymbol: translation.ggbLabel,
        sliderNumeric: translation.sliderValue,
        feedback: evalOutcome.feedback,
      });
      feedbackMap[item.id] = evalOutcome.feedback;
    }

    return feedbackMap;
  }

  private evaluateTranslation(
    translation: TranslationResult,
    item: ExpressionItem,
    effectiveVisible: boolean,
    settings: GraphSettings
  ): { labels: string[]; feedback: SyncFeedback } {
    let cmd = translation.ggbCommand;
    if (settings.angleMode === 'deg') {
      cmd = cmd.replace(/\b(sin|cos|tan|csc|sec|cot)\(([^()]+)\)/g, '$1(($2)*°)');
    }

    let createdLabels: string[] = [];
    try {
      // Remove existing symbol if user redefined e.g. `a = 2`
      if (translation.ggbLabel && this.api.exists(translation.ggbLabel)) {
        this.api.deleteObject(translation.ggbLabel);
      }

      const rawLabels = this.api.evalCommandGetLabels(cmd);
      if (rawLabels && rawLabels.trim()) {
        createdLabels = rawLabels
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean);
      } else if (translation.ggbLabel && this.api.exists(translation.ggbLabel)) {
        createdLabels = [translation.ggbLabel];
      }

      // If 3D mode rejects `d1(x) = rhs`, plot as Curve(t_, rhs(t_), 0) in XY-plane
      if (createdLabels.length === 0 && this.mode === '3d' && translation.kind === 'explicit_2d') {
        const eqIdx = cmd.indexOf('=');
        if (eqIdx !== -1) {
          const lbl = cmd.slice(0, eqIdx).replace(/\(x\)$/, '').trim();
          const rhsT = cmd.slice(eqIdx + 1).trim().replace(/\bx\b/g, 't_');
          const { xmin, xmax } = settings.bounds3D;
          const fallbackCmd = `${lbl} = Curve(t_, ${rhsT}, 0, t_, ${xmin}, ${xmax})`;
          const fbLabels = this.api.evalCommandGetLabels(fallbackCmd);
          if (fbLabels && fbLabels.trim()) {
            createdLabels = fbLabels.split(',').map((s) => s.trim()).filter(Boolean);
          }
        }
      }
    } catch {
      createdLabels = [];
    }

    if (createdLabels.length === 0) {
      // Fallback: in 3D mode some 2D inequalities or constructs aren't supported
      if (this.mode === '3d' && (translation.kind === 'inequality_2d' || translation.kind === 'calculus')) {
        return {
          labels: [],
          feedback: {
            error: null,
            modeNotice: '2D-only construct — switch to 2D mode to plot',
            evalResult: null,
            undefinedVars: [],
            isSlider: false,
          },
        };
      }
      return {
        labels: [],
        feedback: {
          error: 'Could not evaluate expression in GeoGebra',
          modeNotice: null,
          evalResult: null,
          undefinedVars: [],
          isSlider: false,
        },
      };
    }

    this.applyStyles(createdLabels, item, effectiveVisible, translation.isSlider);

    let evalResult: string | null = null;
    if (translation.isNumericEval && createdLabels[0]) {
      evalResult = this.formatNumericResult(createdLabels[0]);
    }

    return {
      labels: createdLabels,
      feedback: {
        error: null,
        modeNotice: null,
        evalResult,
        undefinedVars: [],
        isSlider: translation.isSlider,
        variableName: translation.ggbLabel,
      },
    };
  }

  private readEvalResult(labels: string[], prevFeedback: SyncFeedback): string | null {
    if (!prevFeedback.evalResult && !prevFeedback.isSlider) return prevFeedback.evalResult;
    if (prevFeedback.evalResult && labels[0]) {
      return this.formatNumericResult(labels[0]);
    }
    return prevFeedback.evalResult;
  }

  private formatNumericResult(label: string): string | null {
    try {
      if (!this.api.exists(label)) return null;
      const val = this.api.getValue(label);
      if (typeof val === 'number' && Number.isFinite(val)) {
        const rounded = Math.abs(val) < 1e-12 ? 0 : Number(val.toPrecision(8));
        return String(rounded);
      }
    } catch {
      // ignore
    }
    return null;
  }

  private applyStyles(
    labels: string[],
    item: ExpressionItem,
    effectiveVisible: boolean,
    isSlider: boolean
  ): void {
    const [r, g, b] = hexToRgb(item.color);
    const ggbThickness = Math.max(1, Math.min(13, Math.round(item.lineWidth * 2)));
    const ggbLineStyle = mapLineStyle(item.lineStyle);
    const ggbPointStyle = mapPointStyle(item.pointStyle);

    for (const label of labels) {
      if (!this.api.exists(label)) continue;
      try {
        // Sliders are controlled in our Desmos panel, so hide GeoGebra's native slider widget on the canvas
        if (isSlider) {
          this.api.setVisible(label, false);
          continue;
        }
        this.api.setVisible(label, effectiveVisible);
        this.api.setColor(label, r, g, b);
        this.api.setLineThickness(label, ggbThickness);
        this.api.setLineStyle(label, ggbLineStyle);
        this.api.setPointStyle(label, ggbPointStyle);
        this.api.setPointSize(label, Math.max(1, Math.min(9, item.pointSize)));
        this.api.setLabelVisible(label, Boolean(item.showLabel));
        if (item.showLabel && item.labelText) {
          this.api.setCaption?.(label, item.labelText);
          this.api.setLabelStyle?.(label, 3);
        }
        const objType = this.api.getObjectType?.(label) ?? '';
        if (objType === 'inequality' || objType === 'integral' || objType === 'polygon') {
          this.api.setFilling(label, Math.min(0.45, item.lineOpacity * 0.35));
        }
      } catch {
        // Guard style errors for object types without certain properties
      }
    }
  }

  private createTableObjects(item: ExpressionItem, effectiveVisible: boolean): string[] {
    const cols = item.tableColumns ?? [];
    if (cols.length < 2) return [];
    const xCol = cols[0];
    const created: string[] = [];

    for (let cIdx = 1; cIdx < cols.length; cIdx++) {
      const yCol = cols[cIdx];
      const pointLabels: string[] = [];
      const rowCount = Math.min(xCol.values.length, yCol.values.length);
      for (let rIdx = 0; rIdx < rowCount; rIdx++) {
        const xv = xCol.values[rIdx]?.trim();
        const yv = yCol.values[rIdx]?.trim();
        if (!xv || !yv) continue;
        const xNum = Number(xv);
        const yNum = Number(yv);
        if (Number.isNaN(xNum) || Number.isNaN(yNum)) continue;
        const pLabel = `tbl_${this.labelCounter++}`;
        const res = this.api.evalCommandGetLabels(`${pLabel} = (${xNum}, ${yNum})`);
        if (res) {
          const lbl = res.split(',')[0].trim();
          created.push(lbl);
          pointLabels.push(lbl);
        }
      }
      if (yCol.showLines && pointLabels.length >= 2) {
        const polyLabel = `tblLine_${this.labelCounter++}`;
        const res = this.api.evalCommandGetLabels(`${polyLabel} = PolyLine(${pointLabels.join(', ')})`);
        if (res) {
          created.push(res.split(',')[0].trim());
        }
      }
      this.applyTableColumnStyle(created, yCol, effectiveVisible);
    }
    return created;
  }

  private applyTableStyles(item: ExpressionItem, labels: string[], effectiveVisible: boolean): void {
    const yCol = item.tableColumns?.[1];
    if (!yCol) return;
    this.applyTableColumnStyle(labels, yCol, effectiveVisible);
  }

  private applyTableColumnStyle(
    labels: string[],
    col: NonNullable<ExpressionItem['tableColumns']>[number],
    effectiveVisible: boolean
  ): void {
    const [r, g, b] = hexToRgb(col.color);
    const vis = effectiveVisible && col.visible;
    for (const lbl of labels) {
      if (!this.api.exists(lbl)) continue;
      try {
        const isLine = lbl.startsWith('tblLine_');
        this.api.setVisible(lbl, vis && (isLine ? col.showLines : col.showPoints));
        this.api.setColor(lbl, r, g, b);
        this.api.setLabelVisible(lbl, false);
        if (isLine) {
          this.api.setLineStyle(lbl, mapLineStyle(col.lineStyle));
          this.api.setLineThickness(lbl, 4);
        } else {
          this.api.setPointStyle(lbl, mapPointStyle(col.pointStyle));
          this.api.setPointSize(lbl, 5);
        }
      } catch {
        // ignore
      }
    }
  }

  private deleteLabels(labels: string[]): void {
    for (const lbl of labels) {
      try {
        if (this.api.exists(lbl)) {
          this.api.deleteObject(lbl);
        }
      } catch {
        // ignore
      }
    }
  }

  public clearAll(): void {
    for (const tracked of this.tracked.values()) {
      this.deleteLabels(tracked.ggbLabels);
    }
    this.tracked.clear();
  }
}
