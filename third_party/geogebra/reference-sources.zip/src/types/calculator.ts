export type ViewMode = '2d' | '3d';

export type LineStyleType = 'solid' | 'dashed' | 'dotted';
export type PointStyleType = 'point' | 'open' | 'cross';
export type SliderLoopMode = 'loop' | 'oscillate' | 'once';

export const DESMOS_COLORS = [
  { name: 'Red', hex: '#c74440' },
  { name: 'Blue', hex: '#2d70b3' },
  { name: 'Green', hex: '#388c46' },
  { name: 'Purple', hex: '#6042a6' },
  { name: 'Orange', hex: '#fa7e19' },
  { name: 'Black', hex: '#000000' },
] as const;

export interface SliderConfig {
  min: number;
  max: number;
  step: number;
  playing: boolean;
  speed: number; // multiplier: 0.5, 1, 2, 4
  direction: 1 | -1;
  loopMode: SliderLoopMode;
}

export interface TableColumn {
  id: string;
  header: string; // e.g. 'x_1', 'y_1'
  values: string[];
  color: string;
  visible: boolean;
  showLines: boolean;
  showPoints: boolean;
  pointStyle: PointStyleType;
  lineStyle: LineStyleType;
}

export type ExpressionKind = 'expression' | 'note' | 'folder' | 'table';

export interface ExpressionItem {
  id: string;
  type: ExpressionKind;
  folderId: string | null;
  collapsed?: boolean;
  latex: string;
  color: string;
  visible: boolean;
  lineStyle: LineStyleType;
  lineWidth: number; // Desmos-like scale: 1..6 (default 2.5)
  lineOpacity: number; // 0.1..1
  pointStyle: PointStyleType;
  pointSize: number; // 1..9 (default 4)
  showLabel: boolean;
  labelText: string;
  slider?: SliderConfig;
  noteText?: string;
  tableColumns?: TableColumn[];
  // Computed / runtime status (not persisted as authoritative math)
  error?: string | null;
  modeNotice?: string | null;
  evalResult?: string | null;
  undefinedVars?: string[];
  isSlider?: boolean;
  variableName?: string;
}

export interface GraphSettings {
  showGrid: boolean;
  showMinorGrid: boolean;
  showXAxis: boolean;
  showYAxis: boolean;
  showZAxis: boolean;
  xAxisLabel: string;
  yAxisLabel: string;
  zAxisLabel: string;
  xStep: number | null;
  yStep: number | null;
  angleMode: 'rad' | 'deg';
  polarGrid: boolean;
  reverseContrast: boolean;
  squareAxes: boolean;
  bounds2D: {
    xmin: number;
    xmax: number;
    ymin: number;
    ymax: number;
  };
  bounds3D: {
    xmin: number;
    xmax: number;
    ymin: number;
    ymax: number;
    zmin: number;
    zmax: number;
  };
}

export interface SavedGraph {
  id: string;
  title: string;
  updatedAt: string;
  expressions: ExpressionItem[];
  settings: GraphSettings;
  viewMode: ViewMode;
  ggbXml2d?: string;
  ggbXml3d?: string;
}

export interface ExamplePreset {
  id: string;
  title: string;
  category: '2D Calculus' | '2D Curves' | '3D Surfaces' | 'Interactive';
  recommendedMode: ViewMode;
  description: string;
  expressions: Array<Partial<ExpressionItem> & { type: ExpressionKind }>;
}

export const DEFAULT_SETTINGS: GraphSettings = {
  showGrid: true,
  showMinorGrid: true,
  showXAxis: true,
  showYAxis: true,
  showZAxis: true,
  xAxisLabel: '',
  yAxisLabel: '',
  zAxisLabel: '',
  xStep: null,
  yStep: null,
  angleMode: 'rad',
  polarGrid: false,
  reverseContrast: false,
  squareAxes: false,
  bounds2D: {
    xmin: -10,
    xmax: 10,
    ymin: -6.5,
    ymax: 6.5,
  },
  bounds3D: {
    xmin: -6,
    xmax: 6,
    ymin: -6,
    ymax: 6,
    zmin: -6,
    zmax: 6,
  },
};

export const DEFAULT_SLIDER: SliderConfig = {
  min: -10,
  max: 10,
  step: 0.1,
  playing: false,
  speed: 1,
  direction: 1,
  loopMode: 'oscillate',
};
