import React from 'react';
import { X, ArrowRight } from 'lucide-react';
import { EXAMPLE_PRESETS } from '../engine/presets';
import { ExamplePreset } from '../types/calculator';

interface ExamplesModalProps {
  open: boolean;
  onSelectPreset: (preset: ExamplePreset) => void;
  onClose: () => void;
}

export const ExamplesModal: React.FC<ExamplesModalProps> = ({
  open,
  onSelectPreset,
  onClose,
}) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-label="Example graphs"
        className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-neutral-200 overflow-hidden z-10"
      >
        <div className="h-12 px-5 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="text-sm font-bold text-neutral-900">Example Graphs</h2>
          <button
            type="button"
            aria-label="Close examples modal"
            onClick={onClose}
            className="p-1.5 rounded hover:bg-neutral-100 text-neutral-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[75vh] overflow-y-auto">
          {EXAMPLE_PRESETS.map((preset) => (
            <button
              key={preset.id}
              type="button"
              onClick={() => {
                onSelectPreset(preset);
                onClose();
              }}
              className="text-left p-3.5 rounded-lg border border-neutral-200 hover:border-blue-500 hover:bg-blue-50/30 transition-colors flex flex-col justify-between gap-2 group"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-neutral-900 group-hover:text-blue-700">
                    {preset.title}
                  </span>
                  <span className="text-[11px] font-medium text-neutral-500">
                    {preset.category} · {preset.recommendedMode.toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-neutral-600 mt-1">{preset.description}</p>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-neutral-100 text-[11px] font-math-mono text-neutral-500">
                <span className="truncate">{preset.expressions[0]?.latex}</span>
                <ArrowRight className="w-3.5 h-3.5 shrink-0 text-neutral-400 group-hover:text-blue-600" />
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
