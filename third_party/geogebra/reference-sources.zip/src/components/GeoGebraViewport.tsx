import React, { useEffect, useRef, useState } from 'react';
import { ChevronsRight, Home, Loader2, Minus, Plus, Wrench, AlertCircle } from 'lucide-react';
import { ExpressionItem, GraphSettings, ViewMode } from '../types/calculator';
import { GeoGebraEngineAdapter, GgbApi, SyncFeedback } from '../engine/geogebraAdapter';
import { GraphSettingsPopover } from './GraphSettingsPopover';

declare global {
  interface Window {
    GGBApplet?: new (params: Record<string, unknown>, html5: boolean) => {
      inject: (elementId: string) => void;
    };
  }
}

interface GeoGebraCanvasProps {
  mode: ViewMode;
  active: boolean;
  expressions: ExpressionItem[];
  settings: GraphSettings;
  pendingXml?: string | null;
  onConsumePendingXml?: () => void;
  onFeedback: (mode: ViewMode, feedback: Record<string, SyncFeedback>) => void;
  onAdapterReady: (mode: ViewMode, adapter: GeoGebraEngineAdapter | null) => void;
  onBoundsChange?: (bounds: GraphSettings['bounds2D']) => void;
}

const GeoGebraCanvasInstance: React.FC<GeoGebraCanvasProps> = ({
  mode,
  active,
  expressions,
  settings,
  pendingXml,
  onConsumePendingXml,
  onFeedback,
  onAdapterReady,
  onBoundsChange,
}) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const adapterRef = useRef<GeoGebraEngineAdapter | null>(null);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [retryCount, setRetryCount] = useState(0);

  const expressionsRef = useRef(expressions);
  const settingsRef = useRef(settings);
  const activeRef = useRef(active);
  expressionsRef.current = expressions;
  settingsRef.current = settings;
  activeRef.current = active;

  const elementId = mode === '2d' ? 'ggb-container-2d' : 'ggb-container-3d';
  const appletId = mode === '2d' ? 'ggbApplet2D' : 'ggbApplet3D';

  useEffect(() => {
    let cancelled = false;
    let pollTimer: number | null = null;
    let timeoutTimer: number | null = null;
    let rafId: number | null = null;

    const initApplet = () => {
      if (cancelled || !window.GGBApplet || !hostRef.current) return;
      const rect = hostRef.current.getBoundingClientRect();
      const width = Math.max(320, Math.round(rect.width || 900));
      const height = Math.max(300, Math.round(rect.height || 700));

      hostRef.current.innerHTML = `<div id="${elementId}" class="w-full h-full"></div>`;

      const params: Record<string, unknown> = {
        id: appletId,
        appName: mode === '2d' ? 'graphing' : '3d',
        width,
        height,
        showToolBar: false,
        showAlgebraInput: false,
        showMenuBar: false,
        showResetIcon: false,
        showZoomButtons: false,
        showFullscreenButton: false,
        allowStyleBar: false,
        enableLabelDrags: false,
        enableShiftDragZoom: true,
        enableRightClick: false,
        showToolBarHelp: false,
        preventFocus: true,
        borderColor: null,
        useBrowserForJS: true,
        appletOnLoad: (api: GgbApi) => {
          if (cancelled) return;
          try {
            api.setPerspective(mode === '2d' ? 'G' : 'T');
            api.setMode?.(0);
          } catch {
            // ignore
          }
          const adapter = new GeoGebraEngineAdapter(api, mode);
          adapterRef.current = adapter;
          onAdapterReady(mode, adapter);
          adapter.applySettings(settingsRef.current, true);
          const fb = adapter.syncExpressions(expressionsRef.current, settingsRef.current);
          onFeedback(mode, fb);
          setStatus('ready');
        },
      };

      try {
        const applet = new window.GGBApplet(params, true);
        applet.inject(elementId);
      } catch {
        if (!cancelled) setStatus('error');
      }
    };

    const scheduleInit = () => {
      rafId = window.requestAnimationFrame(() => {
        if (!cancelled) initApplet();
      });
    };

    if (window.GGBApplet) {
      scheduleInit();
    } else {
      pollTimer = window.setInterval(() => {
        if (window.GGBApplet) {
          if (pollTimer) window.clearInterval(pollTimer);
          if (timeoutTimer) window.clearTimeout(timeoutTimer);
          scheduleInit();
        }
      }, 60);

      timeoutTimer = window.setTimeout(() => {
        if (!window.GGBApplet && !cancelled) {
          if (pollTimer) window.clearInterval(pollTimer);
          setStatus('error');
        }
      }, 15000);
    }

    return () => {
      cancelled = true;
      if (rafId !== null) window.cancelAnimationFrame(rafId);
      if (pollTimer) window.clearInterval(pollTimer);
      if (timeoutTimer) window.clearTimeout(timeoutTimer);
      if (hostRef.current) hostRef.current.innerHTML = '';
      onAdapterReady(mode, null);
      adapterRef.current = null;
    };
  }, [mode, retryCount]);

  // Keep GeoGebra sized cleanly when container resizes
  useEffect(() => {
    const el = hostRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (!entry || !adapterRef.current) return;
      const w = Math.round(entry.contentRect.width);
      const h = Math.round(entry.contentRect.height);
      if (w > 50 && h > 50) {
        const api = adapterRef.current.getApi() as GgbApi & {
          setSize?: (w: number, h: number) => void;
          recalculateEnvironments?: () => void;
        };
        try {
          const scaler = el.querySelector('.applet_scaler') as HTMLElement | null;
          if (scaler) {
            scaler.style.transform = 'none';
            scaler.style.width = `${w}px`;
            scaler.style.height = `${h}px`;
          }
          api.setSize?.(w, h);
          api.recalculateEnvironments?.();
        } catch {
          // ignore
        }
      }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Reconcile expressions whenever expressions or settings change (or when becoming active)
  useEffect(() => {
    const adapter = adapterRef.current;
    if (!adapter || status !== 'ready') return;
    const fb = adapter.syncExpressions(expressions, settings);
    if (active) {
      onFeedback(mode, fb);
    }
  }, [expressions, settings.angleMode, status, active]);

  // Apply graph settings changes
  useEffect(() => {
    const adapter = adapterRef.current;
    if (!adapter || status !== 'ready') return;
    adapter.applySettings(settings, false);
  }, [
    settings.showGrid,
    settings.showMinorGrid,
    settings.showXAxis,
    settings.showYAxis,
    settings.showZAxis,
    settings.polarGrid,
    settings.xAxisLabel,
    settings.yAxisLabel,
    settings.zAxisLabel,
    status,
  ]);

  // Apply explicit XML restore if provided on graph load
  useEffect(() => {
    const adapter = adapterRef.current;
    if (!adapter || status !== 'ready' || !pendingXml) return;
    try {
      adapter.getApi().setXML(pendingXml);
      adapter.getApi().setPerspective(mode === '2d' ? 'G' : 'T');
      adapter.applySettings(settings, false);
      const fb = adapter.syncExpressions(expressions, settings);
      onFeedback(mode, fb);
    } catch {
      // Fallback to normal expression sync
    } finally {
      onConsumePendingXml?.();
    }
  }, [pendingXml, status]);

  // Periodically sync 2D bounds back for coordinate readout after pan/zoom
  const handlePointerEnd = () => {
    if (mode !== '2d' || !adapterRef.current || !onBoundsChange) return;
    const next = adapterRef.current.readBounds2D();
    if (next) onBoundsChange(next);
  };

  return (
    <div
      data-testid={`geogebra-viewport-${mode}`}
      onMouseUp={handlePointerEnd}
      onWheel={() => window.setTimeout(handlePointerEnd, 80)}
      className={`absolute inset-0 transition-opacity duration-150 ${
        active ? 'opacity-100 pointer-events-auto z-10' : 'opacity-0 pointer-events-none z-0'
      }`}
    >
      <div
        ref={hostRef}
        className={`w-full h-full ggb-host bg-white ${
          settings.reverseContrast ? 'invert hue-rotate-180' : ''
        }`}
      />

      {status === 'loading' && (
        <div className="absolute inset-0 bg-white/90 flex flex-col items-center justify-center gap-2 text-neutral-600 text-sm z-20">
          <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
          <span className="font-medium">
            Initializing GeoGebra {mode === '3d' ? '3D' : '2D'} Engine...
          </span>
        </div>
      )}

      {status === 'error' && (
        <div className="absolute inset-0 bg-white flex flex-col items-center justify-center gap-3 p-6 text-center z-20">
          <AlertCircle className="w-8 h-8 text-amber-600" />
          <div className="max-w-sm space-y-1">
            <h3 className="text-sm font-semibold text-neutral-900">
              GeoGebra Engine Failed to Load
            </h3>
            <p className="text-xs text-neutral-600">
              Ensure network access to geogebra.org is available, then retry.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setStatus('loading');
              setRetryCount((c) => c + 1);
            }}
            className="px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
          >
            Retry Engine
          </button>
        </div>
      )}
    </div>
  );
};

interface GraphViewportProps {
  viewMode: ViewMode;
  expressions: ExpressionItem[];
  settings: GraphSettings;
  sidebarCollapsed: boolean;
  pendingXml2d?: string | null;
  pendingXml3d?: string | null;
  onConsumePendingXml: (mode: ViewMode) => void;
  onExpandSidebar: () => void;
  onSettingsChange: (next: GraphSettings, applyBounds?: boolean) => void;
  onFeedback: (mode: ViewMode, feedback: Record<string, SyncFeedback>) => void;
  onAdapterReady: (mode: ViewMode, adapter: GeoGebraEngineAdapter | null) => void;
  adaptersRef: React.MutableRefObject<{
    '2d': GeoGebraEngineAdapter | null;
    '3d': GeoGebraEngineAdapter | null;
  }>;
}

export const GraphViewport: React.FC<GraphViewportProps> = ({
  viewMode,
  expressions,
  settings,
  sidebarCollapsed,
  pendingXml2d,
  pendingXml3d,
  onConsumePendingXml,
  onExpandSidebar,
  onSettingsChange,
  onFeedback,
  onAdapterReady,
  adaptersRef,
}) => {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [hasMounted3D, setHasMounted3D] = useState(viewMode === '3d');
  const [pointerCoord, setPointerCoord] = useState<{ x: string; y: string } | null>(null);
  const viewportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (viewMode === '3d') {
      setHasMounted3D(true);
    }
  }, [viewMode]);

  const handleZoom = (factor: number) => {
    const adapter = adaptersRef.current[viewMode];
    if (!adapter) return;
    const nextBounds = adapter.zoom(factor, settings);
    if (nextBounds) {
      onSettingsChange({ ...settings, bounds2D: nextBounds }, false);
    }
  };

  const handleResetView = () => {
    const adapter = adaptersRef.current[viewMode];
    if (!adapter) return;
    adapter.resetView(settings);
    if (viewMode === '2d') {
      onSettingsChange(
        {
          ...settings,
          bounds2D: { xmin: -10, xmax: 10, ymin: -6.5, ymax: 6.5 },
        },
        false
      );
    }
  };

  const handleSettingsUpdate = (next: GraphSettings, applyBounds = false) => {
    onSettingsChange(next, applyBounds);
    const adapter = adaptersRef.current[viewMode];
    if (adapter) {
      adapter.applySettings(next, applyBounds);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (viewMode !== '2d' || !viewportRef.current) {
      setPointerCoord(null);
      return;
    }
    const rect = viewportRef.current.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const { xmin, xmax, ymin, ymax } = settings.bounds2D;
    const rx = (e.clientX - rect.left) / rect.width;
    const ry = 1 - (e.clientY - rect.top) / rect.height;
    const xVal = xmin + rx * (xmax - xmin);
    const yVal = ymin + ry * (ymax - ymin);
    setPointerCoord({
      x: xVal.toFixed(2),
      y: yVal.toFixed(2),
    });
  };

  return (
    <main
      ref={viewportRef}
      data-testid="graph-viewport"
      data-view-mode={viewMode}
      onMouseMove={handleMouseMove}
      onMouseLeave={() => setPointerCoord(null)}
      className="flex-1 h-full relative bg-white overflow-hidden select-none"
    >
      {/* 2D GeoGebra Viewport (always mounted, shown when viewMode === '2d') */}
      <GeoGebraCanvasInstance
        mode="2d"
        active={viewMode === '2d'}
        expressions={expressions}
        settings={settings}
        pendingXml={pendingXml2d}
        onConsumePendingXml={() => onConsumePendingXml('2d')}
        onFeedback={onFeedback}
        onAdapterReady={onAdapterReady}
        onBoundsChange={(bounds2D) =>
          onSettingsChange({ ...settings, bounds2D }, false)
        }
      />

      {/* 3D GeoGebra Viewport (lazy-mounted on first 3D toggle, persistent thereafter) */}
      {hasMounted3D && (
        <GeoGebraCanvasInstance
          mode="3d"
          active={viewMode === '3d'}
          expressions={expressions}
          settings={settings}
          pendingXml={pendingXml3d}
          onConsumePendingXml={() => onConsumePendingXml('3d')}
          onFeedback={onFeedback}
          onAdapterReady={onAdapterReady}
        />
      )}

      {/* Top-Left Expand Sidebar Button when Collapsed */}
      {sidebarCollapsed && (
        <button
          type="button"
          aria-label="Show expression list"
          title="Show Expression List"
          onClick={onExpandSidebar}
          className="absolute top-3 left-3 z-20 h-9 w-9 rounded-lg bg-white/95 hover:bg-white border border-neutral-300 shadow-md text-neutral-700 inline-flex items-center justify-center transition-colors"
        >
          <ChevronsRight className="w-4 h-4" />
        </button>
      )}

      {/* Top-Right Desmos Floating Viewport Controls */}
      <div className="absolute top-3 right-3 z-20 flex flex-col items-end gap-2">
        <button
          type="button"
          data-testid="graph-settings-button"
          aria-label="Graph settings"
          aria-expanded={settingsOpen}
          title="Graph Settings"
          onClick={() => setSettingsOpen((o) => !o)}
          className={`h-9 w-9 rounded-lg border shadow-md inline-flex items-center justify-center transition-colors ${
            settingsOpen
              ? 'bg-neutral-800 text-white border-neutral-800'
              : 'bg-white/95 hover:bg-white text-neutral-700 border-neutral-300'
          }`}
        >
          <Wrench className="w-4 h-4" />
        </button>

        <div className="flex flex-col rounded-lg border border-neutral-300 bg-white/95 shadow-md overflow-hidden divide-y divide-neutral-200">
          <button
            type="button"
            data-testid="zoom-in-button"
            aria-label="Zoom in"
            title="Zoom In"
            onClick={() => handleZoom(0.75)}
            className="h-9 w-9 hover:bg-neutral-100 text-neutral-700 inline-flex items-center justify-center transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            type="button"
            data-testid="zoom-out-button"
            aria-label="Zoom out"
            title="Zoom Out"
            onClick={() => handleZoom(1.333)}
            className="h-9 w-9 hover:bg-neutral-100 text-neutral-700 inline-flex items-center justify-center transition-colors"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            type="button"
            data-testid="reset-view-button"
            aria-label="Reset view"
            title="Reset Default Viewport"
            onClick={handleResetView}
            className="h-9 w-9 hover:bg-neutral-100 text-neutral-700 inline-flex items-center justify-center transition-colors"
          >
            <Home className="w-4 h-4" />
          </button>
        </div>

        {settingsOpen && (
          <GraphSettingsPopover
            settings={settings}
            viewMode={viewMode}
            onChange={handleSettingsUpdate}
            onClose={() => setSettingsOpen(false)}
          />
        )}
      </div>

      {/* Subtle Bottom-Left Coordinate / 3D Orbit Readout */}
      {viewMode === '2d' && pointerCoord && (
        <div className="absolute bottom-3 left-3 z-20 px-2.5 py-1 rounded bg-white/90 border border-neutral-200 shadow-xs text-[11px] font-math-mono tabular-nums text-neutral-600 pointer-events-none">
          ({pointerCoord.x}, {pointerCoord.y})
        </div>
      )}
      {viewMode === '3d' && (
        <div className="absolute bottom-3 left-3 z-20 px-2.5 py-1 rounded bg-white/90 border border-neutral-200 shadow-xs text-[11px] text-neutral-600 pointer-events-none">
          Drag to orbit · Scroll to zoom
        </div>
      )}
    </main>
  );
};
