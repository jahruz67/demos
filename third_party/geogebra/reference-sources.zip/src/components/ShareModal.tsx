import React, { useState, useRef } from 'react';
import { Check, Copy, Download, ImageDown, Upload, X } from 'lucide-react';
import { WorkspaceSnapshot } from '../engine/storage';

interface ShareModalProps {
  open: boolean;
  shareUrl: string;
  snapshot: WorkspaceSnapshot;
  onExportPng: () => string | null;
  onImportSnapshot: (snap: WorkspaceSnapshot) => void;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  open,
  shareUrl,
  snapshot,
  onExportPng,
  onImportSnapshot,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);
  const [importError, setImportError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!open) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Fallback
    }
  };

  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(snapshot.title || 'graph').toLowerCase().replace(/[^a-z0-9]+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadPng = () => {
    const base64 = onExportPng();
    if (!base64) return;
    const a = document.createElement('a');
    a.href = base64.startsWith('data:') ? base64 : `data:image/png;base64,${base64}`;
    a.download = `${(snapshot.title || 'graph').toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`;
    a.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImportError(null);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as WorkspaceSnapshot;
      if (!Array.isArray(parsed.expressions)) {
        setImportError('Invalid graph JSON file.');
        return;
      }
      onImportSnapshot(parsed);
      onClose();
    } catch {
      setImportError('Failed to parse JSON file.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-label="Share and export graph"
        className="relative w-full max-w-md bg-white rounded-xl shadow-2xl border border-neutral-200 overflow-hidden z-10"
      >
        <div className="h-12 px-5 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="text-sm font-bold text-neutral-900">Share &amp; Export Graph</h2>
          <button
            type="button"
            aria-label="Close share modal"
            onClick={onClose}
            className="p-1.5 rounded hover:bg-neutral-100 text-neutral-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          {/* Shareable Link */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1.5">
              Shareable Graph URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                aria-label="Shareable URL"
                className="flex-1 min-w-0 px-2.5 py-2 rounded border border-neutral-300 bg-neutral-50 font-math-mono text-[11px] text-neutral-700 outline-none"
              />
              <button
                type="button"
                onClick={handleCopy}
                className="h-8 px-3 rounded bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5 shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Export Options */}
          <div className="pt-2 border-t border-neutral-100 grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={handleDownloadPng}
              className="h-9 px-3 rounded-lg border border-neutral-300 hover:bg-neutral-50 text-neutral-800 font-semibold inline-flex items-center justify-center gap-2"
            >
              <ImageDown className="w-4 h-4 text-blue-600" />
              <span>Export PNG</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadJson}
              className="h-9 px-3 rounded-lg border border-neutral-300 hover:bg-neutral-50 text-neutral-800 font-semibold inline-flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>Export JSON</span>
            </button>
          </div>

          {/* Import JSON */}
          <div className="pt-2 border-t border-neutral-100">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-9 px-3 rounded-lg border border-dashed border-neutral-300 hover:border-blue-500 hover:bg-blue-50/30 text-neutral-700 font-semibold inline-flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              <span>Import Graph JSON</span>
            </button>
            {importError && (
              <p className="mt-1.5 text-[11px] text-red-600">{importError}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
