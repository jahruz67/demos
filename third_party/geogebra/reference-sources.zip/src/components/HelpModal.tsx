import React from 'react';
import { X } from 'lucide-react';

interface HelpModalProps {
  open: boolean;
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-label="Syntax guide and GeoGebra attribution"
        className="relative w-full max-w-xl bg-white rounded-xl shadow-2xl border border-neutral-200 overflow-hidden z-10"
      >
        <div className="h-12 px-5 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="text-sm font-bold text-neutral-900">
            Syntax Guide &amp; Engine Attribution
          </h2>
          <button
            type="button"
            aria-label="Close help modal"
            onClick={onClose}
            className="p-1.5 rounded hover:bg-neutral-100 text-neutral-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs text-neutral-700 max-h-[75vh] overflow-y-auto">
          <div>
            <h3 className="font-bold text-neutral-900 mb-2">Supported Desmos-Style Syntax</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 font-math-mono text-[11px]">
              <div className="p-2 rounded bg-neutral-50 border border-neutral-200">
                <div className="font-sans font-semibold text-neutral-700 mb-0.5">Explicit &amp; Implicit</div>
                <div>y = x^2, y = sin(x)</div>
                <div>x^2 + y^2 = 25</div>
              </div>
              <div className="p-2 rounded bg-neutral-50 border border-neutral-200">
                <div className="font-sans font-semibold text-neutral-700 mb-0.5">Restrictions &amp; Piecewise</div>
                <div>y = x^2 {'{x > 0}'}</div>
                <div>y = {'{x < 0: -x, x^2}'}</div>
              </div>
              <div className="p-2 rounded bg-neutral-50 border border-neutral-200">
                <div className="font-sans font-semibold text-neutral-700 mb-0.5">Polar &amp; Parametric</div>
                <div>r = 2*sin(3*theta)</div>
                <div>(cos(t), sin(t)) {'{0 <= t <= 2*pi}'}</div>
              </div>
              <div className="p-2 rounded bg-neutral-50 border border-neutral-200">
                <div className="font-sans font-semibold text-neutral-700 mb-0.5">Calculus &amp; Sums</div>
                <div>d/dx(x^3 - 2*x)</div>
                <div>integral(x^2, x, 0, 2)</div>
                <div>sum(n=1, 5, x^n / n)</div>
              </div>
              <div className="p-2 rounded bg-neutral-50 border border-neutral-200 sm:col-span-2">
                <div className="font-sans font-semibold text-neutral-700 mb-0.5">3D Surfaces &amp; Equations (3D Mode)</div>
                <div>z = sin(x)*cos(y) · x^2 + y^2 + z^2 = 25 · x + y + z = 5</div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-neutral-200 space-y-1.5">
            <h3 className="font-bold text-neutral-900">GeoGebra Engine &amp; Licensing Notice</h3>
            <p className="leading-relaxed text-neutral-600">
              All mathematical parsing, symbolic evaluation, 2D plotting, and 3D WebGL surface
              rendering are powered by the{' '}
              <a
                href="https://www.geogebra.org/"
                target="_blank"
                rel="noreferrer"
                className="text-blue-600 hover:underline font-medium"
              >
                GeoGebra
              </a>{' '}
              JavaScript Apps API (<code>appName: &quot;graphing&quot;</code> and{' '}
              <code>appName: &quot;3d&quot;</code>). GeoGebra source code is available at{' '}
              <a
                href="https://github.com/geogebra/geogebra"
                target="_blank"
                rel="noreferrer"
                className="text-blue-600 hover:underline font-medium"
              >
                github.com/geogebra/geogebra
              </a>{' '}
              under the GNU GPL / EUPL and GeoGebra Non-Commercial License terms.
            </p>
            <p className="leading-relaxed text-neutral-500">
              Note: Some 2D-only constructs (such as 2D shaded inequalities or definite area
              integrals) automatically pause in 3D mode while remaining editable in the expression
              list.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
