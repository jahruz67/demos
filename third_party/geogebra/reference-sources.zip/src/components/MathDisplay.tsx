import React, { useMemo } from 'react';
import katex from 'katex';
import { toDisplayLatex } from '../engine/desmosTranslator';

interface MathDisplayProps {
  expression: string;
  className?: string;
}

export const MathDisplay: React.FC<MathDisplayProps> = ({ expression, className = '' }) => {
  const html = useMemo(() => {
    const latex = toDisplayLatex(expression);
    if (!latex) return '';
    try {
      return katex.renderToString(latex, {
        throwOnError: false,
        displayMode: false,
        strict: false,
      });
    } catch {
      return '';
    }
  }, [expression]);

  if (!expression.trim()) {
    return <span className={`text-neutral-400 italic text-sm ${className}`}>Enter expression...</span>;
  }

  if (!html) {
    return <span className={`font-math-mono text-sm text-neutral-900 ${className}`}>{expression}</span>;
  }

  return (
    <span
      className={`text-[15px] text-neutral-900 leading-snug ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};
