import React, { useState, useRef, useEffect } from 'react';
import {
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  Copy,
  Folder,
  GripVertical,
  Info,
  Pause,
  Play,
  Plus,
  Repeat,
  ArrowLeftRight,
  ArrowRight,
  SlidersHorizontal,
  Table2,
  Trash2,
  X,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import {
  DEFAULT_SLIDER,
  ExpressionItem,
  SliderConfig,
  SliderLoopMode,
} from '../types/calculator';
import { ExpressionStylePopover } from './ExpressionStylePopover';

interface ExpressionRowProps {
  item: ExpressionItem;
  index: number;
  isFocused: boolean;
  editMode: boolean;
  inFolder?: boolean;
  inputRefCallback?: (el: HTMLInputElement | null) => void;
  onFocus: () => void;
  onChange: (patch: Partial<ExpressionItem>, recordHistory?: boolean) => void;
  onDelete: () => void;
  onDuplicate: () => void;
  onEnterNew: () => void;
  onAddSliderVars: (vars: string[]) => void;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onDragStart: (e: React.DragEvent) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent) => void;
}

export const ExpressionRow: React.FC<ExpressionRowProps> = ({
  item,
  index,
  isFocused,
  editMode,
  inFolder = false,
  inputRefCallback,
  onFocus,
  onChange,
  onDelete,
  onDuplicate,
  onEnterNew,
  onAddSliderVars,
  onMoveUp,
  onMoveDown,
  onDragStart,
  onDragOver,
  onDrop,
}) => {
  const [styleOpen, setStyleOpen] = useState(false);
  const [editingBounds, setEditingBounds] = useState(false);
  const localInputRef = useRef<HTMLInputElement | null>(null);

  const setInputRef = (el: HTMLInputElement | null) => {
    localInputRef.current = el;
    inputRefCallback?.(el);
  };

  useEffect(() => {
    if (isFocused && localInputRef.current && document.activeElement !== localInputRef.current) {
      // Only auto-focus if requested programmatically
    }
  }, [isFocused]);

  // Parse slider numeric value when item is a slider
  const sliderMatch = item.latex.trim().match(/^([a-zA-Z][a-zA-Z0-9_]*)\s*=\s*(-?\d*\.?\d+)$/);
  const sliderVarName = sliderMatch?.[1] ?? item.variableName ?? 'a';
  const sliderValue = sliderMatch ? parseFloat(sliderMatch[2]) : 1;
  const sliderCfg: SliderConfig = item.slider ?? DEFAULT_SLIDER;
  const showSliderUI = Boolean(sliderMatch || item.isSlider || item.slider);

  const handleSliderValueChange = (nextVal: number, recordHistory = false) => {
    const rounded = Number(nextVal.toFixed(6));
    onChange(
      {
        latex: `${sliderVarName} = ${rounded}`,
        slider: sliderCfg,
      },
      recordHistory
    );
  };

  const updateSliderConfig = (patch: Partial<SliderConfig>) => {
    onChange({
      slider: {
        ...sliderCfg,
        ...patch,
      },
    });
  };

  const cycleLoopMode = () => {
    const order: SliderLoopMode[] = ['oscillate', 'loop', 'once'];
    const idx = order.indexOf(sliderCfg.loopMode);
    updateSliderConfig({ loopMode: order[(idx + 1) % order.length] });
  };

  const cycleSpeed = () => {
    const speeds = [0.5, 1, 2, 4];
    const idx = speeds.indexOf(sliderCfg.speed);
    updateSliderConfig({ speed: speeds[(idx + 1) % speeds.length] });
  };

  // Folder row
  if (item.type === 'folder') {
    return (
      <div
        draggable
        onDragStart={onDragStart}
        onDragOver={onDragOver}
        onDrop={onDrop}
        data-testid={`expr-row-${item.id}`}
        className={`group flex border-b border-neutral-200 bg-neutral-50 transition-colors ${
          isFocused ? 'ring-1 ring-inset ring-blue-500' : ''
        }`}
      >
        {/* Left Gutter */}
        <div className="w-10 shrink-0 bg-[#f4f4f4] border-r border-neutral-200 flex flex-col items-center justify-between py-1.5 select-none">
          <span className="text-[10px] font-medium text-neutral-400 tabular-nums leading-none">
            {index + 1}
          </span>
          <button
            type="button"
            aria-label={item.visible ? `Hide folder ${item.noteText || index + 1}` : `Show folder ${item.noteText || index + 1}`}
            onClick={() => onChange({ visible: !item.visible })}
            className={`w-6 h-6 rounded flex items-center justify-center transition-colors ${
              item.visible ? 'text-neutral-700 hover:bg-neutral-200' : 'text-neutral-300 hover:bg-neutral-200'
            }`}
          >
            <Folder className="w-4 h-4" />
          </button>
          <span className="h-2" />
        </div>

        {/* Folder Content */}
        <div className="flex-1 min-w-0 px-2.5 py-2 flex items-center gap-1.5">
          <button
            type="button"
            aria-label={item.collapsed ? 'Expand folder' : 'Collapse folder'}
            onClick={() => onChange({ collapsed: !item.collapsed })}
            className="p-1 rounded hover:bg-neutral-200 text-neutral-600 shrink-0"
          >
            {item.collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          <input
            type="text"
            value={item.noteText ?? ''}
            placeholder="Folder name"
            aria-label={`Folder ${index + 1} name`}
            onFocus={onFocus}
            onChange={(e) => onChange({ noteText: e.target.value })}
            className="flex-1 min-w-0 bg-transparent text-sm font-semibold text-neutral-800 outline-none"
          />
          {editMode ? (
            <div className="flex items-center gap-0.5 shrink-0">
              {onMoveUp && (
                <button type="button" aria-label="Move folder up" onClick={onMoveUp} className="p-1 text-neutral-500 hover:text-neutral-800">
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
              )}
              {onMoveDown && (
                <button type="button" aria-label="Move folder down" onClick={onMoveDown} className="p-1 text-neutral-500 hover:text-neutral-800">
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              )}
              <button type="button" aria-label="Delete folder" onClick={onDelete} className="p-1 text-red-500 hover:text-red-700">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              aria-label={`Delete folder ${index + 1}`}
              onClick={onDelete}
              className="opacity-0 group-hover:opacity-100 focus:opacity-100 p-1 rounded hover:bg-neutral-200 text-neutral-400 hover:text-neutral-700 transition-opacity"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    );
  }

  // Note row
  if (item.type === 'note') {
    return (
      <div
        draggable
        onDragStart={onDragStart}
        onDragOver={onDragOver}
        onDrop={onDrop}
        data-testid={`expr-row-${item.id}`}
        className={`group flex border-b border-neutral-200 bg-white transition-colors ${
          inFolder ? 'pl-3 bg-neutral-50/40' : ''
        } ${isFocused ? 'ring-1 ring-inset ring-blue-500' : ''}`}
      >
        <div className="w-10 shrink-0 bg-[#f4f4f4] border-r border-neutral-200 flex flex-col items-center justify-between py-1.5 select-none">
          <span className="text-[10px] font-medium text-neutral-400 tabular-nums leading-none">
            {index + 1}
          </span>
          <span className="text-sm font-serif font-bold text-neutral-400 leading-none">"</span>
          <span className="h-2" />
        </div>
        <div className="flex-1 min-w-0 px-2.5 py-2 flex items-start gap-2">
          <textarea
            rows={2}
            value={item.noteText ?? ''}
            placeholder="Enter a note..."
            aria-label={`Note ${index + 1}`}
            onFocus={onFocus}
            onChange={(e) => onChange({ noteText: e.target.value })}
            className="flex-1 min-w-0 resize-none bg-transparent text-sm text-neutral-700 outline-none leading-relaxed"
          />
          <button
            type="button"
            aria-label={`Delete note ${index + 1}`}
            onClick={onDelete}
            className="opacity-0 group-hover:opacity-100 focus:opacity-100 p-1 rounded hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 transition-opacity shrink-0"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  // Table row
  if (item.type === 'table') {
    const cols = item.tableColumns ?? [];
    const xCol = cols[0];
    const yCol = cols[1];
    const rowCount = Math.max(xCol?.values.length ?? 0, yCol?.values.length ?? 0);

    const updateCell = (colIdx: number, rowIdx: number, value: string) => {
      const nextCols = cols.map((c, idx) => {
        if (idx !== colIdx) return c;
        const nextVals = [...c.values];
        nextVals[rowIdx] = value;
        return { ...c, values: nextVals };
      });
      // Auto-append blank row if typing in last row
      if (rowIdx === rowCount - 1 && value.trim() !== '') {
        nextCols.forEach((c) => c.values.push(''));
      }
      onChange({ tableColumns: nextCols });
    };

    return (
      <div
        draggable
        onDragStart={onDragStart}
        onDragOver={onDragOver}
        onDrop={onDrop}
        data-testid={`expr-row-${item.id}`}
        className={`group flex border-b border-neutral-200 bg-white ${
          inFolder ? 'pl-3' : ''
        } ${isFocused ? 'ring-1 ring-inset ring-blue-500' : ''}`}
      >
        <div className="w-10 shrink-0 bg-[#f4f4f4] border-r border-neutral-200 flex flex-col items-center justify-between py-1.5 select-none">
          <span className="text-[10px] font-medium text-neutral-400 tabular-nums leading-none">
            {index + 1}
          </span>
          <button
            type="button"
            aria-label={`Toggle table ${index + 1} visibility`}
            onClick={() => onChange({ visible: !item.visible })}
            style={{
              backgroundColor: item.visible ? (yCol?.color ?? item.color) : 'transparent',
              borderColor: yCol?.color ?? item.color,
            }}
            className="w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors"
          >
            <Table2 className={`w-3 h-3 ${item.visible ? 'text-white' : 'text-neutral-400'}`} />
          </button>
          <span className="h-2" />
        </div>

        <div className="flex-1 min-w-0 p-2">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-2 text-xs text-neutral-600">
              <span className="font-semibold">Table</span>
              {yCol && (
                <label className="inline-flex items-center gap-1 cursor-pointer text-[11px]">
                  <input
                    type="checkbox"
                    checked={yCol.showLines}
                    onChange={(e) => {
                      const nextCols = cols.map((c, idx) =>
                        idx === 1 ? { ...c, showLines: e.target.checked } : c
                      );
                      onChange({ tableColumns: nextCols });
                    }}
                    className="rounded border-neutral-300 text-blue-600"
                  />
                  <span>Connect lines</span>
                </label>
              )}
            </div>
            <button
              type="button"
              aria-label={`Delete table ${index + 1}`}
              onClick={onDelete}
              className="p-1 rounded hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="border border-neutral-200 rounded overflow-hidden">
            <table className="w-full text-xs border-collapse tabular-nums">
              <thead>
                <tr className="bg-neutral-100 border-b border-neutral-200">
                  {cols.map((col) => (
                    <th key={col.id} className="py-1 px-2 text-left font-semibold text-neutral-700 border-r last:border-r-0 border-neutral-200">
                      {col.header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {Array.from({ length: rowCount }).map((_, rIdx) => (
                  <tr key={rIdx} className="border-b last:border-b-0 border-neutral-100">
                    {cols.map((col, cIdx) => (
                      <td key={col.id} className="border-r last:border-r-0 border-neutral-200 p-0">
                        <input
                          type="text"
                          value={col.values[rIdx] ?? ''}
                          aria-label={`${col.header} row ${rIdx + 1}`}
                          onFocus={onFocus}
                          onChange={(e) => updateCell(cIdx, rIdx, e.target.value)}
                          className="w-full px-2 py-1 text-xs font-math-mono bg-transparent outline-none focus:bg-blue-50/40"
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // Standard mathematical expression row
  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      data-testid={`expr-row-${item.id}`}
      className={`group flex border-b border-neutral-200 bg-white transition-colors ${
        inFolder ? 'pl-3 bg-neutral-50/30' : ''
      } ${isFocused ? 'bg-blue-50/20 ring-1 ring-inset ring-blue-500' : 'hover:bg-neutral-50/50'}`}
    >
      {/* Left Desmos Gutter */}
      <div className="w-10 shrink-0 bg-[#f4f4f4] border-r border-neutral-200 flex flex-col items-center justify-between py-1.5 select-none">
        <span className="text-[10px] font-medium text-neutral-400 tabular-nums leading-none">
          {index + 1}
        </span>

        {item.error ? (
          <div
            title={item.error}
            aria-label={`Error in expression ${index + 1}: ${item.error}`}
            className="w-6 h-6 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
          </div>
        ) : item.modeNotice ? (
          <div
            title={item.modeNotice}
            aria-label={item.modeNotice}
            className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center"
          >
            <Info className="w-3.5 h-3.5" />
          </div>
        ) : (
          <button
            type="button"
            aria-label={
              item.visible
                ? `Hide expression ${index + 1}`
                : `Show expression ${index + 1}`
            }
            title="Click to toggle visibility · Gear icon for color & style"
            onClick={() => onChange({ visible: !item.visible })}
            style={{
              backgroundColor: item.visible ? item.color : 'transparent',
              borderColor: item.color,
            }}
            className="w-5 h-5 rounded-full border-2 transition-transform hover:scale-110 focus-visible:outline-2 focus-visible:outline-blue-500"
          />
        )}

        <div className="opacity-0 group-hover:opacity-100 transition-opacity text-neutral-400 cursor-grab active:cursor-grabbing">
          <GripVertical className="w-3 h-3" />
        </div>
      </div>

      {/* Main Expression Content */}
      <div className="flex-1 min-w-0 px-2.5 py-2">
        <div className="flex items-center gap-1.5">
          <input
            ref={setInputRef}
            type="text"
            value={item.latex}
            placeholder="Type math, e.g. y = sin(x) or z = x^2 + y^2"
            aria-label={`Expression ${index + 1}`}
            onFocus={onFocus}
            onChange={(e) => onChange({ latex: e.target.value })}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                onEnterNew();
              } else if (e.key === 'Backspace' && item.latex === '' && index > 0) {
                e.preventDefault();
                onDelete();
              }
            }}
            className="flex-1 min-w-0 bg-transparent text-[15px] font-medium font-math-mono text-neutral-900 placeholder:text-neutral-400 placeholder:font-sans placeholder:text-xs outline-none py-1"
          />

          {/* Quick Actions (Style, Duplicate, Delete, Reorder) */}
          <div className="flex items-center gap-0.5 shrink-0">
            {editMode ? (
              <>
                {onMoveUp && (
                  <button
                    type="button"
                    aria-label={`Move expression ${index + 1} up`}
                    onClick={onMoveUp}
                    className="p-1 rounded hover:bg-neutral-100 text-neutral-500 hover:text-neutral-800"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                )}
                {onMoveDown && (
                  <button
                    type="button"
                    aria-label={`Move expression ${index + 1} down`}
                    onClick={onMoveDown}
                    className="p-1 rounded hover:bg-neutral-100 text-neutral-500 hover:text-neutral-800"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  type="button"
                  aria-label={`Duplicate expression ${index + 1}`}
                  onClick={onDuplicate}
                  className="p-1 rounded hover:bg-neutral-100 text-neutral-500 hover:text-neutral-800"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  aria-label={`Delete expression ${index + 1}`}
                  onClick={onDelete}
                  className="p-1 rounded hover:bg-red-50 text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  aria-label={`Style options for expression ${index + 1}`}
                  title="Color, line style, and label"
                  onClick={() => setStyleOpen((o) => !o)}
                  className={`p-1 rounded hover:bg-neutral-100 text-neutral-500 hover:text-neutral-800 transition-opacity ${
                    styleOpen || isFocused ? 'opacity-100' : 'opacity-45 group-hover:opacity-100'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  aria-label={`Delete expression ${index + 1}`}
                  title="Remove expression"
                  onClick={onDelete}
                  className={`p-1 rounded hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700 transition-opacity ${
                    isFocused ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                  }`}
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Evaluation Result */}
        {item.evalResult && !showSliderUI && (
          <div className="flex justify-end mt-0.5">
            <span className="text-xs font-semibold font-math-mono tabular-nums text-neutral-600 bg-neutral-100 px-2 py-0.5 rounded">
              = {item.evalResult}
            </span>
          </div>
        )}

        {/* Error or Mode Compatibility Notice */}
        {item.error && (
          <div className="mt-1 text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded px-2 py-1 flex items-center gap-1.5">
            <AlertTriangle className="w-3 h-3 shrink-0" />
            <span>{item.error}</span>
          </div>
        )}
        {!item.error && item.modeNotice && (
          <div className="mt-1 text-[11px] text-blue-800 bg-blue-50 border border-blue-200 rounded px-2 py-1 flex items-center gap-1.5">
            <Info className="w-3 h-3 shrink-0" />
            <span>{item.modeNotice}</span>
          </div>
        )}

        {/* Desmos Auto-Slider Prompt for Undefined Parameters */}
        {item.undefinedVars && item.undefinedVars.length > 0 && (
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-xs text-neutral-600">
            <span className="text-[11px] font-medium">add slider:</span>
            {item.undefinedVars.map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => onAddSliderVars([v])}
                className="px-2 py-0.5 rounded bg-blue-600 hover:bg-blue-700 text-white font-semibold text-[11px] inline-flex items-center gap-0.5 transition-colors"
              >
                <Plus className="w-3 h-3" />
                <span>{v}</span>
              </button>
            ))}
            {item.undefinedVars.length > 1 && (
              <button
                type="button"
                onClick={() => onAddSliderVars(item.undefinedVars!)}
                className="px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-900 text-white font-semibold text-[11px] transition-colors"
              >
                all
              </button>
            )}
          </div>
        )}

        {/* Interactive Slider UI */}
        {showSliderUI && (
          <div className="mt-2 pt-1.5 border-t border-neutral-100 space-y-1.5">
            <div className="flex items-center gap-2">
              <button
                type="button"
                aria-label={sliderCfg.playing ? `Pause slider ${sliderVarName}` : `Play slider ${sliderVarName}`}
                onClick={() => updateSliderConfig({ playing: !sliderCfg.playing })}
                className="w-7 h-7 rounded-full border border-neutral-200 bg-white hover:bg-neutral-100 text-neutral-700 inline-flex items-center justify-center shrink-0 transition-colors"
              >
                {sliderCfg.playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 ml-0.5" />}
              </button>

              <input
                type="range"
                aria-label={`Slider ${sliderVarName}`}
                min={sliderCfg.min}
                max={sliderCfg.max}
                step={sliderCfg.step > 0 ? sliderCfg.step : 0.01}
                value={Math.min(sliderCfg.max, Math.max(sliderCfg.min, sliderValue))}
                onChange={(e) => handleSliderValueChange(parseFloat(e.target.value), false)}
                style={{ '--slider-color': item.color } as React.CSSProperties}
                className="desmos-slider flex-1 min-w-0"
              />

              <button
                type="button"
                aria-label={`Cycle animation speed (${sliderCfg.speed}x)`}
                onClick={cycleSpeed}
                title="Animation speed"
                className="px-1.5 py-0.5 rounded text-[11px] font-semibold tabular-nums text-neutral-600 hover:bg-neutral-100 border border-neutral-200 shrink-0"
              >
                {sliderCfg.speed}x
              </button>

              <button
                type="button"
                aria-label={`Animation loop mode: ${sliderCfg.loopMode}`}
                onClick={cycleLoopMode}
                title={`Mode: ${sliderCfg.loopMode}`}
                className="p-1 rounded text-neutral-600 hover:bg-neutral-100 border border-neutral-200 shrink-0"
              >
                {sliderCfg.loopMode === 'oscillate' && <ArrowLeftRight className="w-3 h-3" />}
                {sliderCfg.loopMode === 'loop' && <Repeat className="w-3 h-3" />}
                {sliderCfg.loopMode === 'once' && <ArrowRight className="w-3 h-3" />}
              </button>
            </div>

            {editingBounds ? (
              <div className="flex items-center gap-1.5 text-[11px] text-neutral-600 tabular-nums">
                <label className="flex items-center gap-1">
                  <span>Min</span>
                  <input
                    type="number"
                    value={sliderCfg.min}
                    onChange={(e) => {
                      const v = parseFloat(e.target.value);
                      if (!Number.isNaN(v)) updateSliderConfig({ min: v });
                    }}
                    className="w-14 px-1 py-0.5 border border-neutral-300 rounded text-center"
                  />
                </label>
                <label className="flex items-center gap-1">
                  <span>Max</span>
                  <input
                    type="number"
                    value={sliderCfg.max}
                    onChange={(e) => {
                      const v = parseFloat(e.target.value);
                      if (!Number.isNaN(v)) updateSliderConfig({ max: v });
                    }}
                    className="w-14 px-1 py-0.5 border border-neutral-300 rounded text-center"
                  />
                </label>
                <label className="flex items-center gap-1">
                  <span>Step</span>
                  <input
                    type="number"
                    step="any"
                    value={sliderCfg.step}
                    onChange={(e) => {
                      const v = parseFloat(e.target.value);
                      if (!Number.isNaN(v) && v >= 0) updateSliderConfig({ step: v });
                    }}
                    className="w-14 px-1 py-0.5 border border-neutral-300 rounded text-center"
                  />
                </label>
                <button
                  type="button"
                  onClick={() => setEditingBounds(false)}
                  className="ml-auto px-2 py-0.5 rounded bg-neutral-200 hover:bg-neutral-300 text-neutral-800 font-medium"
                >
                  OK
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between text-[11px] text-neutral-500 tabular-nums">
                <button
                  type="button"
                  onClick={() => setEditingBounds(true)}
                  className="hover:text-blue-600 hover:underline"
                >
                  {sliderCfg.min} ≤ {sliderVarName} ≤ {sliderCfg.max} (step {sliderCfg.step})
                </button>
                <span className="font-math-mono font-medium text-neutral-700">{sliderValue}</span>
              </div>
            )}
          </div>
        )}

        {/* Style Popover */}
        {styleOpen && (
          <ExpressionStylePopover
            item={item}
            onChange={(patch) => onChange(patch)}
            onDuplicate={onDuplicate}
            onDelete={onDelete}
            onClose={() => setStyleOpen(false)}
          />
        )}
      </div>
    </div>
  );
};
