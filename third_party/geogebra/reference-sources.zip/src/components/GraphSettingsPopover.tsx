import React from 'react';
import { X, RotateCcw } from 'lucide-react';
import { DEFAULT_SETTINGS, GraphSettings, ViewMode } from '../types/calculator';

interface GraphSettingsPopoverProps {
  settings: GraphSettings;
  viewMode: ViewMode;
  onChange: (next: GraphSettings, applyBounds?: boolean) => void;
  onClose: () => void;
}

export const GraphSettingsPopover: React.FC<GraphSettingsPopoverProps> = ({
  settings,
  viewMode,
  onChange,
  onClose,
}) => {
  const update = (patch: Partial<GraphSettings>, applyBounds = false) => {
    onChange({ ...settings, ...patch }, applyBounds);
  };

  const updateBounds2D = (key: keyof GraphSettings['bounds2D'], raw: string) => {
    const val = parseFloat(raw);
    if (Number.isNaN(val)) return;
    onChange(
      {
        ...settings,
        bounds2D: {
          ...settings.bounds2D,
          [key]: val,
        },
      },
      true
    );
  };

  const updateBounds3D = (key: keyof GraphSettings['bounds3D'], raw: string) => {
    const val = parseFloat(raw);
    if (Number.isNaN(val)) return;
    onChange(
      {
        ...settings,
        bounds3D: {
          ...settings.bounds3D,
          [key]: val,
        },
      },
      true
    );
  };

  return (
    <div
      role="dialog"
      aria-label="Graph settings"
      className="w-80 max-h-[82vh] overflow-y-auto bg-white border border-neutral-200 rounded-lg shadow-xl text-xs text-neutral-800 p-4 space-y-4 z-30"
    >
      <div className="flex items-center justify-between border-b border-neutral-100 pb-2.5">
        <h2 className="text-sm font-semibold text-neutral-900">Graph Settings</h2>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onChange(DEFAULT_SETTINGS, true)}
            title="Reset settings to defaults"
            className="p-1 rounded hover:bg-neutral-100 text-neutral-500 hover:text-neutral-800"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            aria-label="Close graph settings"
            onClick={onClose}
            className="p-1 rounded hover:bg-neutral-100 text-neutral-500 hover:text-neutral-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid & Display */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <label className="inline-flex items-center gap-2 cursor-pointer font-medium">
            <input
              type="checkbox"
              checked={settings.showGrid}
              onChange={(e) => update({ showGrid: e.target.checked })}
              className="rounded border-neutral-300 text-blue-600"
            />
            <span>Grid</span>
          </label>

          {viewMode === '2d' && (
            <div className="inline-flex rounded border border-neutral-200 overflow-hidden">
              <button
                type="button"
                onClick={() => update({ polarGrid: false })}
                className={`px-2 py-1 text-[11px] font-medium ${
                  !settings.polarGrid ? 'bg-blue-600 text-white' : 'bg-white text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                Cartesian
              </button>
              <button
                type="button"
                onClick={() => update({ polarGrid: true })}
                className={`px-2 py-1 text-[11px] font-medium ${
                  settings.polarGrid ? 'bg-blue-600 text-white' : 'bg-white text-neutral-600 hover:bg-neutral-50'
                }`}
              >
                Polar
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 pl-1">
          {viewMode === '2d' && (
            <label className="inline-flex items-center gap-2 cursor-pointer text-neutral-700">
              <input
                type="checkbox"
                checked={settings.showMinorGrid}
                onChange={(e) => update({ showMinorGrid: e.target.checked })}
                className="rounded border-neutral-300 text-blue-600"
              />
              <span>Minor Gridlines</span>
            </label>
          )}
          <label className="inline-flex items-center gap-2 cursor-pointer text-neutral-700">
            <input
              type="checkbox"
              checked={settings.reverseContrast}
              onChange={(e) => update({ reverseContrast: e.target.checked })}
              className="rounded border-neutral-300 text-blue-600"
            />
            <span>Reverse Contrast</span>
          </label>
        </div>
      </div>

      {/* Axes & Labels */}
      <div className="space-y-2.5 pt-2 border-t border-neutral-100">
        <div className="font-semibold text-neutral-700">Axes &amp; Bounds</div>

        {/* X Axis */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <label className="inline-flex items-center gap-1.5 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={settings.showXAxis}
                onChange={(e) => update({ showXAxis: e.target.checked })}
                className="rounded border-neutral-300 text-blue-600"
              />
              <span>X-Axis</span>
            </label>
            <input
              type="text"
              placeholder="Label"
              value={settings.xAxisLabel}
              onChange={(e) => update({ xAxisLabel: e.target.value })}
              className="w-28 px-2 py-1 border border-neutral-200 rounded text-xs outline-none focus:border-blue-500"
            />
          </div>
          {viewMode === '2d' ? (
            <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
              <input
                type="number"
                aria-label="X min"
                value={Number(settings.bounds2D.xmin.toFixed(2))}
                onChange={(e) => updateBounds2D('xmin', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
              <span className="text-neutral-500">≤ x ≤</span>
              <input
                type="number"
                aria-label="X max"
                value={Number(settings.bounds2D.xmax.toFixed(2))}
                onChange={(e) => updateBounds2D('xmax', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
              <input
                type="number"
                aria-label="3D X min"
                value={settings.bounds3D.xmin}
                onChange={(e) => updateBounds3D('xmin', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
              <span className="text-neutral-500">≤ x ≤</span>
              <input
                type="number"
                aria-label="3D X max"
                value={settings.bounds3D.xmax}
                onChange={(e) => updateBounds3D('xmax', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
            </div>
          )}
        </div>

        {/* Y Axis */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <label className="inline-flex items-center gap-1.5 cursor-pointer font-medium">
              <input
                type="checkbox"
                checked={settings.showYAxis}
                onChange={(e) => update({ showYAxis: e.target.checked })}
                className="rounded border-neutral-300 text-blue-600"
              />
              <span>Y-Axis</span>
            </label>
            <input
              type="text"
              placeholder="Label"
              value={settings.yAxisLabel}
              onChange={(e) => update({ yAxisLabel: e.target.value })}
              className="w-28 px-2 py-1 border border-neutral-200 rounded text-xs outline-none focus:border-blue-500"
            />
          </div>
          {viewMode === '2d' ? (
            <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
              <input
                type="number"
                aria-label="Y min"
                value={Number(settings.bounds2D.ymin.toFixed(2))}
                onChange={(e) => updateBounds2D('ymin', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
              <span className="text-neutral-500">≤ y ≤</span>
              <input
                type="number"
                aria-label="Y max"
                value={Number(settings.bounds2D.ymax.toFixed(2))}
                onChange={(e) => updateBounds2D('ymax', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
              <input
                type="number"
                aria-label="3D Y min"
                value={settings.bounds3D.ymin}
                onChange={(e) => updateBounds3D('ymin', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
              <span className="text-neutral-500">≤ y ≤</span>
              <input
                type="number"
                aria-label="3D Y max"
                value={settings.bounds3D.ymax}
                onChange={(e) => updateBounds3D('ymax', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
            </div>
          )}
        </div>

        {/* Z Axis (3D mode) */}
        {viewMode === '3d' && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <label className="inline-flex items-center gap-1.5 cursor-pointer font-medium">
                <input
                  type="checkbox"
                  checked={settings.showZAxis}
                  onChange={(e) => update({ showZAxis: e.target.checked })}
                  className="rounded border-neutral-300 text-blue-600"
                />
                <span>Z-Axis</span>
              </label>
              <input
                type="text"
                placeholder="Label"
                value={settings.zAxisLabel}
                onChange={(e) => update({ zAxisLabel: e.target.value })}
                className="w-28 px-2 py-1 border border-neutral-200 rounded text-xs outline-none focus:border-blue-500"
              />
            </div>
            <div className="flex items-center gap-1.5 text-[11px] tabular-nums">
              <input
                type="number"
                aria-label="3D Z min"
                value={settings.bounds3D.zmin}
                onChange={(e) => updateBounds3D('zmin', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
              <span className="text-neutral-500">≤ z ≤</span>
              <input
                type="number"
                aria-label="3D Z max"
                value={settings.bounds3D.zmax}
                onChange={(e) => updateBounds3D('zmax', e.target.value)}
                className="w-20 px-1.5 py-1 border border-neutral-200 rounded text-center"
              />
            </div>
          </div>
        )}
      </div>

      {/* Angle Unit */}
      <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
        <span className="font-semibold text-neutral-700">Angle Unit</span>
        <div className="inline-flex rounded border border-neutral-200 overflow-hidden">
          <button
            type="button"
            onClick={() => update({ angleMode: 'rad' })}
            className={`px-3 py-1 text-[11px] font-medium ${
              settings.angleMode === 'rad' ? 'bg-blue-600 text-white' : 'bg-white text-neutral-700 hover:bg-neutral-50'
            }`}
          >
            Radians
          </button>
          <button
            type="button"
            onClick={() => update({ angleMode: 'deg' })}
            className={`px-3 py-1 text-[11px] font-medium ${
              settings.angleMode === 'deg' ? 'bg-blue-600 text-white' : 'bg-white text-neutral-700 hover:bg-neutral-50'
            }`}
          >
            Degrees
          </button>
        </div>
      </div>
    </div>
  );
};
