import React, { useState } from 'react';
import { ChevronDown, Delete, CornerDownLeft, ArrowLeft, ArrowRight } from 'lucide-react';

interface MathKeypadProps {
  open: boolean;
  onInsert: (text: string, cursorOffset?: number) => void;
  onBackspace: () => void;
  onMoveCursor: (delta: number) => void;
  onEnter: () => void;
  onClose: () => void;
}

const FUNCTION_GROUPS = [
  {
    title: 'Trig',
    items: [
      { label: 'sin', insert: 'sin()' , offset: -1 },
      { label: 'cos', insert: 'cos()', offset: -1 },
      { label: 'tan', insert: 'tan()', offset: -1 },
      { label: 'csc', insert: 'csc()', offset: -1 },
      { label: 'sec', insert: 'sec()', offset: -1 },
      { label: 'cot', insert: 'cot()', offset: -1 },
      { label: 'arcsin', insert: 'arcsin()', offset: -1 },
      { label: 'arccos', insert: 'arccos()', offset: -1 },
      { label: 'arctan', insert: 'arctan()', offset: -1 },
    ],
  },
  {
    title: 'Calculus & Sums',
    items: [
      { label: 'd/dx', insert: 'd/dx()', offset: -1 },
      { label: '∫', insert: 'integral(x^2, x, 0, 1)', offset: 0 },
      { label: 'Σ', insert: 'sum(n=1, 5, x^n)', offset: 0 },
      { label: 'Π', insert: 'prod(k=1, 5, x-k)', offset: 0 },
      { label: 'ln', insert: 'ln()', offset: -1 },
      { label: 'log', insert: 'log()', offset: -1 },
      { label: 'eˣ', insert: 'exp()', offset: -1 },
      { label: 'abs', insert: 'abs()', offset: -1 },
    ],
  },
  {
    title: 'Stats & Rounding',
    items: [
      { label: 'mean', insert: 'mean()', offset: -1 },
      { label: 'median', insert: 'median()', offset: -1 },
      { label: 'stdev', insert: 'stdev()', offset: -1 },
      { label: 'min', insert: 'min()', offset: -1 },
      { label: 'max', insert: 'max()', offset: -1 },
      { label: 'floor', insert: 'floor()', offset: -1 },
      { label: 'ceil', insert: 'ceil()', offset: -1 },
      { label: 'round', insert: 'round()', offset: -1 },
    ],
  },
];

export const MathKeypad: React.FC<MathKeypadProps> = ({
  open,
  onInsert,
  onBackspace,
  onMoveCursor,
  onEnter,
  onClose,
}) => {
  const [functionsOpen, setFunctionsOpen] = useState(false);

  if (!open) return null;

  const preventFocusLoss = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  return (
    <div
      data-testid="math-keypad"
      onMouseDown={preventFocusLoss}
      className="fixed bottom-0 left-0 right-0 md:left-auto md:right-4 md:bottom-3 md:w-[640px] bg-[#ececec] border border-neutral-300 md:rounded-xl shadow-2xl z-40 select-none"
    >
      {/* Top Keypad Header */}
      <div className="h-8 px-3 border-b border-neutral-300 flex items-center justify-between text-xs text-neutral-600">
        <span className="font-semibold">Mathematical Keypad</span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setFunctionsOpen((v) => !v)}
            className={`px-2.5 py-0.5 rounded text-xs font-semibold border transition-colors ${
              functionsOpen
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-50'
            }`}
          >
            functions
          </button>
          <button
            type="button"
            aria-label="Close keypad"
            onClick={onClose}
            className="p-1 rounded hover:bg-neutral-200 text-neutral-600"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Functions Drawer */}
      {functionsOpen && (
        <div className="p-2.5 bg-white border-b border-neutral-300 grid grid-cols-1 sm:grid-cols-3 gap-2.5 max-h-52 overflow-y-auto">
          {FUNCTION_GROUPS.map((grp) => (
            <div key={grp.title}>
              <div className="text-[11px] font-semibold text-neutral-500 mb-1.5">{grp.title}</div>
              <div className="grid grid-cols-3 gap-1">
                {grp.items.map((fn) => (
                  <button
                    key={fn.label}
                    type="button"
                    onClick={() => {
                      onInsert(fn.insert, fn.offset);
                      setFunctionsOpen(false);
                    }}
                    className="h-7 px-1.5 rounded bg-neutral-100 hover:bg-blue-50 hover:text-blue-700 text-xs font-medium text-neutral-800 transition-colors"
                  >
                    {fn.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Main Key Grid */}
      <div className="p-2 grid grid-cols-12 gap-1.5 text-sm font-medium">
        {/* Left Symbol Cluster (5 cols) */}
        <div className="col-span-5 grid grid-cols-4 gap-1">
          {[
            { label: 'x', val: 'x' },
            { label: 'y', val: 'y' },
            { label: 'z', val: 'z' },
            { label: 'θ', val: 'theta' },
            { label: 'a²', val: '^2' },
            { label: 'aᵇ', val: '^' },
            { label: '|a|', val: 'abs()', offset: -1 },
            { label: '√', val: 'sqrt()', offset: -1 },
            { label: '<', val: '<' },
            { label: '>', val: '>' },
            { label: '≤', val: '<=' },
            { label: '≥', val: '>=' },
            { label: '(', val: '(' },
            { label: ')', val: ')' },
            { label: 'π', val: 'pi' },
            { label: ',', val: ',' },
          ].map((k) => (
            <button
              key={k.label}
              type="button"
              onClick={() => onInsert(k.val, k.offset)}
              className="h-9 rounded bg-white hover:bg-neutral-50 active:bg-neutral-200 border border-neutral-300/80 shadow-2xs text-neutral-800 font-math-mono text-xs flex items-center justify-center"
            >
              {k.label}
            </button>
          ))}
        </div>

        {/* Center Numeric Pad (4 cols) */}
        <div className="col-span-4 grid grid-cols-3 gap-1">
          {['7', '8', '9', '4', '5', '6', '1', '2', '3', '0', '.', '='].map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => onInsert(k)}
              className="h-9 rounded bg-[#fafafa] hover:bg-white active:bg-neutral-200 border border-neutral-300/80 shadow-2xs text-neutral-900 font-semibold text-sm flex items-center justify-center"
            >
              {k}
            </button>
          ))}
        </div>

        {/* Right Ops & Navigation (3 cols) */}
        <div className="col-span-3 grid grid-cols-2 gap-1">
          <button
            type="button"
            onClick={() => onInsert('/')}
            className="h-9 rounded bg-white hover:bg-neutral-50 border border-neutral-300/80 text-neutral-800 flex items-center justify-center"
          >
            ÷
          </button>
          <button
            type="button"
            onClick={() => onInsert('*')}
            className="h-9 rounded bg-white hover:bg-neutral-50 border border-neutral-300/80 text-neutral-800 flex items-center justify-center"
          >
            ×
          </button>
          <button
            type="button"
            onClick={() => onInsert('-')}
            className="h-9 rounded bg-white hover:bg-neutral-50 border border-neutral-300/80 text-neutral-800 flex items-center justify-center"
          >
            −
          </button>
          <button
            type="button"
            onClick={() => onInsert('+')}
            className="h-9 rounded bg-white hover:bg-neutral-50 border border-neutral-300/80 text-neutral-800 flex items-center justify-center"
          >
            +
          </button>
          <button
            type="button"
            aria-label="Cursor left"
            onClick={() => onMoveCursor(-1)}
            className="h-9 rounded bg-neutral-200/80 hover:bg-neutral-200 border border-neutral-300/80 text-neutral-700 flex items-center justify-center"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <button
            type="button"
            aria-label="Cursor right"
            onClick={() => onMoveCursor(1)}
            className="h-9 rounded bg-neutral-200/80 hover:bg-neutral-200 border border-neutral-300/80 text-neutral-700 flex items-center justify-center"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            aria-label="Backspace"
            onClick={onBackspace}
            className="h-9 rounded bg-neutral-200/80 hover:bg-neutral-200 border border-neutral-300/80 text-neutral-700 flex items-center justify-center"
          >
            <Delete className="w-4 h-4" />
          </button>
          <button
            type="button"
            aria-label="Enter new expression"
            onClick={onEnter}
            className="h-9 rounded bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center"
          >
            <CornerDownLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
