import React from 'react';
import { FilePlus2, Trash2, X, FolderOpen } from 'lucide-react';
import { SavedGraph } from '../types/calculator';

interface SavedGraphsDrawerProps {
  open: boolean;
  savedGraphs: SavedGraph[];
  activeGraphId: string | null;
  onNewGraph: () => void;
  onLoadGraph: (graph: SavedGraph) => void;
  onDeleteGraph: (id: string) => void;
  onClose: () => void;
}

export const SavedGraphsDrawer: React.FC<SavedGraphsDrawerProps> = ({
  open,
  savedGraphs,
  activeGraphId,
  onNewGraph,
  onLoadGraph,
  onDeleteGraph,
  onClose,
}) => {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div
        className="fixed inset-0 bg-black/35"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-label="Saved graphs"
        className="relative w-80 max-w-[90vw] h-full bg-white shadow-2xl border-r border-neutral-200 flex flex-col z-10"
      >
        <div className="h-12 px-4 border-b border-neutral-200 flex items-center justify-between">
          <h2 className="text-sm font-bold text-neutral-900">Saved Graphs</h2>
          <button
            type="button"
            aria-label="Close saved graphs drawer"
            onClick={onClose}
            className="p-1.5 rounded hover:bg-neutral-100 text-neutral-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-3 border-b border-neutral-100">
          <button
            type="button"
            onClick={() => {
              onNewGraph();
              onClose();
            }}
            className="w-full h-9 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors"
          >
            <FilePlus2 className="w-4 h-4" />
            <span>New Blank Graph</span>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {savedGraphs.length === 0 ? (
            <div className="py-10 px-4 text-center text-xs text-neutral-500 space-y-2">
              <FolderOpen className="w-8 h-8 text-neutral-300 mx-auto" />
              <p>No saved graphs yet.</p>
              <p className="text-[11px] text-neutral-400">
                Click &ldquo;Save&rdquo; in the top bar to store graphs locally.
              </p>
            </div>
          ) : (
            savedGraphs.map((g) => {
              const isActive = g.id === activeGraphId;
              return (
                <div
                  key={g.id}
                  className={`group rounded-lg border p-2.5 flex items-center justify-between gap-2 transition-colors ${
                    isActive
                      ? 'border-blue-500 bg-blue-50/40'
                      : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      onLoadGraph(g);
                      onClose();
                    }}
                    className="flex-1 min-w-0 text-left"
                  >
                    <div className="text-xs font-semibold text-neutral-900 truncate">
                      {g.title}
                    </div>
                    <div className="text-[11px] text-neutral-500 mt-0.5 tabular-nums">
                      {g.viewMode.toUpperCase()} · {g.expressions.length} items ·{' '}
                      {new Date(g.updatedAt).toLocaleDateString()}
                    </div>
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete saved graph ${g.title}`}
                    onClick={() => onDeleteGraph(g.id)}
                    className="p-1.5 rounded text-neutral-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
