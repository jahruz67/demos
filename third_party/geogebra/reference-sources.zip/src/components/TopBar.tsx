import React, { useState, useRef, useEffect } from 'react';
import {
  Menu,
  Save,
  Check,
  Undo2,
  Redo2,
  Share2,
  HelpCircle,
  BookOpen,
  Box,
  Grid2x2,
} from 'lucide-react';
import { ViewMode } from '../types/calculator';

interface TopBarProps {
  title: string;
  onTitleChange: (title: string) => void;
  hasUnsavedChanges: boolean;
  onSave: () => void;
  onOpenSavedDrawer: () => void;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onOpenExamples: () => void;
  onOpenShare: () => void;
  onOpenHelp: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  title,
  onTitleChange,
  hasUnsavedChanges,
  onSave,
  onOpenSavedDrawer,
  viewMode,
  onViewModeChange,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onOpenExamples,
  onOpenShare,
  onOpenHelp,
}) => {
  const [editingTitle, setEditingTitle] = useState(false);
  const [draftTitle, setDraftTitle] = useState(title);
  const [justSaved, setJustSaved] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setDraftTitle(title);
  }, [title]);

  useEffect(() => {
    if (editingTitle) {
      inputRef.current?.focus();
      inputRef.current?.select();
    }
  }, [editingTitle]);

  const commitTitle = () => {
    setEditingTitle(false);
    const cleaned = draftTitle.trim() || 'Untitled Graph';
    setDraftTitle(cleaned);
    if (cleaned !== title) {
      onTitleChange(cleaned);
    }
  };

  const handleSaveClick = () => {
    onSave();
    setJustSaved(true);
    window.setTimeout(() => setJustSaved(false), 1600);
  };

  return (
    <header
      data-testid="app-topbar"
      className="h-12 w-full bg-[#242424] text-white border-b border-[#141414] px-2 sm:px-3 flex items-center justify-between gap-2 sm:gap-4 shrink-0 select-none z-30"
    >
      {/* Left Zone: Saved Graphs menu + Editable Graph Title + Save */}
      <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0 shrink">
        <button
          type="button"
          onClick={onOpenSavedDrawer}
          aria-label="Open saved graphs menu"
          title="Saved Graphs"
          className="h-8 w-8 inline-flex items-center justify-center rounded hover:bg-white/10 text-neutral-200 transition-colors shrink-0 focus-visible:outline-2 focus-visible:outline-blue-400"
        >
          <Menu className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          {editingTitle ? (
            <input
              ref={inputRef}
              type="text"
              value={draftTitle}
              onChange={(e) => setDraftTitle(e.target.value)}
              onBlur={commitTitle}
              onKeyDown={(e) => {
                if (e.key === 'Enter') commitTitle();
                if (e.key === 'Escape') {
                  setDraftTitle(title);
                  setEditingTitle(false);
                }
              }}
              aria-label="Graph title"
              className="bg-[#333333] text-white text-sm font-medium px-2 py-1 rounded border border-blue-400 outline-none w-32 sm:w-56"
            />
          ) : (
            <button
              type="button"
              onClick={() => setEditingTitle(true)}
              title="Click to rename graph"
              className="hidden sm:inline-block text-sm font-semibold text-white hover:text-blue-200 truncate max-w-[200px] md:max-w-[240px] px-1.5 py-1 rounded hover:bg-white/10 transition-colors text-left"
            >
              {title}
            </button>
          )}

          <button
            type="button"
            onClick={handleSaveClick}
            aria-label="Save graph"
            title="Save graph"
            className={`h-7 px-2 sm:px-3 rounded text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-blue-400 ${
              justSaved
                ? 'bg-emerald-700 text-white'
                : hasUnsavedChanges
                  ? 'bg-[#1a7f37] hover:bg-[#1f9340] text-white'
                  : 'bg-[#363636] hover:bg-[#444444] text-neutral-200'
            }`}
          >
            {justSaved ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Saved</span>
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Save</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Center Zone: 2D / 3D Viewport Mode Toggle */}
      <div
        role="group"
        aria-label="Graph viewport mode"
        className="flex items-center bg-[#181818] p-0.5 rounded-md border border-[#3a3a3a] shrink-0"
      >
        <button
          type="button"
          data-testid="mode-toggle-2d"
          aria-pressed={viewMode === '2d'}
          onClick={() => onViewModeChange('2d')}
          className={`h-7 px-2.5 sm:px-3 rounded text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-blue-400 ${
            viewMode === '2d'
              ? 'bg-[#2d70b3] text-white shadow-sm'
              : 'text-neutral-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Grid2x2 className="w-3.5 h-3.5" />
          <span>2D</span>
        </button>
        <button
          type="button"
          data-testid="mode-toggle-3d"
          aria-pressed={viewMode === '3d'}
          onClick={() => onViewModeChange('3d')}
          className={`h-7 px-2.5 sm:px-3 rounded text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-blue-400 ${
            viewMode === '3d'
              ? 'bg-[#2d70b3] text-white shadow-sm'
              : 'text-neutral-300 hover:text-white hover:bg-white/5'
          }`}
        >
          <Box className="w-3.5 h-3.5" />
          <span>3D</span>
        </button>
      </div>

      {/* Right Zone: Undo/Redo, Examples, Share, Help */}
      <div className="flex items-center gap-0.5 sm:gap-1.5 shrink-0">
        <div className="hidden md:flex items-center gap-0.5 mr-1">
          <button
            type="button"
            onClick={onUndo}
            disabled={!canUndo}
            aria-label="Undo"
            title="Undo (Ctrl+Z)"
            className="h-8 w-8 inline-flex items-center justify-center rounded hover:bg-white/10 disabled:opacity-35 disabled:pointer-events-none text-neutral-200 transition-colors"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onRedo}
            disabled={!canRedo}
            aria-label="Redo"
            title="Redo (Ctrl+Shift+Z)"
            className="h-8 w-8 inline-flex items-center justify-center rounded hover:bg-white/10 disabled:opacity-35 disabled:pointer-events-none text-neutral-200 transition-colors"
          >
            <Redo2 className="w-4 h-4" />
          </button>
        </div>

        <button
          type="button"
          onClick={onOpenExamples}
          aria-label="Open example graphs"
          title="Example Graphs"
          className="h-8 px-2.5 rounded hover:bg-white/10 text-neutral-200 text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Examples</span>
        </button>

        <button
          type="button"
          onClick={onOpenShare}
          aria-label="Share or export graph"
          title="Share & Export"
          className="h-8 px-2.5 rounded hover:bg-white/10 text-neutral-200 text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Share</span>
        </button>

        <button
          type="button"
          onClick={onOpenHelp}
          aria-label="Help and GeoGebra engine info"
          title="Syntax Guide & Attribution"
          className="h-8 w-8 inline-flex items-center justify-center rounded hover:bg-white/10 text-neutral-200 transition-colors shrink-0"
        >
          <HelpCircle className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
