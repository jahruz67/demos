import React, { useState } from 'react';
import {
  ChevronsLeft,
  Folder,
  Keyboard,
  Plus,
  Quote,
  Settings2,
  Sigma,
  Table2,
  Undo2,
  Redo2,
} from 'lucide-react';
import { ExpressionItem, ExpressionKind } from '../types/calculator';
import { ExpressionRow } from './ExpressionRow';

interface ExpressionPanelProps {
  expressions: ExpressionItem[];
  focusedId: string | null;
  width: number;
  collapsed: boolean;
  keypadOpen: boolean;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onCollapse: () => void;
  onToggleKeypad: () => void;
  onFocusExpression: (id: string) => void;
  onRegisterInputRef: (id: string, el: HTMLInputElement | null) => void;
  onAddItem: (kind: ExpressionKind, afterId?: string | null) => void;
  onUpdateExpression: (id: string, patch: Partial<ExpressionItem>, recordHistory?: boolean) => void;
  onDeleteExpression: (id: string) => void;
  onDuplicateExpression: (id: string) => void;
  onReorderExpression: (fromIndex: number, toIndex: number) => void;
  onAddSliderVars: (vars: string[], afterId: string) => void;
}

export const ExpressionPanel: React.FC<ExpressionPanelProps> = ({
  expressions,
  focusedId,
  width,
  collapsed,
  keypadOpen,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onCollapse,
  onToggleKeypad,
  onFocusExpression,
  onRegisterInputRef,
  onAddItem,
  onUpdateExpression,
  onDeleteExpression,
  onDuplicateExpression,
  onReorderExpression,
  onAddSliderVars,
}) => {
  const [addMenuOpen, setAddMenuOpen] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [dragIndex, setDragIndex] = useState<number | null>(null);

  if (collapsed) {
    return null;
  }

  // Track which items are hidden inside a collapsed folder
  const collapsedFolders = new Set<string>();
  for (const item of expressions) {
    if (item.type === 'folder' && item.collapsed) {
      collapsedFolders.add(item.id);
    }
  }

  return (
    <aside
      data-testid="expression-panel"
      style={{ width }}
      className="h-full max-w-full bg-white border-r border-neutral-300 flex flex-col shrink-0 relative z-20"
    >
      {/* Desmos Sub-Toolbar */}
      <div className="h-10 bg-[#ededed] border-b border-neutral-300 px-2 flex items-center justify-between shrink-0 select-none">
        <div className="flex items-center gap-1 relative">
          <button
            type="button"
            data-testid="add-item-button"
            aria-label="Add item"
            aria-expanded={addMenuOpen}
            onClick={() => setAddMenuOpen((o) => !o)}
            className="h-7 px-2 rounded hover:bg-neutral-200/80 text-neutral-700 inline-flex items-center gap-1 text-xs font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>

          {addMenuOpen && (
            <div
              role="menu"
              aria-label="Add expression item"
              className="absolute top-9 left-0 w-44 bg-white border border-neutral-200 rounded-lg shadow-xl py-1 z-30 text-xs text-neutral-800"
            >
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  onAddItem('expression', focusedId);
                  setAddMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 font-medium"
              >
                <Sigma className="w-4 h-4 text-blue-600" />
                <span>Expression</span>
              </button>
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  onAddItem('note', focusedId);
                  setAddMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 font-medium"
              >
                <Quote className="w-4 h-4 text-neutral-600" />
                <span>Note</span>
              </button>
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  onAddItem('table', focusedId);
                  setAddMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 font-medium"
              >
                <Table2 className="w-4 h-4 text-emerald-600" />
                <span>Table</span>
              </button>
              <button
                type="button"
                role="menuitem"
                onClick={() => {
                  onAddItem('folder', focusedId);
                  setAddMenuOpen(false);
                }}
                className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2.5 font-medium"
              >
                <Folder className="w-4 h-4 text-amber-600" />
                <span>Folder</span>
              </button>
            </div>
          )}

          <div className="h-4 w-px bg-neutral-300 mx-0.5 md:hidden" />

          <button
            type="button"
            onClick={onUndo}
            disabled={!canUndo}
            aria-label="Undo edit"
            className="md:hidden h-7 w-7 rounded hover:bg-neutral-200/80 disabled:opacity-35 text-neutral-700 inline-flex items-center justify-center"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onRedo}
            disabled={!canRedo}
            aria-label="Redo edit"
            className="md:hidden h-7 w-7 rounded hover:bg-neutral-200/80 disabled:opacity-35 text-neutral-700 inline-flex items-center justify-center"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label={editMode ? 'Done editing list' : 'Edit expression list'}
            aria-pressed={editMode}
            onClick={() => setEditMode((m) => !m)}
            title="Reorder, duplicate, or delete items"
            className={`h-7 px-2 rounded text-xs font-medium inline-flex items-center gap-1 transition-colors ${
              editMode
                ? 'bg-blue-600 text-white'
                : 'hover:bg-neutral-200/80 text-neutral-700'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5" />
            {editMode && <span>Done</span>}
          </button>

          <button
            type="button"
            aria-label="Hide expression list"
            title="Hide Expression List"
            onClick={onCollapse}
            className="h-7 w-7 rounded hover:bg-neutral-200/80 text-neutral-700 inline-flex items-center justify-center transition-colors"
          >
            <ChevronsLeft className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Scrollable Expression List */}
      <div className="flex-1 overflow-y-auto expr-scroll">
        {expressions.map((item, idx) => {
          if (item.folderId && collapsedFolders.has(item.folderId)) {
            return null;
          }
          return (
            <ExpressionRow
              key={item.id}
              item={item}
              index={idx}
              isFocused={focusedId === item.id}
              editMode={editMode}
              inFolder={Boolean(item.folderId)}
              inputRefCallback={(el) => onRegisterInputRef(item.id, el)}
              onFocus={() => onFocusExpression(item.id)}
              onChange={(patch, recordHistory = true) =>
                onUpdateExpression(item.id, patch, recordHistory)
              }
              onDelete={() => onDeleteExpression(item.id)}
              onDuplicate={() => onDuplicateExpression(item.id)}
              onEnterNew={() => onAddItem('expression', item.id)}
              onAddSliderVars={(vars) => onAddSliderVars(vars, item.id)}
              onMoveUp={idx > 0 ? () => onReorderExpression(idx, idx - 1) : undefined}
              onMoveDown={
                idx < expressions.length - 1 ? () => onReorderExpression(idx, idx + 1) : undefined
              }
              onDragStart={() => setDragIndex(idx)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (dragIndex !== null && dragIndex !== idx) {
                  onReorderExpression(dragIndex, idx);
                }
                setDragIndex(null);
              }}
            />
          );
        })}

        {/* Clickable empty area below list to append a new expression (classic Desmos behavior) */}
        <button
          type="button"
          data-testid="append-expression-area"
          aria-label="Add new expression"
          onClick={() => onAddItem('expression')}
          className="w-full min-h-[72px] flex items-start px-3 py-3 text-xs text-neutral-400 hover:text-neutral-600 hover:bg-neutral-50/70 transition-colors text-left"
        >
          <span className="inline-flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            <span>Add expression</span>
          </span>
        </button>
      </div>

      {/* Bottom Keypad Toggle Bar */}
      <div className="h-10 bg-[#f6f6f6] border-t border-neutral-200 px-2.5 flex items-center justify-between shrink-0">
        <button
          type="button"
          data-testid="keypad-toggle-button"
          aria-label={keypadOpen ? 'Hide math keypad' : 'Show math keypad'}
          aria-pressed={keypadOpen}
          onClick={onToggleKeypad}
          className={`h-7 px-2.5 rounded border text-xs font-medium inline-flex items-center gap-1.5 transition-colors ${
            keypadOpen
              ? 'bg-neutral-800 text-white border-neutral-800'
              : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
          }`}
        >
          <Keyboard className="w-3.5 h-3.5" />
          <span>Keypad</span>
        </button>

        <span className="text-[11px] text-neutral-500 tabular-nums">
          {expressions.length} {expressions.length === 1 ? 'item' : 'items'}
        </span>
      </div>
    </aside>
  );
};
