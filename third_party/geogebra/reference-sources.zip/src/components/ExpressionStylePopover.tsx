import React from 'react';
import { Check, Copy, Trash2 } from 'lucide-react';
import { DESMOS_COLORS, ExpressionItem, LineStyleType, PointStyleType } from '../types/calculator';

interface ExpressionStylePopoverProps {
  item: ExpressionItem;
  onChange: (patch: Partial<ExpressionItem>) => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onClose: () => void;
}

export const ExpressionStylePopover: React.FC<ExpressionStylePopoverProps> = ({
  item,
  onChange,
  onDuplicate,
  onDelete,
  onClose,
}) => {
  const lineStyles: { id: LineStyleType; label: string; preview: string }[] = [
    { id: 'solid', label: 'Solid', preview: 'border-t-2 border-solid' },
    { id: 'dashed', label: 'Dashed', preview: 'border-t-2 border-dashed' },
    { id: 'dotted', label: 'Dotted', preview: 'border-t-2 border-dotted' },
  ];

  const pointStyles: { id: PointStyleType; label: string }[] = [
    { id: 'point', label: 'Filled' },
    { id: 'open', label: 'Open' },
    { id: 'cross', label: 'Cross' },
  ];

  return (
    <div
      role="dialog"
      aria-label="Expression style options"
      className="mt-2 p-3 bg-white border border-neutral-200 rounded-lg shadow-lg text-xs text-neutral-800 space-y-3 z-20"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex items-center justify-between">
        <span className="font-semibold text-neutral-700">Appearance</span>
        <button
          type="button"
          onClick={onClose}
          className="text-neutral-500 hover:text-neutral-800 px-1.5 py-0.5 rounded hover:bg-neutral-100"
        >
          Done
        </button>
      </div>

      {/* Colors */}
      <div>
        <div className="text-[11px] text-neutral-500 mb-1.5 font-medium">Color</div>
        <div className="flex items-center gap-2">
          {DESMOS_COLORS.map((c) => {
            const active = item.color.toLowerCase() === c.hex.toLowerCase();
            return (
              <button
                key={c.hex}
                type="button"
                aria-label={`Color ${c.name}`}
                onClick={() => onChange({ color: c.hex })}
                style={{ backgroundColor: c.hex }}
                className={`w-6 h-6 rounded-full inline-flex items-center justify-center transition-transform ${
                  active ? 'ring-2 ring-offset-2 ring-neutral-800 scale-110' : 'hover:scale-105'
                }`}
              >
                {active && <Check className="w-3.5 h-3.5 text-white" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Line Style & Width */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <div className="text-[11px] text-neutral-500 mb-1 font-medium">Line Style</div>
          <div className="flex items-center gap-1">
            {lineStyles.map((ls) => (
              <button
                key={ls.id}
                type="button"
                aria-label={`Line style ${ls.label}`}
                onClick={() => onChange({ lineStyle: ls.id })}
                className={`flex-1 h-7 px-2 rounded border flex items-center justify-center ${
                  item.lineStyle === ls.id
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-neutral-200 hover:bg-neutral-50'
                }`}
              >
                <span className={`w-full ${ls.preview}`} style={{ borderColor: item.color }} />
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="text-[11px] text-neutral-500 mb-1 font-medium">Point Style</div>
          <div className="flex items-center gap-1">
            {pointStyles.map((ps) => (
              <button
                key={ps.id}
                type="button"
                onClick={() => onChange({ pointStyle: ps.id })}
                className={`flex-1 h-7 px-1.5 rounded border text-[11px] font-medium ${
                  item.pointStyle === ps.id
                    ? 'border-blue-600 bg-blue-50 text-blue-700'
                    : 'border-neutral-200 text-neutral-700 hover:bg-neutral-50'
                }`}
              >
                {ps.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Thickness & Opacity */}
      <div className="grid grid-cols-2 gap-3">
        <label className="block">
          <div className="flex justify-between text-[11px] text-neutral-500 mb-1">
            <span>Thickness</span>
            <span className="tabular-nums font-medium text-neutral-700">{item.lineWidth}</span>
          </div>
          <input
            type="range"
            min={1}
            max={6}
            step={0.5}
            value={item.lineWidth}
            onChange={(e) => onChange({ lineWidth: parseFloat(e.target.value) })}
            className="w-full accent-blue-600"
          />
        </label>

        <label className="block">
          <div className="flex justify-between text-[11px] text-neutral-500 mb-1">
            <span>Opacity</span>
            <span className="tabular-nums font-medium text-neutral-700">
              {Math.round(item.lineOpacity * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0.2}
            max={1}
            step={0.1}
            value={item.lineOpacity}
            onChange={(e) => onChange({ lineOpacity: parseFloat(e.target.value) })}
            className="w-full accent-blue-600"
          />
        </label>
      </div>

      {/* Label */}
      <div className="flex items-center gap-2 pt-1 border-t border-neutral-100">
        <label className="inline-flex items-center gap-1.5 cursor-pointer shrink-0">
          <input
            type="checkbox"
            checked={item.showLabel}
            onChange={(e) => onChange({ showLabel: e.target.checked })}
            className="rounded border-neutral-300 text-blue-600"
          />
          <span className="text-[11px] font-medium text-neutral-700">Label</span>
        </label>
        <input
          type="text"
          value={item.labelText}
          placeholder="Optional label"
          onChange={(e) => onChange({ labelText: e.target.value, showLabel: true })}
          className="flex-1 min-w-0 px-2 py-1 text-xs border border-neutral-200 rounded focus:border-blue-500 outline-none"
        />
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between pt-2 border-t border-neutral-100">
        <button
          type="button"
          onClick={() => {
            onDuplicate();
            onClose();
          }}
          className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-neutral-700 hover:bg-neutral-100 font-medium"
        >
          <Copy className="w-3.5 h-3.5" />
          <span>Duplicate</span>
        </button>
        <button
          type="button"
          onClick={() => {
            onDelete();
            onClose();
          }}
          className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-red-600 hover:bg-red-50 font-medium"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Delete</span>
        </button>
      </div>
    </div>
  );
};
