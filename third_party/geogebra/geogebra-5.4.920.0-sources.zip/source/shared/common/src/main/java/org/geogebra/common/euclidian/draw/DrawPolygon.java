/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.euclidian.draw;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;

import org.geogebra.common.awt.AwtFactory;
import org.geogebra.common.awt.GArea;
import org.geogebra.common.awt.GGraphics2D;
import org.geogebra.common.awt.GPoint2D;
import org.geogebra.common.awt.GRectangle;
import org.geogebra.common.awt.GShape;
import org.geogebra.common.euclidian.Drawable;
import org.geogebra.common.euclidian.EuclidianView;
import org.geogebra.common.euclidian.GeneralPathClipped;
import org.geogebra.common.euclidian.Previewable;
import org.geogebra.common.euclidian.event.PointerEventType;
import org.geogebra.common.kernel.Construction;
import org.geogebra.common.kernel.ConstructionDefaults;
import org.geogebra.common.kernel.MyPoint;
import org.geogebra.common.kernel.geos.GeoLine;
import org.geogebra.common.kernel.geos.GeoPoint;
import org.geogebra.common.kernel.geos.GeoPolygon;
import org.geogebra.common.kernel.geos.GeoVec3D;
import org.geogebra.common.kernel.kernelND.GeoPointND;
import org.geogebra.common.kernel.matrix.Coords;
import org.geogebra.common.util.DoubleUtil;
import org.geogebra.common.util.MyMath;

/**
 *
 * @author Markus Hohenwarter
 */
public class DrawPolygon extends Drawable implements Previewable {
	private static final double MIN_HITTING_SIZE = 20;
	private GeoPolygon poly;
	private boolean isVisible;
	private boolean labelVisible;

	private final @Nonnull GeneralPathClipped gp;
	private double[] coords = new double[2];
	private ArrayList<GeoPointND> points;

	private boolean fillShape = false;

	private GPoint2D endPoint = new GPoint2D();

	/**
	 * Creates new DrawPolygon
	 *
	 * @param view
	 *            Euclidian view to be used
	 * @param poly
	 *            Polygon to be drawn
	 */
	public DrawPolygon(EuclidianView view, GeoPolygon poly) {
		this.view = view;
		this.poly = poly;
		geo = poly;
		gp = new GeneralPathClipped(view);
		gp.resetWithThickness(geo.getLineThickness());
		update();
	}

	/**
	 * Creates a new DrawPolygon for preview.
	 *
	 * @param view
	 *            Euclidian view to be used
	 * @param points
	 *            vertices
	 */
	public DrawPolygon(EuclidianView view, ArrayList<GeoPointND> points) {
		this.view = view;
		this.points = points;
		geo = view.getKernel().getConstruction().getConstructionDefaults()
				.getDefaultGeo(ConstructionDefaults.DEFAULT_POLYGON);
		gp = new GeneralPathClipped(view);
		gp.resetWithThickness(geo.getLineThickness());
		updatePreview();
	}

	@Override
	final public void update() {
		isVisible = geo.isEuclidianVisible();
		if (isVisible) {
			labelVisible = geo.isLabelVisible();
			updateStrokes(poly);

			// build general path for this polygon
			isVisible = addPointsToPath(poly.getPointsLength());
			if (!isVisible) {
				return;
			}
			gp.closePath();
			fillShape = false;

			if (geo.isInverseFill()) {
				createInverseShape();
			}

			// polygon on screen?
			if (!view.intersects(gp.getGeneralPath()) && !geo.isInverseFill()) {
				isVisible = false;
				// don't return here to make sure that getBounds() works for
				// offscreen points too
			}
			drawAndUpdateTraceIfNeeded(poly.getTrace());
		}
	}

	@Override
	public void drawTrace(GGraphics2D g2) {
		fill(g2, gp.getGeneralPath());
	}

	private void createInverseShape() {
		setShape(view.getBoundsArea());
		getShape().subtract(AwtFactory.getPrototype().newArea(gp.getGeneralPath()));
		fillShape = true;
	}

	private Coords getCoords(int i) {
		if (poly != null) {
			return view.getCoordsForView(poly.getPoint3D(i));
		}

		return view.getCoordsForView(points.get(i).getInhomCoordsInD3());
	}

	// return false if a point doesn't lie on the plane
	private boolean addPointsToPath(int length) {
		gp.resetWithThickness(geo.getLineThickness());

		if (length <= 0) {
			return false;
		}

		// first point
		Coords v = getCoords(0);
		if (!DoubleUtil.isZero(v.getZ())) {
			return false;
		}
		coords[0] = v.getX();
		coords[1] = v.getY();
		view.toScreenCoords(coords);
		gp.moveTo(coords[0], coords[1]);

		// for centroid calculation (needed for label pos)
		double xsum = coords[0];
		double ysum = coords[1];

		for (int i = 1; i < length; i++) {
			v = getCoords(i);
			if (!DoubleUtil.isZero(v.getZ())) {
				return false;
			}
			coords[0] = v.getX();
			coords[1] = v.getY();
			view.toScreenCoords(coords);
			if (labelVisible) {
				xsum += coords[0];
				ysum += coords[1];
			}
			gp.lineTo(coords[0], coords[1]);
		}

		if (labelVisible) {
			labelDesc = geo.getLabelDescription();
			xLabel = (int) (xsum / length);
			yLabel = (int) (ysum / length);
			addLabelOffset();
		}

		return true;
	}

	@Override
	final public void draw(GGraphics2D g2) {
		if (isVisible) {
			// fill using default/hatching/image as appropriate
			fill(g2, fillShape ? getShape() : gp.getGeneralPath());
			if (isHighlighted()) {
				g2.setPaint(poly.getSelColor());
				g2.setStroke(selStroke);
				gp.draw(g2);
			}

			// polygons (e.g. in GeoLists) that don't have labeled segments
			// should also draw their border
			if (!poly.wasInitLabelsCalled()
					&& poly.getLineThickness() > 0) {
				g2.setPaint(getObjectColor());
				g2.setStroke(objStroke);
				gp.draw(g2);
			}

			if (labelVisible) {
				g2.setPaint(poly.getLabelColor());
				g2.setFont(view.getFontPoint());
				drawLabel(g2);
			}
		}
	}

	@Override
	final public void updatePreview() {
		int size = points.size();
		isVisible = size > 0;

		if (isVisible) {
			addPointsToPath(size);
		}
	}

	@Override
	final public void updateMousePos(double mouseRWx, double mouseRWy) {
		double xRW = mouseRWx;
		double yRW = mouseRWy;
		if (isVisible) {
			int mx;
			int my;

			// round angle to nearest 15 degrees if alt pressed
			if (view.getEuclidianController().isAltDown()) {

				GeoPointND p = points.get(points.size() - 1);
				double px = p.getInhomX();
				double py = p.getInhomY();

				if (points.size() > 1) {
					Construction cons = view.getKernel().getConstruction();
					GeoPoint intersection = new GeoPoint(cons);
					GeoLine l = new GeoLine(cons);
					GeoLine l2 = new GeoLine(cons);
					GeoPointND p2 = points.get(0);
					double px2 = p2.getInhomX();
					double py2 = p2.getInhomY();
					double nearestX = Double.MAX_VALUE;
					double nearestY = Double.MAX_VALUE;
					double dist = Double.MAX_VALUE;
					for (int angle = 0; angle < 180; angle += 15) {

						if (angle == 90) {
							l.setCoords(1, 0, -px);
						} else {
							double gradient = Math.tan(angle * Math.PI / 180.0);
							l.setCoords(gradient, -1.0, py - gradient * px);
						}

						for (int ang2 = 0; ang2 < 180; ang2 += 15) {
							if (ang2 == angle) {
								continue;
							} else if (DoubleUtil.isEqual(ang2, 90)) {
								l2.setCoords(1.0, 0, -px2);
							} else {
								double gradient2 = Math
										.tan(ang2 * Math.PI / 180.0);
								l2.setCoords(gradient2, -1.0,
										py2 - gradient2 * px2);
							}

							// calculate intersection
							GeoVec3D.cross(l, l2, intersection);

							double x1 = intersection.x / intersection.z;
							double y1 = intersection.y / intersection.z;

							double d = MyMath.length(x1 - xRW, y1 - yRW);
							if (d < dist) {
								nearestX = x1;
								nearestY = y1;
								dist = d;
							}
						}
					}

					xRW = nearestX;
					yRW = nearestY;
				} else {
					double angle = Math.atan2(yRW - py, xRW - px) * 180
							/ Math.PI;
					double radius = Math.sqrt(
							(py - yRW) * (py - yRW) + (px - xRW) * (px - xRW));

					// round angle to nearest 15 degrees
					angle = Math.round(angle / 15) * 15;

					xRW = px + radius * Math.cos(angle * Math.PI / 180);
					yRW = py + radius * Math.sin(angle * Math.PI / 180);
				}

				mx = view.toScreenCoordX(xRW);
				my = view.toScreenCoordY(yRW);

				endPoint.setLocation(xRW, yRW);
				view.getEuclidianController().setLineEndPoint(endPoint);
				gp.lineTo(mx, my);
			} else {
				view.getEuclidianController().setLineEndPoint(null);
			}
			gp.lineTo(view.toScreenCoordX(xRW), view.toScreenCoordY(yRW));
		}
	}

	@Override
	final public void drawPreview(GGraphics2D g2) {
		if (isVisible) {
			fill(g2, geo.isInverseFill() ? getShape() : gp.getGeneralPath());

			g2.setPaint(getObjectColor());
			updateStrokes(geo);
			g2.setStroke(objStroke);
			gp.draw(g2);
		}
	}

	@Override
	public void disposePreview() {
		// do nothing
	}

	@Override
	final public boolean hit(int x, int y, int hitThreshold) {
		GShape t = geo.isInverseFill() ? getShape() : gp.getGeneralPath();
		int eps = getFillingHitThreshold(hitThreshold, getBounds());
		boolean contains = t.contains(AwtFactory.getPrototype().newRectangle(x - eps,
				y - eps, 2 * eps, 2 * eps));

		if (geo.isFilled() && contains) {
			return true;
		}

		boolean intersects = t.intersects(x - eps,
				y - eps, 2 * eps, 2 * eps);

		return intersects && !contains;
	}

	private int getFillingHitThreshold(int hitThreshold, GRectangle bounds) {
		// polygon is big enough: don't use dynamic threshold
		if (geo.isFilled() && bounds != null && bounds.getWidth() > MIN_HITTING_SIZE) {
			return view.getApplication().getCapturingThreshold(PointerEventType.MOUSE);
		} else {
			return hitThreshold;
		}
	}

	@Override
	final public boolean isInside(GRectangle rect) {
		return gp.getBounds() != null && rect.contains(gp.getBounds());
	}

	/**
	 * Returns the bounding box of this Drawable in screen coordinates.
	 */
	@Override
	final public GRectangle getBounds() {
		if (!geo.isDefined() || !geo.isEuclidianVisible()) {
			return null;
		}
		return gp.getBounds();
	}

	@Override
	public GArea getShape() {
		if (super.getShape() != null) {
			return super.getShape();
		}
		if (geo.isInverseFill()) {
			createInverseShape();
		} else {
			setShape(AwtFactory.getPrototype().newArea(gp.getGeneralPath()));
		}
		return super.getShape();
	}

	@Override
	public void fromPoints(ArrayList<GPoint2D> pts) {
		for (int i = 0; i < pts.size(); i++) {
			poly.getPoint(i).setCoords(view.toRealWorldCoordX(pts.get(i).getX()),
					view.toRealWorldCoordY(pts.get(i).getY()), 1);
		}
	}

	@Override
	protected List<GPoint2D> toPoints() {
		List<GPoint2D> ret = new ArrayList<>(this.poly.getNumPoints());
		for (GeoPointND pt : this.poly.getPoints()) {
			pt.updateCoords2D();
			MyPoint screenPt = new MyPoint(view.toScreenCoordXd(pt.getX2D()),
					view.toScreenCoordYd(pt.getY2D()));
			ret.add(screenPt);
		}
		return ret;
	}
}
