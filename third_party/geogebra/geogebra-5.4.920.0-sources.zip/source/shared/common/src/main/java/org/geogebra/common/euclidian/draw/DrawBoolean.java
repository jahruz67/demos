/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.euclidian.draw;

import org.geogebra.common.awt.AwtFactory;
import org.geogebra.common.awt.GBasicStroke;
import org.geogebra.common.awt.GColor;
import org.geogebra.common.awt.GDimension;
import org.geogebra.common.awt.GGeneralPath;
import org.geogebra.common.awt.GGraphics2D;
import org.geogebra.common.awt.GRectangle;
import org.geogebra.common.awt.GRectangle2D;
import org.geogebra.common.awt.font.GTextLayout;
import org.geogebra.common.euclidian.Drawable;
import org.geogebra.common.euclidian.EuclidianConstants;
import org.geogebra.common.euclidian.EuclidianStatic;
import org.geogebra.common.euclidian.EuclidianView;
import org.geogebra.common.kernel.StringTemplate;
import org.geogebra.common.kernel.geos.GeoBoolean;
import org.geogebra.common.main.App;
import org.geogebra.common.main.GeoGebraColorConstants;
import org.geogebra.common.util.StringUtil;

/**
 * Checkbox for free GeoBoolean object.
 * 
 * @author Markus Hohenwarter
 */
public final class DrawBoolean extends Drawable {

	/**
	 * For some reason checkboxes were drawn 5 pixels from the label offset of
	 * the geo (both vertically and horizontally). Cannot be removed, as this
	 * would break old materials :/
	 */
	public static final int LEGACY_OFFSET = 5;

	public static final int LABEL_MARGIN_TEXT = 9;
	public static final int LABEL_MARGIN_LATEX = 5;

	private static final int CHECKBOX_SIZE = EuclidianConstants.DEFAULT_CHECKBOX_SIZE;

	private final GeoBoolean geoBool;

	private boolean isVisible;
	private String oldCaption;

	private int textWidth = 0;
	private int textHeight = 0;

	/**
	 * Creates new DrawBoolean
	 * 
	 * @param view
	 *            view
	 * @param geoBool
	 *            boolean (checkbox)
	 */
	public DrawBoolean(EuclidianView view, GeoBoolean geoBool) {
		this.view = view;
		this.geoBool = geoBool;
		geo = geoBool;
		update();
	}

	private boolean isLatexLabel() {
		return CanvasDrawable.isLatexString(labelDesc);
	}

	@Override
	public void update() {
		isVisible = geo.isEuclidianVisible();

		// return here, object is invisible, not just offscreen
		if (!isVisible) {
			return;
		}
		updateStrokes(geoBool);

		// show hide label by setting text
		if (geo.isLabelVisible()) {
			// get caption to show r
			String caption = geoBool.getCaption(StringTemplate.defaultTemplate);
			if (!caption.equals(oldCaption)) {
				oldCaption = caption;
				labelDesc = caption; // GeoElement.indicesToHTML(caption, true);
			}
			// checkBox.setText(labelDesc);
		} else {
			// don't show label
			oldCaption = "";
			labelDesc = "";
		}
		updateTextWidth();
		updateLabel();
		if (getDynamicCaption() != null && getDynamicCaption().isEnabled()) {
			getDynamicCaption().update();
		}
	}

	private void updateLabel() {
		xLabel = geoBool.getAbsoluteScreenLocX();
		yLabel = geoBool.getAbsoluteScreenLocY();
		int prefSize = CHECKBOX_SIZE + 12;
		labelRectangle.setBounds(xLabel, yLabel,
				prefSize + textWidth, prefSize);
	}

	@Override
	public void draw(GGraphics2D g2) {
		if (isVisible) {
			g2.setFont(view.getFontPoint());
			int checkboxX = geoBool.getAbsoluteScreenLocX() + LEGACY_OFFSET;
			int checkboxY = geoBool.getAbsoluteScreenLocY() + LEGACY_OFFSET;
			CheckBoxIcon.paintIcon(geoBool.getBoolean(),
					!geoBool.isSelectionAllowed(view), g2, checkboxX, checkboxY);
			if (isHighlighted()) {
				CheckBoxIcon.highlightIcon(g2, checkboxX, checkboxY);
			}
			if (geo.isLabelVisible()) {
				drawLabel(g2, checkboxX);
			}
		}
	}

	private void updateTextWidth() {
		if (getDynamicCaption() != null && getDynamicCaption().isEnabled()) {
			getDynamicCaption().update();
			getDynamicCaption().measure();
			textWidth = getDynamicCaption().getWidth();
		} else if (isLatexLabel()) {
			GDimension d = CanvasDrawable.measureLatex(
					view.getApplication(), view.getFontPoint(),
					labelDesc);

			textWidth = d.getWidth();
			textHeight = d.getHeight();
		} else {
			GTextLayout layout = getTextLayout(labelDesc,
					view.getFontPoint());

			// ie labelDesc != ""
			if (layout != null) {
				textWidth = (int) Math.round(layout.getBounds().getWidth());
				textHeight = (int) Math.round(layout.getBounds().getHeight());
			}
		}
	}

	private void drawLabel(GGraphics2D g2, int checkboxX) {
		GColor textColor = geoBool.usesDisabledStyle(null)
				? GeoGebraColorConstants.NEUTRAL_500 : geo.getObjectColor();
		if (getDynamicCaption() != null && getDynamicCaption().isEnabled()) {
			getDynamicCaption().draw(g2);
		} else if (isLatexLabel()) {
			int captionX = checkboxX + CHECKBOX_SIZE + LABEL_MARGIN_LATEX;
			int captionY = getCaptionY(true, textHeight);

			App app = view.getApplication();
			g2.setPaint(textColor);

			app.getDrawEquation().drawEquation(app, geoBool, g2, captionX, captionY,
					labelDesc, g2.getFont(),
					StringUtil.startsWithFormattingCommand(labelDesc),
					textColor, geoBool.getBackgroundColor(),
					false, false,
					view.getCallBack(geo, firstCall));
			firstCall = false;
		} else {
			g2.setPaint(textColor);
			if (!StringUtil.empty(labelDesc)) {
				int captionX = checkboxX + CHECKBOX_SIZE + LABEL_MARGIN_TEXT;
				int captionY = getCaptionY(false, textHeight);
				EuclidianStatic.drawIndexedString(view.getApplication(), g2,
						labelDesc, captionX, captionY, false);
			}
		}
	}

	@Override
	public int getCaptionY(boolean latex, int height) {
		return latex ? geoBool.getAbsoluteScreenLocY()
				+ (CHECKBOX_SIZE - height) / 2 + LEGACY_OFFSET
				: geoBool.getAbsoluteScreenLocY()
				+ (CHECKBOX_SIZE + height) / 2 + LEGACY_OFFSET;
	}

	/**
	 * was this object clicked at? (mouse pointer location (x,y) in screen
	 * coords)
	 */
	@Override
	public boolean hit(int x, int y, int hitThreshold) {
		return super.hitLabel(x, y);
	}

	@Override
	public boolean isInside(GRectangle rect) {
		return rect.contains(labelRectangle);
	}

	@Override
	public boolean intersectsRectangle(GRectangle rect) {
		return rect.intersects(labelRectangle);
	}

	/**
	 * Returns false
	 */
	@Override
	public boolean hitLabel(int x, int y) {
		return false;
	}

	/**
	 * Replacement for Swing component
	 */
	public static class CheckBoxIcon {

		private static final int BORDER_DIAMETER = 4;
		private static GBasicStroke stroke26 = null;
		private static GGeneralPath gp;

		/**
		 * @param g2 graphics
		 * @param x x-coordinate of the icon
		 * @param y y-coordinate of the icon
		 */
		public static void highlightIcon(GGraphics2D g2, int x, int y) {
			Drawable.drawHighlightRectangle(g2, x + 1, y + 1,
					CHECKBOX_SIZE - 2, CHECKBOX_SIZE - 2, BORDER_DIAMETER);
		}

		/**
		 * Draws the checkbox on graphics.
		 * 
		 * @param checked
		 *            true if checked
		 * @param disabled
		 *            true if disabled
		 * @param g
		 *            graphics
		 * @param x
		 *            x coordinate (left edge)
		 * @param y
		 *            y coordinate (upper edge)
		 */
		static public void paintIcon(boolean checked, boolean disabled,
				GGraphics2D g, int x, int y) {
			g.setStroke(AwtFactory.getPrototype().newBasicStroke(2.0));
			GColor bg = GColor.WHITE;
			if (checked) {
				bg = disabled ? GeoGebraColorConstants.NEUTRAL_500
						: GeoGebraColorConstants.PURPLE_600;
			}
			g.setColor(bg);
			g.fillRoundRect(x, y, CHECKBOX_SIZE, CHECKBOX_SIZE, BORDER_DIAMETER,
					BORDER_DIAMETER);
			// Draw rounded border
			if (!checked) {
				g.setColor(disabled
						? GeoGebraColorConstants.NEUTRAL_500
						: GeoGebraColorConstants.NEUTRAL_700);
				g.drawRoundRect(x + 1, y + 1, CHECKBOX_SIZE - 2,
						CHECKBOX_SIZE - 2, BORDER_DIAMETER, BORDER_DIAMETER);
			}
			// paint check
			if (checked) {
				if (stroke26 == null) {
					initPathAndStroke();
				}
				g.setColor(GColor.WHITE);
				g.setStroke(stroke26);
				g.translate(x, y);
				g.draw(gp);
				g.translate(-x, -y);
			}
		}

		private static void initPathAndStroke() {
			// based on ic_check_white24px.svg, scaled to 20px and offset by 3px
			//{1.73,12.91,8.1,19.28,22.79,4.59}*20/24 + 3
			//gives {4.44,13.76,9.75,19.07,21.99,6.83}
			stroke26 = AwtFactory.getPrototype().newBasicStroke(2.6,
					GBasicStroke.CAP_SQUARE,
					GBasicStroke.JOIN_MITER);
			gp = AwtFactory.getPrototype().newGeneralPath();
			gp.moveTo(4.44, 13.76);
			gp.lineTo(9.75, 19.07);
			gp.lineTo(21.99, 6.83);
		}

	}

	@Override
	public GRectangle2D getBoundsForCorner() {
		return labelRectangle;
	}

}
