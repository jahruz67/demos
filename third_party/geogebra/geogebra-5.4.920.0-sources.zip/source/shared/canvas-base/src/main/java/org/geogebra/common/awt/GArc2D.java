/*
 * GeoGebra - Dynamic Mathematics for Everyone
 * Copyright (c) GeoGebra GmbH, Altenbergerstr. 69, 4040 Linz, Austria
 * https://www.geogebra.org
 *
 * This file is licensed by GeoGebra GmbH under the EUPL 1.2 licence and
 * may be used under the EUPL 1.2 in compatible projects (see Article 5
 * and the Appendix of EUPL 1.2 for details).
 * You may obtain a copy of the licence at:
 * https://interoperable-europe.ec.europa.eu/collection/eupl/eupl-text-eupl-12
 *
 * Note: The overall GeoGebra software package is free to use for
 * non-commercial purposes only.
 * See https://www.geogebra.org/license for full licensing details
 */

package org.geogebra.common.awt;

/**
 * Wrapper for java.awt.geom.Arc2D compatible classes
 */
public interface GArc2D extends GRectangularShape {
	/** open type (just the arc) */
	int OPEN = 0;
	/** chord type (include line connecting ends) */
	int CHORD = 1;
	/** pie type (include lines connecting with center + the area) */
	int PIE = 2;

	/**
	 * 
	 * @param x
	 *            x-coord of top left corner
	 * @param y
	 *            y-coord of top left corner
	 * @param width
	 *            width
	 * @param height
	 *            height
	 * @param angleStart
	 *            start angle
	 * @param angleEnd
	 *            end angle
	 * @param type
	 *            type (OPEN or PIE)
	 */
	void setArc(double x, double y, double width, double height,
			double angleStart, double angleEnd, int type);

	/**
	 * @return start point
	 */
	GPoint2D getStartPoint();

	/**
	 * @return end point
	 */
	GPoint2D getEndPoint();

	/**
	 * 
	 * @param centerX
	 *            x-coord of center
	 * @param centerY
	 *            y-coord of center
	 * @param radius
	 *            circle radius
	 * @param angleStart
	 *            start angle
	 * @param angleExt
	 *            end angle
	 * @param type
	 *            type (OPEN or PIE)
	 */
	void setArcByCenter(double centerX, double centerY,
			double radius, double angleStart, double angleExt, int type);

}
